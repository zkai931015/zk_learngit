#ifndef    _H_SSL_H_
#define    _H_SSL_H_

#include "haier_appmain.h"

#include "uplus_type.h"

#include "config.h"
#include "platform.h"
#include "debug.h"
#include "ssl.h"
#include "entropy.h"
#include "ctr_drbg.h"
#include "error.h"
#include "certs.h"

#include "stdio.h"
#include "string.h"

#define SERVER_NAME "uplus-haier-u-ac-1473-v2-"

#define GET_REQUEST "GET / HTTP/1.0\r\n\r\n"


typedef struct {

		uint16 rx;
		uint8 *ssl_recv_buf;
		uint16 buffLen;
		
}SSL_RECV;


typedef struct {
	
    int fd;      
	
}mbedtls_context;

typedef struct{

	//�������Լ����ӵ�
	mbedtls_context server_fd;
  	//����mbedtls���һЩ�ṹ��
    mbedtls_entropy_context *entropy;
    mbedtls_ctr_drbg_context *ctr_drbg;
    mbedtls_ssl_context *ssl;
    mbedtls_ssl_config *conf;
    mbedtls_x509_crt *cacert;
		
}ssl_session_ctx;

extern uplus_ctx_id net_ssl_client_create(uplus_s32 fd, struct uplus_ca_chain *root_ca, uplus_u8 root_ca_num);
extern uplus_s32 net_ssl_client_handshake(uplus_ctx_id id);
extern uplus_s32 net_ssl_client_close(uplus_ctx_id id);
extern uplus_s32 net_ssl_pending(uplus_ctx_id id);
extern uplus_s32 net_ssl_read(uplus_ctx_id id, uplus_u8 *buf, uplus_size_t len);
extern uplus_s32 net_ssl_write(uplus_ctx_id id, uplus_u8 *buf, uplus_size_t len);

#endif


#include "haier_bt.h"
#include "haier_module.h"
#include "zk_atcmd.h"


void bt_task_main(void *pParameter);	
void bt_recv_task_main(void *pParameter);
void bt_uart_timer_callback(void *argument);

static bt_uart_recv1 bt_uart_recv;

static void bt_uart_mark_can_receive(void)
{
    HANDLE Section = iot_os_enter_critical_section();
	
    bt_uart_recv.recvLen = 0;
	
    iot_os_exit_critical_section(Section);
}


void bt_uart_timer_callback(void *argument)
{
	if(bt_uart_recv.recv_start)
	{
		bt_uart_recv.recv_timeout++;
		if(bt_uart_recv.recv_timeout > (BT_RECV_TIMEOUT/5))
		{
			bt_uart_recv.recv_start = 0;
			bt_uart_recv.recv_timeout = 0;

			iot_os_stop_timer(bt_uart_timer_handle);
			task_msg_send(bt_recv_task_handle, BT_UART_RECV_MSG, bt_uart_recv.recvbuff, bt_uart_recv.recvLen);
			return;
		}
	}
	iot_os_start_timer(bt_uart_timer_handle, 5);
}

static void bt_uart_recv_process(void)
{
	if(bt_uart_recv.recv_start == 0)  //�Ƿ�Ϊ���յĵ�һ���ֽ�
	{
		bt_uart_recv.recv_start = 1; //��ʼ���ձ�־λ��λ

		bt_uart_recv.recv_timeout = 0; //��ʱ������0

		iot_os_start_timer(bt_uart_timer_handle, 5);
	}
	else
	{
		bt_uart_recv.recv_timeout = 0;
	}
}

void bt_recv_handle(T_AMOPENAT_UART_MESSAGE* evt)
{
	uint8 *recv_buff = NULL;
    int32 recv_len;
    int32 dataLen = evt->param.dataLen;

	if(dataLen > 0)
	{
		recv_buff = iot_os_malloc(dataLen);
		if(recv_buff == NULL)
		{
			uplus_sys_log("[zk bt] bt_uart_recv_handle_0 recv_buff malloc fail %d", dataLen);
		}
	}
	else
	{
		//uplus_sys_log("[zk bt] bt_uart_recv_handle_1 datalen error %d", dataLen);
		return;
	}
	
    switch(evt->evtId)
    {
        case OPENAT_DRV_EVT_UART_RX_DATA_IND:
    
            recv_len = iot_uart_read(BT_UART_PORT, recv_buff, dataLen , BT_UART_RECV_TIMEOUT);
			
       		if(bt_uart_recv.recvLen < (BT_UART_RECVBUFF_MAX - BT_UART_RECV_BLOCK))
			{
				memcpy(bt_uart_recv.recvbuff + bt_uart_recv.recvLen, recv_buff, recv_len);
				bt_uart_recv.recvLen += recv_len;

				bt_uart_recv_process();
			}
			iot_os_free(recv_buff);
            break;
        case OPENAT_DRV_EVT_UART_TX_DONE_IND:
            uplus_sys_log("[zk bt] bt_uart_recv_handle_3 OPENAT_DRV_EVT_UART_TX_DONE_IND");
            break;
        default:
            break;
    }
}

void bt_uart_write(char *buff, int32 len)
{
	if((buff == NULL) || (len <=0))
		return;
	
    uint16 write_len = iot_uart_write(BT_UART_PORT, (uint8*)buff, len);
}

static void bt_conn_handle (E_OPENAT_DRV_EVT evt, E_AMOPENAT_GPIO_PORT gpioPort, unsigned char state)
{
    UINT8 status;

    // �ж���gpio�ж�
    if (OPENAT_DRV_EVT_GPIO_INT_IND == evt)
    {
        // �жϴ����жϵĹܽ�
        if (BT_CONN_PIN == gpioPort)
        {   
            // ����ǰgpio״̬, 1:�ߵ�ƽ 0:�͵�ƽ
            iot_gpio_read(gpioPort, &status);
            uplus_sys_log("[zk bt] bt conn suc gpio %d, status %d", gpioPort, state);
			//�����ӳɹ��Ժ���������Ϊ͸��ģʽ
			BT_MODE_CTR(FALSE);
        }
    }
}

static void bt_uart_init(void)
{   
    T_AMOPENAT_UART_PARAM uartCfg;
	
    memset(&uartCfg, 0, sizeof(T_AMOPENAT_UART_PARAM));
    uartCfg.baud = OPENAT_UART_BAUD_9600; //(E_AMOPENAT_UART_BAUD)baud;
    uartCfg.dataBits = 8;  
    uartCfg.stopBits = 1; 
    uartCfg.parity = OPENAT_UART_NO_PARITY; 
    uartCfg.flowControl = OPENAT_UART_FLOWCONTROL_NONE; 
    uartCfg.txDoneReport = TRUE; 
    uartCfg.uartMsgHande = bt_recv_handle; 
   
	if(iot_uart_open(BT_UART_PORT, &uartCfg) == FALSE)
	{
		uplus_sys_log("[zk bt] bt_uart_init fail");
	}
	uplus_sys_log("[zk bt] bt_uart_init");
}

static void bt_uart_deinit(void)
{
	iot_uart_close(BT_UART_PORT);
}

static void bt_gpio_init(void)
{
	T_AMOPENAT_GPIO_CFG  output_cfg;
    BOOL err;

	//BT_CTR�������ã�����Ϊ͸��ģʽ
    memset(&output_cfg, 0, sizeof(T_AMOPENAT_GPIO_CFG));
    
    output_cfg.mode = OPENAT_GPIO_OUTPUT; //���
    output_cfg.param.defaultState = TRUE; //Ĭ�ϵ�ƽ

    err = iot_gpio_config(BT_MODE_PIN, &output_cfg);
    if (!err)
        return;

	//BT_REST�������á��͵�ƽBTģ���������У��ߵ�ƽ���ָ�λ
	output_cfg.param.defaultState = TRUE; // Ĭ�ϵ�ƽ  

    err = iot_gpio_config(BT_REST_PIN, &output_cfg);
    if (!err)
        return;
	iot_os_sleep(50);
	iot_gpio_set(BT_REST_PIN, FALSE);
	
	//BT_CONN�������ã�
	T_AMOPENAT_GPIO_CFG  input_cfg;
    
    memset(&input_cfg, 0, sizeof(T_AMOPENAT_GPIO_CFG));
    
    input_cfg.mode = OPENAT_GPIO_INPUT_INT; //���������ж�
    input_cfg.param.defaultState = FALSE;    
    input_cfg.param.intCfg.debounce = 50;  //����50ms
    input_cfg.param.intCfg.intType = OPENAT_GPIO_INT_FALLING_EDGE; //�½��ش����ж�
    input_cfg.param.intCfg.intCb = bt_conn_handle; 		//�жϴ�������
    
    err = iot_gpio_config(BT_CONN_PIN, &input_cfg);
    if (!err)
    {
    	uplus_sys_log("[zk bt] bt_init_2:init fail");
        return;
    }
	
    uplus_sys_log("[zk bt] bt_init_3");
}

static void bt_init(void)
{
	bt_gpio_init();
	bt_uart_init();
}

void bt_set_key(uint8 opt)
{
	//01 FC 1A 11 Option PVK
	uint8 cmdbuf[22]={0}; 

	cmdbuf[0] = 1;
	cmdbuf[1] = 0xfc;
	cmdbuf[2] = 0x1A;
	cmdbuf[3] = 0x11;
	//Option��
	//bit0������ѡ�0-�����ܣ�1-�������͵����ݼ���
	//bit1������ѡ�0-�����ܣ�1-�����յ������ݽ���
	//bit2����Կѡ��0-��˽Կ��Ϊ��Կ��1-ʹ���������Ϊ��Կ
	//bit3����Ȩѡ�0-�����Ȩ��1-���Ӻ����� 30s ����ɼ�Ȩ������Ͽ�
	cmdbuf[4] = opt;
	//16byte PVK
	cmdbuf[5] = 'U';
	memcpy(cmdbuf+6, appSysTem.Module_IMEI, 15);

	bt_uart_write(cmdbuf, 21);

	uplus_sys_log("[zk bt] bt_set_key:start key=%s", cmdbuf+6);
}

static void bt_get_key(void)
{
	//01 FC 1B 00
	uint8 cmdbuf[4]={0}; 

	cmdbuf[0] = 1;
	cmdbuf[1] = 0xfc;
	cmdbuf[2] = 0x1B;
	cmdbuf[3] = 0;

	bt_uart_write(cmdbuf, 4);

	uplus_sys_log("[zk bt] bt_get_key:start");
}

static void bt_set_baud(void)
{
	uint8 cmdbuf[7]={0}; 

	cmdbuf[0] = 1;
	cmdbuf[1] = 0xfc;
	cmdbuf[2] = 1;
	cmdbuf[3] = 3;
	//������: 00   01  	 02  	03  	04  	05  	06  	07  	 08  	 09
	//kbps    2.4  4.8 	 9.6 	19.2 	38.4 	57.6 	115.2 	230.4  460.8  921.6
	cmdbuf[4] = 6;
	cmdbuf[5] = 0;
	cmdbuf[6] = 0;
	
	bt_uart_write(cmdbuf, 7);

	uplus_sys_log("[zk bt] bt_set_baud:start");
}

static void bt_get_mac(void)
{
	uint8 cmdbuf[5]={0}; 
	
	cmdbuf[0] = 0x01;
	cmdbuf[1] = 0xfc;
	cmdbuf[2] = 0x18;
	cmdbuf[3] = 1;
	cmdbuf[4] = 3;

	bt_uart_write(cmdbuf, 5);

	uplus_sys_log("[zk bt] bt_get_mac_0:start");
}

static void bt_set_name(char* name, uint16 name_len)
{
	if(name_len < 20)
	{
		uint8 *cmdbuf = iot_os_malloc(name_len+4);
		if(cmdbuf == NULL)
		{
			 uplus_sys_log("[zk bt] set_bt_name_0 malloc fail");
			return;
		}
		cmdbuf[0] = 0x01;
		cmdbuf[1] = 0xfc;
		cmdbuf[2] = 0x07;
		cmdbuf[3] = name_len;
		memcpy(cmdbuf+4, name, name_len);

		bt_uart_write(cmdbuf, name_len+4);

		iot_os_free(cmdbuf);
		uplus_sys_log("[zk bt] set_bt_name_1:start");
	}
}

static void bt_get_name(void)
{
	uint8 *cmdbuf = iot_os_malloc(4);
	if(cmdbuf == NULL)
	{
		 uplus_sys_log("[zk bt] bt_get_name0 malloc fail");
		return;
	}
	cmdbuf[0] = 0x01;
	cmdbuf[1] = 0xfc;
	cmdbuf[2] = 0x08;
	cmdbuf[3] = 0;

	bt_uart_write(cmdbuf, 4);

	iot_os_free(cmdbuf);

	uplus_sys_log("[zk bt] get_bt_name_1:start");
}

static void bt_event_notify_process(uint8 *data, uint16 datalen)
{
	if((data == NULL) || (datalen == 0))
		return;

	//zk_debug(data, datalen);

	bt_uart_write(data, datalen);

	uplus_sys_log("[zk bt] event_notify_1");
}

void bt_task_main(void *pParameter)
{
	TASK_MSG *msg = NULL;
	
	bt_init();
	iot_os_sleep(3000);
	//bt_set_baud();
	bt_get_mac();
	//bt_set_name(BT_NAME, sizeof(BT_NAME));
	while(1)
	{
		iot_os_wait_message(bt_task_handle, (PVOID*)&msg);	
		switch(msg->id)
	    {
			case BT_EVENT_NOTIFY_MSG:
				bt_event_notify_process(msg->param, msg->len);
				break;
	        default:
				uplus_sys_log("[zk bt] bt_task_main_0 not cmd");
	            break;
	    }
		
	    if(msg)
	    {
	        if(msg->param)
	        {
	            iot_os_free(msg->param);
	            msg->param = NULL;
	        }
	        iot_os_free(msg);
	        msg = NULL;
	    }
	}
}


/**********  BT���ݽ��մ���   **********/

static void bt_get_key_ack(uint8 * data, uint16 datalen)
{
	if((data == NULL) || (datalen==0))
		return;
	
	if(data[4] == 0)
	{
		uint8 key[17] = {0};
		memcpy(key, data+6, 16);
		uplus_sys_log("[zk bt] bt_get_key_ack suc: key=%s", key);
	}
	else
	{
		uplus_sys_log("[zk bt] bt_get_key_ack:fail %d", data[4]);
	}
}

static void bt_set_key_ack(uint8 * data, uint16 datalen)
{
	if((data == NULL) || (datalen==0))
		return;
	
	if(data[4] == 0)
	{
		uplus_sys_log("[zk bt] bt_set_key_ack:suc");
		//������key�󣬶�ȡһ��
		bt_get_key();
	}
	else
	{
		uplus_sys_log("[zk bt] bt_set_key_ack:fail %d", data[4]);
	}
}

static void bt_set_baud_ack(uint8 * data, uint16 datalen)
{
	if((data == NULL) || (datalen==0))
		return;
	
	if(data[4] == 0)
	{
		uplus_sys_log("[zk bt] bt_set_baud_ack_:ok");
		iot_os_sleep(60);

		bt_uart_deinit();

		bt_uart_init();
		
		bt_get_mac();
	}
	else
	{
		uplus_sys_log("[zk bt] bt_set_baud_ack:fail %d", data[4]);
	}
}

static void bt_get_mac_ack(uint8 * data, uint16 datalen)
{
	if((data == NULL) || (datalen==0))
		return;

	if(data[4] == 0)
	{
		uint8 bt_mac[15] = {0};
		uint8 macLen = data[3] -2;
		uint8 bt_name[20] = {0};
		uplus_sys_log("[zk bt] bt_get_mac_ack_0 get mac suc macLen=%d", macLen);

		uint8 i;
		uint8 num = 0;
		for(i=macLen; i>0; i--)
		{
			num += snprintf(bt_mac+num, sizeof(bt_mac)-num, "%02X", data[5+i]);
			
			//uplus_sys_log("macLen[%d]=0x%02X", i, data[6+i]);
		}
		//����nameͷ
		memcpy(bt_name, BT_NAME, strlen(BT_NAME));
		//��������mac��ַ��6λ
		memcpy(bt_name+strlen(BT_NAME), bt_mac+((macLen*2)-6), 6);
		
		uplus_sys_log("[zk bt] bt_get_mac_ack_1 bt_mac=%s bt_name=%s", bt_mac, bt_name);
		
		bt_set_name(bt_name, strlen(bt_name)+1);
	}
	else
	{
		uplus_sys_log("[zk bt] bt_get_mac_ack:fail %d", data[4]);
	}
}

static void bt_set_name_ack(uint8 * data, uint16 datalen)
{
	if((data == NULL) || (datalen==0))
		return;

	if(data[4] == 0)
	{
		uplus_sys_log("[zk bt] bt_set_name_ack_0 set name suc");

		//���óɹ��󣬲�ѯһ��
		bt_get_name();
	}
	else
	{
		uplus_sys_log("[zk bt] bt_set_name_ack_0 set name fail %d", data[4]);
	}
}

static void bt_get_name_ack(uint8 * data, uint16 datalen)
{
	if((data == NULL) || (datalen==0))
		return;

	if(data[4] == 0)
	{
		uplus_sys_log("[zk bt] bt_get_name_ack_0:%s", data+5);
		
		//�������óɹ��󣬿���͸��ģʽ��׼��������λ�����ƿյ�ָ��
		//BT_MODE_CTR(FALSE);
	}
	else
	{
		uplus_sys_log("[zk bt] bt_get_name_ack:fail %d", data[4]);
	}
}

//FFFF0C000000000000015D0100006B //��
//FFFF0C000000000000015D0100016C//��
//FFFF140000000000000160010302650002030040000025 //����

static uint8 off_air[] = {0xFF,0xFF,0x0C,00,00,00,00,00,00,0x01,0x5D,0x01,00,00,0x6B};
static uint8 on_air[] = {0xFF,0xFF,0x0C,00,00,00,00,00,00,0x01,0x5D,0x01,00,0x01,0x6C};
static uint8 ctr_air[] = {0xFF,0xFF,0x14,00,00,00,00,00,00,0x01,0x60,0x01,0x03,0x02,0x65,00,0x02,0x03,00,0x40,00,00,0x25};

static void bt_ctr_air_handle(uint8 *data, uint16 datalen)
{
	if((data == NULL) || (datalen==0))
		return;
	
	uplus_sys_log("[zk bt] bt_ctr_air_handle_1 bt control air %d", datalen);

	//�������ƿյ����Դ���
	switch(data[2])
	{
		case 0xff:
			task_msg_send(air_task_handle, BT_CTR_AIR_MSG, off_air, sizeof(off_air));
			break;
		case 0xAA:
			task_msg_send(air_task_handle, BT_CTR_AIR_MSG, on_air, sizeof(on_air));
			break;
		case 0x96:
			task_msg_send(air_task_handle, BT_CTR_AIR_MSG, ctr_air, sizeof(ctr_air));
			break;
		default:
			uplus_sys_log("[zk bt] bt_ctr_air_handle_2 cmd error 0x%x", data[2]);
			
			task_msg_send(air_task_handle, BT_CTR_AIR_MSG, data, datalen);
			break;
	}
	//task_msg_send(air_task_handle, BT_CTR_AIR_MSG, data, datalen);
}

static void bt_recv_data_process(uint8 *data, uint16 datalen)
{
	if((data == NULL) || (datalen==0))
		return;

	//BT�����յ������ݿ�����ָ�����ݣ�Ҳ������͸���Ŀյ����ݣ����ݰ�ͷ�ж�
	if((data[0] == 0x04) && (data[1] == 0xFC)) 
	{
		switch(data[2])
		{
			case BT_SET_BAUD:
				bt_set_baud_ack(data, datalen);
				break;
			case BT_SET_NAME:
				bt_set_name_ack(data, datalen);
				break;
			case BT_GET_NAME:
				bt_get_name_ack(data, datalen);
				break;
			case BT_GET_MAC:
				bt_get_mac_ack(data, datalen);
				break;
			case BT_SET_KEY:
				bt_set_key_ack(data, datalen);
				break;
			case BT_GET_KEY:
				bt_get_key_ack(data, datalen);
				break;
			case BT_SET_BROADCAST:
			case BT_GET_BROADCAST:
			default:
				uplus_sys_log("[zk bt] bt_recv_data_process_0 Unsupported cmd %d", data[2]);
				break;
		}
	}
	else if((data[0] == 0xFF) && (data[1] == 0xFF))
	{
		bt_ctr_air_handle(data, datalen);
	}
	else
	{
		at_main_handle(data, datalen);
	}
}

void bt_recv_task_main(void *pParameter)
{
	TASK_MSG *msg = NULL;

	iot_os_sleep(3000);
	while(1)
	{
		iot_os_wait_message(bt_recv_task_handle, (PVOID*)&msg);	
		bt_uart_mark_can_receive();
		
		switch(msg->id)
	    {
			case BT_UART_RECV_MSG:
				bt_recv_data_process(msg->param, msg->len);
				break;
	        default:
				uplus_sys_log("[zk bt] bt_recv_task_main_0 not cmd");
	            break;
	    }
		
	    if(msg)
	    {
	        if(msg->param)
	        {
	            iot_os_free(msg->param);
	            msg->param = NULL;
	        }
	        iot_os_free(msg);
	        msg = NULL;
	    }
	}
}




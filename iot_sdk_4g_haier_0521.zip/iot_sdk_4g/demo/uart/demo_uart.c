#include "haier_appmain.h"
#include "haier_led.h"
#include "haier_bottomPlate.h"
#include "haier_bt.h"
#include "haier_module.h"
#include "haier_uplus_server.h"
#include "haier_fota.h"


HANDLE air_task_handle;
HANDLE air_recv_task_handle;
HANDLE bt_task_handle;
HANDLE bt_recv_task_handle;
HANDLE uplus_server_task_handle;
HANDLE u_server_task_handle;
HANDLE network_task_handle;
HANDLE ota_task_handle;
HANDLE led_task_handle;

HANDLE test_task_handle;

HANDLE haier_main_timer_handle;
HANDLE air_uart_timer_handle;
HANDLE bt_uart_timer_handle;

Haier_AppSystem appSysTem;
LOCAL_CFG local;

int32 uplus_usr_init(void);

void zk_debug(uint8 *buff, uint16 len)
{
	uplus_sys_log("*****************************start******************************");
	uint16 i,j,m;
	j = len % 10;
	uint8 *p = buff;
	for(i=0; i < (len - j); i+=10)
	{
		uplus_sys_log("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X",p[i],p[i+1],p[i+2],p[i+3],p[i+4],p[i+5],p[i+6],p[i+7],p[i+8],p[i+9]);
	
	}
	for(m=0; m<j; m++)
	{
		uplus_sys_log("%02X", p[len - j + m]);
	}
	uplus_sys_log("*****************************end******************************");
}

int my_atoi(const char *src)
{
      int s = 0;
      bool isMinus = 0;
  
      while(*src == ' ')  //�����հ׷�
      {
          src++; 
      }
  
      if(*src == '+' || *src == '-')
      {
          if(*src == '-')
          {
              isMinus = 1;
          }
          src++;
      }
      else if(*src < '0' || *src > '9')  //�����һλ�Ȳ��Ƿ���Ҳ�������֣�ֱ�ӷ����쳣ֵ
      {
          s = 2147483647;
          return s;
      }
  
      while(*src != '\0' && *src >= '0' && *src <= '9')
      {
          s = s * 10 + *src - '0';
          src++;
      }
      return s * (isMinus ? -1 : 1);
 }

VOID task_msg_send(HANDLE hTask, TASK_MSG_ID id, void *param, uint32 len)
{
    TASK_MSG *msg = NULL;

    msg = (TASK_MSG *)iot_os_malloc(sizeof(TASK_MSG));
	memset(msg, 0, sizeof(TASK_MSG));
    msg->id = id;
	if((param != NULL) && (len > 0))
	{
		msg->param = iot_os_malloc(len+1);
		if(msg->param == NULL)
		{
			uplus_sys_log("[zk] task_msg_send_0 malloc fail %d", len);
			iot_os_free(msg);
			return ;
		}
		memset(msg->param, 0, len+1);
		memcpy(msg->param, param, len);
    	msg->len = len;
	}

    iot_os_send_message(hTask, msg);
}

void set_sys_state(SYS_STATE sysStata)
{
	HANDLE Section = iot_os_enter_critical_section();
	
	appSysTem.sysCurrState = sysStata;
	
    iot_os_exit_critical_section(Section);
}

SYS_STATE get_sye_state(void)
{
	return appSysTem.sysCurrState;
}

void write_local_cfg_Info(void)
{
	int32 fd = 0;
    int32 ret = 0;

	 //read & write & create
	fd = iot_fs_open_file("Haier_Local", FS_O_RDWR);
	if(fd  < 0) 
    {
    	fd = iot_fs_create_file("Haier_Local");
        if(fd < 0)
        {
			uplus_sys_log("[zk local] write_local_cfg_Info_0:file create error %d", fd);
			return;
        }
    }
	//�����ļ�ָ�����ļ�ͷ
	iot_fs_seek_file(fd, 0, FS_SEEK_SET);
	//д�������ݵ��ļ�
    ret = iot_fs_write_file(fd, &local, sizeof(LOCAL_CFG));
    if (ret < 0)
    {
		uplus_sys_log("[zk local] Write 'Haier_Local' file failed");
    }
    iot_fs_close_file(fd);

	uplus_sys_log("[zk local]Write 'Haier_Local' file Succ");
}

static void DefaultConfigInfo(void)
{
	//�ȶ������ṹ����0
	memset(&local, 0, sizeof(LOCAL_CFG));
	//�����û�����ʶ��
	strncpy((char *)local.Identifier, USER_IDENTIFIER, sizeof(local.Identifier));
	
	uplus_sys_log("[zk local] Use default configuration");

	write_local_cfg_Info();
}

static void read_local_cfg_Info(void)
{
	int32 fd = 0;

	fd = iot_fs_open_file("Haier_Local", FS_O_RDONLY);
	if(fd  < 0) 
    {
    	fd = iot_fs_create_file("Haier_Local");
        if(fd < 0)
        {
			uplus_sys_log("[zk local] read_local_cfg_Info_0:file create error %d", fd);
			return;
        }
    }
	//�����ļ�ָ�����ļ�ͷ
	iot_fs_seek_file(fd, 0, FS_SEEK_SET);
	//���ļ����ݵ�local
	iot_fs_read_file(fd , &local, sizeof(LOCAL_CFG));
	iot_fs_close_file(fd);
	//У���Ƿ�����Ч����
	if(strncmp((char *)local.Identifier, USER_IDENTIFIER, sizeof(local.Identifier)) != 0)
	{
		uplus_sys_log("[zk local] read_local_cfg_Info_1: Data Fail");
		
		DefaultConfigInfo();  
	}
}

static void local_cfg_Init(void)
{
	read_local_cfg_Info();

	local.rest_num++;

	if(local.fota_flag == 1)
	{
		if(local.fota_fail_ret_num < FOTA_FAIL_RETRIES_NUM)
		{
			set_sys_state(SYS_STATE_FOTA);
			local.fota_fail_ret_num++;
			
			uplus_sys_log("[zk fota] local_cfg_Init:%s,%s,%s,%s", local.ftp_addr, local.user_name, local.user_passwod, local.ota_file_name);
		}
		else
		{
			local.fota_flag = 0;
			local.fota_fail_ret_num = 0;
		}
	}

	uplus_sys_log("[zk local] fota=%d fota_fail_num=%d rest_num=%d", local.fota_flag, local.fota_fail_ret_num, local.rest_num);

	write_local_cfg_Info();
}

static void haier_main_time_callback(void *pParameter)
{
	task_msg_send(air_task_handle, GET_AIR_DATA_MSG, NULL, 0);
}

static void app_soft_timer_created(void)
{
	haier_main_timer_handle = iot_os_create_timer(haier_main_time_callback,  (PVOID)1);

	air_uart_timer_handle = iot_os_create_timer(air_uart_timer_callback,  (PVOID)2);

	bt_uart_timer_handle = iot_os_create_timer(bt_uart_timer_callback,  (PVOID)3);
}

void app_task_created(void)
{
	air_recv_task_handle = iot_os_create_task(air_recv_task_main, NULL, 4096, 4, OPENAT_OS_CREATE_DEFAULT, "air_recv_task");

	air_task_handle = iot_os_create_task(air_task_main, NULL, 2048, 3, OPENAT_OS_CREATE_DEFAULT, "air_task");

	bt_recv_task_handle = iot_os_create_task(bt_recv_task_main, NULL, 2048, 5, OPENAT_OS_CREATE_DEFAULT, "bt_task");

	bt_task_handle = iot_os_create_task(bt_task_main, NULL, 2048, 4, OPENAT_OS_CREATE_DEFAULT, "bt_task");

	u_server_task_handle = iot_os_create_task(uplus_server_task_main, NULL, 4096, 3, OPENAT_OS_CREATE_DEFAULT, "u_server_task");

	//test_task_handle = iot_os_create_task(uplus_server_test_task, NULL, 1024, 6, OPENAT_OS_CREATE_DEFAULT, "teat_task");
}

static void haier_resource_created(void)
{
	//�������õ�һЩ��ʼ��
	local_cfg_Init();

	if(local.fota_flag == 0)
	{
		app_soft_timer_created();
		
		app_task_created();
	}
	else
	{
		ota_task_handle = iot_os_create_task(ota_task, NULL,10*1024, 4, OPENAT_OS_CREATE_DEFAULT,"ota_task");
	}
	
	network_task_handle = iot_os_create_task(network_task_main, NULL, 4096, 3, OPENAT_OS_CREATE_DEFAULT, "network_task");

	led_task_handle = iot_os_create_task(led_task_main, NULL, 1024, 6, OPENAT_OS_CREATE_DEFAULT, "led_task");

}

void app_main(void)
{
	haier_resource_created();
}




#include "string.h"
#include "iot_os.h"
#include "iot_debug.h"
#include "iot_network.h"
#include "iot_socket.h"
#include "iot_gpio.h"


#define NETWORK_DISCONNECT 	(0)
#define NETWORK_READY 			(1)
#define NETWORK_LINKING 		(2)
#define NETWORK_LINKED 		(3)
#define NETWORK_GOING_DOWN 	(4)


typedef struct {
    UINT8 type;
    UINT8 data;
}DEMO_SOCKET_MESSAGE;

extern T_AMOPENAT_INTERFACE_VTBL* g_s_InterfaceVtbl;
#define socket_dbg iot_debug_print

#define DEMO_SERVER_TCP_IP "121.40.198.143"
#define DEMO_SERVER_TCP_PORT 12415

#define DEMO_SERVER_UDP_IP "121.40.170.41"
#define DEMO_SERVER_UDP_PORT 12414   


//zhangkai 2020/04/02
#define LED_MODE_PIN 	65    	//���
#define LED_STATUS_PIN 	64	//�̵�

#define WDG_REST_IN_PIN		54
#define	WDG_WDI_PIN			53

#define LED_MODE_OFF iot_gpio_set(LED_MODE_PIN, FALSE)
#define LED_MODE_ON  iot_gpio_set(LED_MODE_PIN, TRUE)

#define LED_STATUS_OFF iot_gpio_set(LED_STATUS_PIN, FALSE)
#define LED_STATUS_ON  iot_gpio_set(LED_STATUS_PIN, TRUE)

typedef enum
{
	SYS_STATE_POWN = 1,
	SYS_STATE_NETWORK_CONNECT,
    SYS_STATE_RUN,
		
}SYS_STATE;

SYS_STATE SysTem_Status;

static HANDLE g_s_socket_task;
static HANDLE led_task_handle;

static int demo_socket_tcp_recv(int socketfd)
{
    unsigned char recv_buff[64] = {0};
    int recv_len;

    // TCP ��������
    recv_len = recv(socketfd, recv_buff, sizeof(recv_buff), 0);
    socket_dbg("[socket] tcp recv result %d data %s", recv_len, recv_buff);
   
    return recv_len;
}

static int demo_socket_tcp_send(int socketfd)
{
    int send_len;

	char data[1024] = {0};

	memset(data, 0x32, 1024);

    // TCP ��������
    send_len = send(socketfd, data, 1024, 0);
    socket_dbg("[socket] tcp send datd result = %d", send_len);
    return send_len;
}


static int demo_socket_tcp_connect_server(void)
{
    int socketfd;
    int connErr;
    struct openat_sockaddr_in tcp_server_addr; 
    
    // ����tcp socket
    socketfd = socket(OPENAT_AF_INET,OPENAT_SOCK_STREAM,0);
    if (socketfd < 0)
    {
        socket_dbg("[socket] create tcp socket error");
        return -1;
    }
       
    socket_dbg("[socket] create tcp socket success");
    
    // ����TCP����
    memset(&tcp_server_addr, 0, sizeof(tcp_server_addr)); // ��ʼ����������ַ  
    tcp_server_addr.sin_family = OPENAT_AF_INET;  
    tcp_server_addr.sin_port = htons((unsigned short)DEMO_SERVER_TCP_PORT);  
    inet_aton(DEMO_SERVER_TCP_IP,&tcp_server_addr.sin_addr);

    socket_dbg("[socket] tcp connect to addr %s", DEMO_SERVER_TCP_IP);
    connErr = connect(socketfd, (const struct sockaddr *)&tcp_server_addr, sizeof(struct openat_sockaddr));
    

    if (connErr < 0)
    {
        socket_dbg("[socket] tcp connect error %d", socket_errno(socketfd));
        close(socketfd);
        return -1;
    }
    socket_dbg("[socket] tcp connect success");

    return socketfd;
}

static void demo_socket_tcp_client()
{
    int socketfd, ret, err;
    struct openat_timeval tm;
    openat_fd_set readset;
    int optLen = 4, sendBufSize;

    tm.tv_sec = 2;
    tm.tv_usec = 0;

    socketfd = demo_socket_tcp_connect_server();

    if (socketfd >= 0)
    {
        while(1)
        {
            ret = demo_socket_tcp_send(socketfd);
            if(ret < 0)
            {
            	err = socket_errno(socketfd);
				socket_dbg("[socket] send last error %d", err);
            	if(err != OPENAT_EWOULDBLOCK)
            	{
                	//break;
            	}
				else
				{
					iot_os_sleep(10);
					continue;
				}
            }

            OPENAT_FD_ZERO(&readset);
            OPENAT_FD_SET(socketfd, &readset);
            ret = select(socketfd+1, &readset, NULL, NULL, &tm);
            if(ret > 0)
            {
    			ret = demo_socket_tcp_recv(socketfd);
                if(ret == 0)
                {
                    socket_dbg("[socket] recv close");
                    iot_os_sleep(1000);
                }
                else if(ret < 0)
                {
                    socket_dbg("[socket] recv error %d", socket_errno(socketfd));
                    iot_os_sleep(1000);
                }
            }
            else if(ret == 0)
            {
                socket_dbg("[socket] select timeout");
            }
        }
        close(socketfd);
    }
}


static int demo_socket_udp_connect_server(void)
{
    int socketfd;	
    // ����tcp socket
    socketfd = socket(OPENAT_AF_INET,OPENAT_SOCK_DGRAM,0);
    if (socketfd < 0)
    {
        socket_dbg("[socket] create udp socket error");
        return -1;
    }
    socket_dbg("[socket] create udp socket success");

    return socketfd;
}


static int demo_socket_udp_send(int socketfd)
{
    int send_len;
	struct openat_sockaddr_in udp_server_addr; 

	memset(&udp_server_addr, 0, sizeof(udp_server_addr)); // ��ʼ����������ַ  
    udp_server_addr.sin_family = OPENAT_AF_INET;  
    udp_server_addr.sin_port = htons((unsigned short)DEMO_SERVER_UDP_PORT);  
    inet_aton(DEMO_SERVER_UDP_IP,&udp_server_addr.sin_addr);

    // UDP ��������
    send_len = sendto(socketfd, "hello i'm client", strlen("hello i'm client"), 0,
    				  (struct sockaddr*)&udp_server_addr, sizeof(struct openat_sockaddr));
    socket_dbg("[socket] udp send [hello i'm client] result = %d", send_len);
    return send_len;
}

static int demo_socket_udp_recv(int socketfd)
{
    unsigned char recv_buff[64] = {0};
    int recv_len;
	openat_socklen_t udp_server_len;

	struct openat_sockaddr_in udp_server_addr; 

	memset(&udp_server_addr, 0, sizeof(udp_server_addr)); // ��ʼ����������ַ  
    udp_server_addr.sin_family = OPENAT_AF_INET;  
    udp_server_addr.sin_port = htons((unsigned short)DEMO_SERVER_UDP_PORT);  
    inet_aton(DEMO_SERVER_UDP_IP,&udp_server_addr.sin_addr);
	udp_server_len = sizeof(udp_server_addr);

    // UDP ��������
    recv_len = recvfrom(socketfd, recv_buff, sizeof(recv_buff), 0, (struct sockaddr*)&udp_server_addr, &udp_server_len);
    socket_dbg("[socket] udp recv result %d data %s", recv_len, recv_buff);
   
    return recv_len;
}


static void demo_socket_udp_client()
{
    int socketfd, ret, err, count;
    

    socketfd = demo_socket_udp_connect_server();

    if (socketfd >= 0)
    {
        while(1)
        {
            ret = demo_socket_udp_send(socketfd);
            if(ret < 0)
            {
            	err = socket_errno(socketfd);
				socket_dbg("[socket] send last error %d", err);
            	if(err != OPENAT_EWOULDBLOCK)
            	{
                	break;
            	}
				else
				{
					iot_os_sleep(200);
					continue;
				}
            }
			//������ȡ
            ret = demo_socket_udp_recv(socketfd);
            if(ret <= 0)
            {
                socket_dbg("[socket] recv error %d", socket_errno(socketfd));
                break;
            }

			if(++count >= 5)
			{
				socket_dbg("[socket] udp loop end");
				break;
			}
        }
    }
}

static void demo_gethostbyname(void)
{
    //��������

    char *name = "www.baidu.com";
    struct openat_hostent *hostentP = NULL;
    char *ipAddr = NULL;

    //��ȡ����ip��Ϣ
    hostentP = gethostbyname(name);

    if (!hostentP)
    {
        socket_dbg("[socket] gethostbyname %s fail", name);
        return;
    }

    // ��ipת�����ַ���
    ipAddr = ipaddr_ntoa((const openat_ip_addr_t *)hostentP->h_addr_list[0]);
    
    socket_dbg("[socket] gethostbyname %s ip %s", name, ipAddr);
}


static void demo_network_connetck(void)
{
    T_OPENAT_NETWORK_CONNECT networkparam;
    
    memset(&networkparam, 0, sizeof(T_OPENAT_NETWORK_CONNECT));
    memcpy(networkparam.apn, "ctexcel", strlen("ctexcel"));
   
	//memcpy(networkparam.apn, "CTNET", strlen("CTNET"));
	
    iot_network_connect(&networkparam);

}


static void demo_networkIndCallBack(E_OPENAT_NETWORK_STATE state)
{
    DEMO_SOCKET_MESSAGE* msgptr = iot_os_malloc(sizeof(DEMO_SOCKET_MESSAGE));
	
   // iot_debug_print("[zk] network ind state %d", state);

	switch(state)
	{
		case OPENAT_NETWORK_DISCONNECT:
			msgptr->type = NETWORK_DISCONNECT;
			break;
		case OPENAT_NETWORK_READY:
			msgptr->type = NETWORK_READY;
			break;
		case OPENAT_NETWORK_LINKING:
			msgptr->type = NETWORK_LINKING;
			break;
		case OPENAT_NETWORK_LINKED:
			msgptr->type = NETWORK_LINKED;
			break;
		case OPENAT_NETWORK_GOING_DOWN:
			msgptr->type = NETWORK_GOING_DOWN;
			break;
		default:
			iot_os_free(msgptr);
			return;
	}
	iot_os_send_message(g_s_socket_task,(PVOID)msgptr);
}

VOID gpio_Init(VOID)
{
    T_AMOPENAT_GPIO_CFG  output_cfg;
    BOOL err;
    
    memset(&output_cfg, 0, sizeof(T_AMOPENAT_GPIO_CFG));
    
    output_cfg.mode = OPENAT_GPIO_OUTPUT; //输出
    output_cfg.param.defaultState = TRUE; // 默认高电�?
    err = iot_gpio_config(LED_MODE_PIN, &output_cfg);
    if (!err)
        return;

	err = iot_gpio_config(LED_STATUS_PIN, &output_cfg);
	if (!err)
        return;
	
    iot_debug_print("gpio_Init_1 gpio finish");
}



void wdg_reset(void)
{
	iot_gpio_set(WDG_REST_IN_PIN, FALSE);
	iot_os_sleep(100);
	iot_gpio_set(WDG_REST_IN_PIN, TRUE);
}

int8 wdg_feed(void)
{
	//这句其实加不加都可以，为了确保喂狗之前，WDI是高电平（因为要产生一个低脉冲来喂狗）
	iot_gpio_set(WDG_REST_IN_PIN, TRUE);
	
	iot_gpio_set(WDG_REST_IN_PIN, FALSE);
	iot_os_sleep(100);
	iot_gpio_set(WDG_REST_IN_PIN, TRUE);  //喂狗之后，就把电平拉回来

	return 0;
}

int8  wdg_init(VOID)
{
	T_AMOPENAT_GPIO_CFG  output_cfg;
	BOOL err;
	
	memset(&output_cfg, 0, sizeof(T_AMOPENAT_GPIO_CFG));
	
	output_cfg.mode = OPENAT_GPIO_OUTPUT; //输出
	output_cfg.param.defaultState = TRUE; // 默认高电�?
	err = iot_gpio_config(WDG_REST_IN_PIN, &output_cfg);
	if (!err)
		return -1;
	err = iot_gpio_config(WDG_WDI_PIN, &output_cfg);
	if (!err)
		return -1;
	
	wdg_reset();
	return 0;
}


int led_status_change(uint16 led_state)
{
	SysTem_Status = (SYS_STATE)led_state;
	return 0;
}

static VOID led_task_main(PVOID pParameter)
{
	SysTem_Status = SYS_STATE_POWN;
	gpio_Init();
	wdg_init();
	
	while(1)
	{
		switch(SysTem_Status)
		{
			case SYS_STATE_POWN:
				LED_MODE_ON;
				LED_STATUS_ON;
				iot_os_sleep(1800);
				LED_MODE_OFF;
				LED_STATUS_OFF;
				iot_debug_print("[zk] led_task_main_0 sys pown ");
				
				SysTem_Status = SYS_STATE_NETWORK_CONNECT;
				break;
			case SYS_STATE_NETWORK_CONNECT:
				LED_MODE_ON;
				iot_os_sleep(300);
				LED_MODE_OFF;
				iot_os_sleep(200);
				break;
			case SYS_STATE_RUN:
				LED_MODE_ON;
				iot_os_sleep(3000);
				LED_MODE_OFF;
				iot_os_sleep(2900);
				

				iot_debug_print("[zk] led_task_main_1 sys run...");
				break;
			default:
				iot_debug_print("[zk] led_task_main_2 sys status error");
				iot_os_sleep(5000);
				break;
		}
		wdg_feed();
	}
}

#define nDNS1	"8.8.8.8"
#define nDNS2	"114.114.114.114"
static void demo_socket_task(PVOID pParameter)
{
    DEMO_SOCKET_MESSAGE*    msg;
    BOOL sock = FALSE;

	iot_os_sleep(3000);
	extern HANDLE g_CustTaskHandle;
	iot_os_delete_task(g_CustTaskHandle);
	
	//ע������״̬�ص�����
    iot_network_set_cb(demo_networkIndCallBack);
    while(1)
    {
        iot_os_wait_message(g_s_socket_task, (PVOID)&msg);

        switch(msg->type)
        {
        	case NETWORK_DISCONNECT:
				socket_dbg("[zk] network disconnect");
				led_status_change(SYS_STATE_NETWORK_CONNECT);
				break;
            case NETWORK_READY:
                socket_dbg("[zk] network connecting...");
                demo_network_connetck();
				led_status_change(SYS_STATE_NETWORK_CONNECT);
                break;
			case OPENAT_NETWORK_LINKING:
				socket_dbg("[zk] network linking....");
				led_status_change(SYS_STATE_NETWORK_CONNECT);
				break;
            case NETWORK_LINKED:
                socket_dbg("[zk] network connected");
				led_status_change(SYS_STATE_RUN);
				/*int ret = 0;
				CHAR nDns1[30] = {0}, nDns2[30] = {0};
				ret = setNetifDns(nDNS1, nDNS2);
				socket_dbg("[socket] setNetifDns ret: %d", ret);
				ret = getNetifDns(nDns1, nDns2);
				socket_dbg("[socket] getNetifDns ret: %d nDns1: %s, nDns2: %s", ret, nDns1, nDns2);
				
                if(!sock)
                {
					demo_gethostbyname(); 
					//demo_socket_udp_client();
     				demo_socket_tcp_client();
                	sock = TRUE;
                }*/
                break;
			case OPENAT_NETWORK_GOING_DOWN:
				socket_dbg("[zk] network going down");
				led_status_change(SYS_STATE_NETWORK_CONNECT);
				break;
			default:
				break;
        }
		
        iot_os_free(msg);
    }
}


void demo_socket_init(void)
{ 
    //socket_dbg("[socket] demo_socket_init");
    
    g_s_socket_task = iot_os_create_task(demo_socket_task,NULL,4096,5,OPENAT_OS_CREATE_DEFAULT, "demo_socket");

	led_task_handle = iot_os_create_task(led_task_main, NULL, 1024, 6, OPENAT_OS_CREATE_DEFAULT, "led_task");
}

VOID app_main(VOID)
{
 // iot_debug_set_fault_mode(OPENAT_FAULT_HANG);
    demo_socket_init();
}


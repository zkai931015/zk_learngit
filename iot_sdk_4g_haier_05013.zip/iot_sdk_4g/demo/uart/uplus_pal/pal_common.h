
/**
 * @file pal_common.h
 * @brief
 *
 * @date
 * @author
 *
 */

#ifndef __PAL_COMMON_H__
#define __PAL_COMMON_H__

#include "uplus_type.h"

#include "string.h"
#include "stdio.h"
#include <stdarg.h>

#include "iot_debug.h"

#include "iot_uart.h"

#include "iot_os.h"

#include "iot_gpio.h"

#include "iot_network.h"
#include "iot_socket.h"
#include "am_openat_socket.h"
#include "am_openat_drv.h"

#include "iot_fs.h"
#include "iot_flash.h"

#include "uplus_pal_def.h"

#include "haier_appmain.h"
#include "h_ssl.h"

#include "zk_md5.h"

extern int8 wdg_init(VOID);
extern int8 wdg_feed(void);

extern int32 uplus_file_open(int32 *fd, char *file_name, uplus_s32 flags);
extern int32 uplus_file_close(int32 fd);
extern int32 uplus_file_seek(INT32 iFd,         INT32 iOffset, UINT8 iOrigin);
extern int32 uplus_file_write(int32 fd, uint8 *buf, uint32 len);
extern int32 uplus_file_read(int32 fd, uint8 *buf, uint32 len);

extern E_AMOPENAT_POWERON_REASON iot_pmd_get_poweronCasue (void);


/*在此添加相关头文件*/

#endif /*__PAL_COMMON_H__*/


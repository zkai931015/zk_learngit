/******************************************************************************
 * @file app_at_utils.c
 * @brief libneul at_utils, provides some common functions
 * Copyright (c) 2016 NEUL LIMITED
******************************************************************************/
#include "zk_at_utils.h"

#define AT_CMD_HEX_PREFIX_LENGTH     2
#define AT_CMD_HEX_PREFIX_1           "0x"
#define AT_CMD_HEX_PREFIX_2           "0X"

static AT_PARAM_TABLE_s *app_at_param_table = NULL;

uint16 at_get_cmd_length(const uint8 *p_str)
{
    uint16 len=0;
    uint8 in_double_quotes = 0;

    if(!p_str)
    {
        return 0;
    }

    while(*p_str && (*p_str != AT_CMD_SEPARATOR || in_double_quotes))
    {
        if (*p_str == AT_CMD_DOUBLE_QUOTATION)
        {
            in_double_quotes = !in_double_quotes;
        }
        len++;
        p_str++;
    }
    return len;

}

static uint8 at_parse_hex_to_char(uint8 hex)
{
    if(hex < 10)
    {
        return hex + '0';
    }
    else
    {
        return (hex - 0x0a) + 'A';
    }
}

static uint8 at_parse_char_to_hex(uint8 character, uint8 *hex)
{
    uint8 temp_hex;

    if (hex == NULL)
    {
        return 0;
    }

    if((character >= '0') && (character <= '9'))
    {
        temp_hex = character - '0';
    }
    else if((character >= 'a') && (character <= 'f'))
    {
        temp_hex = (character - 'a') + 10;
    }
    else if((character >= 'A') && (character <= 'F'))
    {
        temp_hex = (character - 'A') + 10;
    }
    else
    {
        return 0;
    }
    *hex = temp_hex;
    return 1;
}

uint8 at_parse_buf_to_hex_forward_order(const uint8* source_buf, uint8* dest_buf_hex, uint16 source_length)
{
    uint16 i;
    uint8  temp_ch;

    if ((source_buf == NULL) || (dest_buf_hex == NULL) || (source_length == 0))
    {
        return 0;
    }

    for (i = 0; i < source_length; i++)
    {
        temp_ch = source_buf[i] >> 4;
        dest_buf_hex[2 * i] = at_parse_hex_to_char(temp_ch);

        temp_ch = (source_buf[i] & 0x0f);
        dest_buf_hex[2 * i + 1] = at_parse_hex_to_char(temp_ch);
    }
    return 1;
}

uint8 at_parse_buf_to_hex_reversed_order(uint8* buffer, uint16 length)
{
    int16 i;
    uint8 temp_ch;

    if ((buffer == NULL) || (length == 0) || (length % 2 != 0))
    {
        return 0;
    }

    for (i = (int16)(length / 2 - 1); i >= 0; i--)
    {
        temp_ch = (buffer[i] & 0x0f);
        buffer[2 * i + 1] = at_parse_hex_to_char(temp_ch);

        temp_ch = buffer[i] >> 4;
        buffer[2 * i] = at_parse_hex_to_char(temp_ch);
    }
    return 1;
}

uint8 at_parse_buf_hex_to_uint8(const uint8* source_buf_hex, uint8* dest_buf, uint16 source_length)
{
    uint16 i;
    uint8 hex;

    if ((source_buf_hex == NULL) || (dest_buf == NULL) || ((source_length % 2) != 0))
    {
        return 0;
    }

    for (i = 0; i < source_length;)
    {
        if (at_parse_char_to_hex(*(source_buf_hex + i), &hex) == false)
        {
            return 0;
        }
        dest_buf[i / 2] = (uint8)(hex << 4);

        i++;
        if (at_parse_char_to_hex(*(source_buf_hex + i), &hex) == false)
        {
            return 0;
        }
        dest_buf[i / 2] |= hex;
        i++;
    }
    return 1;

}

uint8 at_parse_buf_hex_to_uint16(const uint8* source_buf_hex, uint16 *dest_value, uint16 source_length)
{
    uint16 i;
    uint8  nible = 0;

    if ((source_buf_hex == NULL) || (dest_value == NULL))
    {
        return 0;
    }

    *dest_value = 0;

    for (i = 0; i < source_length; i++)
    {
        if (at_parse_char_to_hex(*(source_buf_hex + i), &nible) == false)
        {
            return 0;
        }

        *dest_value = (uint16)(*dest_value << 4) + (uint16)nible;
    }
    return 1;
}

uint8 at_parse_buf_hex_to_uint64(const uint8* source_buf_hex, uint64 *dest_value, uint16 source_length)
{
    uint16 i;
    uint8  nible = 0;

    if ((source_buf_hex == NULL) || (dest_value == NULL))
    {
        return 0;
    }

    *dest_value = 0;

    for (i = 0; i < source_length; i++)
    {
        nible = (uint8)(*(source_buf_hex + i));

        if (at_parse_char_to_hex(*(source_buf_hex + i), &nible) == 0)
        {
            return 0;
        }

        *dest_value = (unsigned long long)(*dest_value << 4) + (unsigned long long)nible;
    }

    return 1;
}


static AT_RET at_parse_check_param_is_legal(const uint8 *p_atparams_string)
{
    uint8 in_double_quotes = 0;

    if (p_atparams_string == NULL)
    {
        return AT_RET_INTERNAL_ERROR;
    }

    while((*p_atparams_string !='\0')&&(*p_atparams_string !=AT_CMD_PARAM_SEPARATOR)&&(*p_atparams_string != AT_CMD_SEPARATOR))
    {
        if (*p_atparams_string == AT_CMD_DOUBLE_QUOTATION)
        {
            in_double_quotes = !in_double_quotes;
        }

        if ((*p_atparams_string == AT_CMD_WHITE_SPACE) && (!in_double_quotes))
        {
            return AT_RET_SYNTAX_ERROR;
        }
        p_atparams_string++;
    }
    return AT_RET_OK;
}

static void at_init_param(AT_PARAM_s *p_param)
{
    p_param->str = NULL;
    p_param->str_len = 0;
    p_param->is_in_double_quotes = 0;
}

/** Create at parameter array.
 * @param p_atparams_string The buffer to store at string
 * @return The result number of at parameter array.
 */
static uint8 at_get_num_of_recv_params(const uint8 *p_atparams_string)
{
    uint8    param_num = 1;
    uint8     in_double_quotes = 0;

    if (p_atparams_string == NULL || *p_atparams_string == '\0')
    {
        return 0;
    }

    while ((*p_atparams_string != AT_CMD_END_MARK) && (*p_atparams_string != AT_CMD_SEPARATOR))
    {
        if (*p_atparams_string == AT_CMD_DOUBLE_QUOTATION)
        {
            in_double_quotes = !in_double_quotes;
        }

        if ((AT_CMD_PARAM_SEPARATOR == *p_atparams_string) && (!in_double_quotes))
        {
            param_num++;
        }

        p_atparams_string++;
    }

    return param_num;
}

void at_free_at_params(void)
{
    if(app_at_param_table != NULL)
    {
        if (app_at_param_table->params_array != NULL)
        {
            iot_os_free(app_at_param_table->params_array);
        }
        iot_os_free(app_at_param_table);
    }
}

static AT_RET at_parse_find_seperate(uint8** source, uint8 seperate, uint16 *length)
{
    uint8   *s;
    uint16   count = 0;
    uint8     in_double_quotes = 0;

    if (source == NULL)
    {
        *length = 0;
        return AT_RET_SYNTAX_ERROR;
    }

    s = *source;

    while (((in_double_quotes) || (*s != seperate)) && (*s != AT_CMD_END_MARK))
    {
        if (*s == AT_CMD_DOUBLE_QUOTATION)
        {
            in_double_quotes = !in_double_quotes;
        }
        count++;
        s++;
    }

    *length = count;
    if (*s == seperate)
    {
        s++; // skip comma
    }
    *source = s;

    return AT_RET_OK;
}

AT_RET at_create_param_array(uint8 *p_atparams_string, uint8 *p_param_num, uint8 param_minnum, uint8 param_maxnum)
{
    uint8       count;
    uint8      *p_str = p_atparams_string, *s;
    uint16      str_len = 0;
    AT_RET     cause = AT_RET_SYNTAX_ERROR;
    uint8       param_num;

    param_num = at_get_num_of_recv_params(p_atparams_string);
    *p_param_num = param_num;
    if ((param_num < param_minnum) || (param_num > param_maxnum))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    app_at_param_table = iot_os_malloc(sizeof(AT_PARAM_TABLE_s));
    if(app_at_param_table == NULL)
    {
        return AT_RET_MEMORY_ERROR;
    }

    app_at_param_table->param_count = param_num;
    app_at_param_table->params_array = iot_os_malloc(sizeof(AT_PARAM_s) * param_num);
    if(app_at_param_table->params_array == NULL && param_num != 0)
    {
        iot_os_free(app_at_param_table);
        return AT_RET_MEMORY_ERROR;
    }

    for(count = 0; count < param_num; count++)
    {
        at_init_param(&(app_at_param_table->params_array[count]));
    }

    for(count = 0; count < param_num; count++)
    {
        s = p_str;
        cause = at_parse_find_seperate(&p_str, AT_CMD_PARAM_SEPARATOR, &str_len);
        if (cause != AT_RET_OK)
        {
            at_free_at_params();
            return cause;
        }

        if (str_len == 0)
        {
            app_at_param_table->params_array[count].str = NULL;
        }
        else
        {
            app_at_param_table->params_array[count].str = s;
        }
        app_at_param_table->params_array[count].str_len = str_len;
    }

    return AT_RET_OK;
}

static AT_RET at_parse_uint32(const uint8 *p_str, uint32 *p_val, uint16 str_len)
{
    uint64 value;
    char  *s;

    if ((p_str == NULL) || (p_val == NULL))
    {
        return AT_RET_SYNTAX_ERROR;
    }

    value = strtoul((char*)p_str, &s, 10);
    if (str_len != s - (char*)p_str)
    {
        return AT_RET_NOT_NUMERIC;
    }

    if (value > MAX_UINT32)
    {
        return AT_RET_SYNTAX_ERROR;
    }

    *p_val = (uint32)value;

    return AT_RET_OK;
}

AT_RET at_get_uint32_param(uint8 seqno, uint32 *p_uint32, bool mandatory)
{
    AT_RET cause = AT_RET_OK;

    if( seqno >= app_at_param_table->param_count)
    {
        //Error , reading more param than that present in AT command
        return AT_RET_PARAM_MISSING;
    }
    if(app_at_param_table->params_array[seqno].str == NULL)
    {
        if(mandatory)
        {
            cause = AT_RET_PARAM_MISSING;
        }
        else
        {
            *p_uint32 = AT_INT32_NO_VALUE;
        }
    }
    else
    {
        cause = at_parse_uint32(app_at_param_table->params_array[seqno].str, p_uint32, app_at_param_table->params_array[seqno].str_len);
    }

    return cause;
}

bool at_check_hex_string_prefix(const uint8 *p_string, uint16 str_len)
{
    if((str_len > AT_CMD_HEX_PREFIX_LENGTH) && (p_string != NULL))
    {
        if ((memcmp(p_string, AT_CMD_HEX_PREFIX_1,AT_CMD_HEX_PREFIX_LENGTH) == 0) || (memcmp(p_string, AT_CMD_HEX_PREFIX_2,AT_CMD_HEX_PREFIX_LENGTH) == 0))
        {
            return true;
        }
    }

    return false;
}

static AT_RET at_parse_hex_uint16(uint8 *p_str, uint16 *p_val, uint16 str_len)
{
    uint16  value = 0;
    uint8   value1;
    uint8   i = 0;
    uint8  *p_temp_string = p_str;

    if ((p_str == NULL) || (p_val == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    while ((*p_temp_string != AT_CMD_END_MARK) && (*p_temp_string != AT_CMD_PARAM_SEPARATOR) && (*p_temp_string != AT_CMD_SEPARATOR))
    {
        if (!isxdigit(*p_temp_string))      //lint !e866
        {
            return AT_RET_NOT_NUMERIC;
        }
        p_temp_string++;
    }

    while (i < str_len)
    {
        if(!isxdigit(*p_str))               //lint !e866
        {
            return AT_RET_SYNTAX_ERROR;
        }

        value = (uint16)(value << 4);

        if (at_parse_char_to_hex(*p_str, &value1) == false)
        {
            return AT_RET_SYNTAX_ERROR;
        }

        value  += value1;

        if( (value < value1) || ((value == 0xFFFF) && (i != str_len - 1)))
        {
            return AT_RET_SYNTAX_ERROR;
        }
        i++;
        p_str++;
    }

    *p_val = value;

    return AT_RET_OK;
}

static AT_RET at_parse_uint16(const uint8 *p_str, uint16 *p_val, uint16 str_len)
{
    uint32  value;
    char  *s;

    if ((p_str == NULL) || (p_val == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    value = strtoul((char*)p_str, &s, 10);
    if (str_len != s - (char*)p_str)
    {
        return AT_RET_NOT_NUMERIC;
    }

    if (value > MAX_UINT16)
    {
        return AT_RET_SYNTAX_ERROR;
    }

    *p_val = (uint16)value;

    return AT_RET_OK;
}

static AT_RET at_parse_uint8(const uint8 *p_str, uint8 *p_val, uint16 str_len)
{
    uint16  value;
    char  *s;

    if ((p_str == NULL) || (p_val == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    value = (uint16)strtoul((char*)p_str, &s, 10);
    if (str_len != s - (char*)p_str)
    {
        return AT_RET_NOT_NUMERIC;
    }

    if (value > 0xFF)
    {
        return AT_RET_SYNTAX_ERROR;
    }

    *p_val = (uint8)value;

    return AT_RET_OK;
}

static AT_RET at_parse_int16(const uint8 *p_str, int16 *p_val, uint16 str_len)
{
    int32  value;
    char  *s;

    if ((p_str == NULL) || (p_val == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    value = strtol((char*)p_str, &s, 10);
    if (str_len != s - (char*)p_str)
    {
        return AT_RET_NOT_NUMERIC;
    }

    if ((value < MIN_INT16) || (value > MAX_INT16))
    {
        return AT_RET_SYNTAX_ERROR;
    }

    *p_val = (int16)value;

    return AT_RET_OK;
}


AT_RET at_get_uint16_param(uint8 seqno, uint16 *p_uint16, bool mandatory)
{
    AT_RET cause = AT_RET_OK;

    if ((app_at_param_table == NULL) || (p_uint16 == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    if( seqno >= app_at_param_table->param_count)
    {
        //Error , reading more param than that present in AT command
        return AT_RET_PARAM_MISSING;
    }
    if(app_at_param_table->params_array[seqno].str == NULL)
    {
        if(mandatory)
        {
            cause = AT_RET_PARAM_MISSING;
        }
        else
        {
            *p_uint16 = AT_UINT16_NO_VALUE;
        }
    }
    else
    {
        if(at_check_hex_string_prefix(app_at_param_table->params_array[seqno].str, app_at_param_table->params_array[seqno].str_len))
        {
            return at_parse_hex_uint16(app_at_param_table->params_array[seqno].str + AT_CMD_HEX_PREFIX_LENGTH, p_uint16, app_at_param_table->params_array[seqno].str_len - AT_CMD_HEX_PREFIX_LENGTH);
        }

        cause = at_parse_uint16(app_at_param_table->params_array[seqno].str, p_uint16, app_at_param_table->params_array[seqno].str_len);
    }

    return cause;
}

AT_RET at_get_uint8_param(uint8 seqno, uint8 *p_uint8, bool mandatory)
{
    AT_RET cause = AT_RET_OK;

    if ((app_at_param_table == NULL) || (p_uint8 == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    if( seqno >= app_at_param_table->param_count)
    {
        //Error , reading more param than that present in AT command
        return AT_RET_PARAM_MISSING;
    }
    if(app_at_param_table->params_array[seqno].str == NULL)
    {
        if(mandatory)
        {
            cause = AT_RET_PARAM_MISSING;
        }
    }
    else
    {
        cause = at_parse_uint8(app_at_param_table->params_array[seqno].str, p_uint8, app_at_param_table->params_array[seqno].str_len);
    }

    return cause;
}

AT_RET at_get_int16_param(uint8 seqno, int16 *p_int16, bool mandatory)
{
    AT_RET cause = AT_RET_OK;

    if ((app_at_param_table == NULL) || (p_int16 == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    if( seqno >= app_at_param_table->param_count)
    {
        //Error , reading more param than that present in AT command
        return AT_RET_PARAM_MISSING;
    }
    if(app_at_param_table->params_array[seqno].str == NULL)
    {
        if(mandatory)
        {
            cause = AT_RET_PARAM_MISSING;
        }
        else
        {
            *p_int16 = AT_INT16_NO_VALUE;
        }
    }
    else
    {
        cause = at_parse_int16(app_at_param_table->params_array[seqno].str, p_int16, app_at_param_table->params_array[seqno].str_len);
    }

    return cause;
}

AT_RET at_get_string_param(uint8 seqno, uint8 *p_string, uint16 max_len, bool mandatory)
{
    uint8   *s;
    uint16   str_len;
    uint16   paramstr_offset;

    if ((app_at_param_table == NULL) || (p_string == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    if( seqno >= app_at_param_table->param_count)
    {
        //Error , reading more param than that present in AT command
        return AT_RET_PARAM_MISSING;
    }

    s = app_at_param_table->params_array[seqno].str;
    str_len = app_at_param_table->params_array[seqno].str_len;

    if (s == NULL)
    {
        p_string = NULL;
        if (mandatory)
        {
            return AT_RET_PARAM_MISSING;
        }
        else
        {
            return AT_RET_OK;
        }
    }

    if ((s[0] == AT_CMD_DOUBLE_QUOTATION) && (s[str_len - 1] == AT_CMD_DOUBLE_QUOTATION))
    {
        if (str_len > max_len + 1)
        {
            return AT_RET_SYNTAX_ERROR;
        }

        app_at_param_table->params_array[seqno].is_in_double_quotes = 1;

        // copy and delete quotes
        strncpy(p_string, (s + 1), (str_len - 2));
        p_string[str_len - 2] = AT_CMD_END_MARK;
        return AT_RET_OK;
    }

    if (str_len > max_len - 1)
    {
        return AT_RET_SYNTAX_ERROR;
    }

    // support upper and lower case when the param is not in quoted strings
    /*for(paramstr_offset = 0; paramstr_offset < str_len; paramstr_offset++)
    {
        *(s + paramstr_offset) = (uint8) toupper( *(s + paramstr_offset));//lint !e1058
    }*/

    strncpy(p_string, s, str_len);
    p_string[str_len] = AT_CMD_END_MARK;

    return AT_RET_OK;
}

AT_RET at_get_hexstring_param(uint8 seqno, uint8 **p_hexstring, uint16 *p_hexstring_len, bool mandatory)
{
    uint8       *s;
    AT_RET   cause;

    if ((app_at_param_table == NULL) || (p_hexstring == NULL))
    {
        return AT_RET_INTERNAL_ERROR;
    }

    if( seqno >= app_at_param_table->param_count)
    {
        //Error , reading more param than that present in AT command
        return AT_RET_PARAM_MISSING;
    }

    s = app_at_param_table->params_array[seqno].str;

    if (s == NULL)
    {
        p_hexstring = NULL;
        if (mandatory)
        {
            return AT_RET_PARAM_MISSING;
        }
        else
        {
            return AT_RET_OK;
        }
    }

    cause = at_parse_check_param_is_legal(s);
    if (cause != AT_RET_OK)
    {
        return cause;
    }

    *p_hexstring = s;
    *p_hexstring_len = app_at_param_table->params_array[seqno].str_len;

    return AT_RET_OK;
}

uint16 at_get_cmd_name_length(const uint8 *p_str)
{
    uint16 len = 0;

    if(p_str == NULL)
    {
        return 0;
    }

    while((*p_str != '\0') && (*p_str != '=') && (*p_str != '?') && (*p_str != AT_CMD_SEPARATOR))
    {
        len++;
        p_str++;
    }
    return len;

}

uint8 at_is_param_in_double_quotes(uint8 position)
{
    if (app_at_param_table == NULL)
    {
        return 1;
    }
    if (app_at_param_table->params_array[position].is_in_double_quotes)
    {
        return 1;
    }
    return 0;
}


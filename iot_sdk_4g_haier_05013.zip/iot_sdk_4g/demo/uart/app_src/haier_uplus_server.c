#include "haier_uplus_server.h"
#include "haier_module.h"
#include "uplus_config_platform.h"


#define INSTANCE	1 			//instance  ��ֵ�����Զ���

#define PKT_BUF_MAX	5			//APP��������PKT_BUF����

//��uplusSDKע���豸���صľ��
void *device_handle;

//uplusSDK�ڲ�pkt_bufde��listָ��
pkt_buf_list_t *pkt_buf_list;

//uplusSDKע����豸��Ϣ
device_control_info_t device_ctr_info;

//�յ���һЩ������Ϣ
dev_info_t dev;

//�������·���session����Ҫ���棬�ظ�ʱ��Ҫ����
session_desc_t session;
//�������·�������Я����SN����Ҫ���棬�ظ�ʱ��Ҫ����
uplus_u32 sn;

static UPLUS_STATE uplus_state;

uint8 z_ssid[32] = "zhangkai";
uint8 z_passwd[64] = "12345678";

void set_uplus_sdk_state(UPLUS_STATE state)
{
	HANDLE Section = iot_os_enter_critical_section();
	
    uplus_state = state;
	
    iot_os_exit_critical_section(Section);
}

uint8 get_uplus_sdk_state(void)
{
	return uplus_state;
}

int32 uplus_file_open(int32 *fd, char *file_name, int32 flags)
{
	int32 fd_1;
    fd_1 = iot_fs_open_file(file_name, flags-1);
	if (fd_1 >= 0) 
    {
    	*fd = fd_1;
        return 0;
    }
    fd_1 = iot_fs_create_file(file_name);
	if(fd_1 < 0)
		return -1;
	else
		*fd = fd_1;
	
    return 0;
}

int32 uplus_file_close(int32 fd)
{
	if(iot_fs_close_file(fd) < 0)
		return -1;
	else
		return 0;
}

int32 uplus_file_seek(INT32 iFd, INT32 iOffset, UINT8 iOrigin)
{	
	iot_fs_seek_file  (iFd, iOffset,  iOrigin-1);
	return 0;
}

int32 uplus_file_read(int32 fd, uint8 *buf, uint32 len)
{
	if((buf == NULL) || (len <= 0))
		return -1;
	
	int32 read_num = iot_fs_read_file(fd, buf, len);
	if(read_num > 0)
		return read_num;
	else
		return -1;
}

int32 uplus_file_write(int32 fd, uint8 *buf, uint32 len)
{
	if((buf == NULL) || (len <= 0))
		return -1;

	int32 write_num = iot_fs_write_file(fd, buf, len);
	if(write_num > 0)
		return write_num;
	else
		return -1;
}

#define FLASH_BEGIN_ADDR (0x00790000)
//FLASH_BEGIN_ADDR +64k faslh64k����
#define FLASH_END_ADDR   (0x00800000) 

#define FLASH_BEGIN_BAT_ADDR	(0x00810000)
#define FLASH_END_BAT_ADDR	(0x00820000)

int flash_read(uint32 addr, uint8 *buff, uint32 len)
{
    INT32 read_len = 1;
    E_AMOPENAT_MEMD_ERR errCode;
    
    errCode = iot_flash_read(addr, len, &read_len, buff);

    if(OPENAT_MEMD_ERR_NO != errCode)
    {
    	uplus_sys_log("[zk u+] flash_read error len=%d errcode=%d", len, errCode);
    	return -1;
    }
	uplus_sys_log("[zk u+] flash_read read ok len=%d", len);
	return 0;
}

int flash_write(uint32 addr, uint8 *buff, uint32 len)
{
    INT32 write_len = 1;
    E_AMOPENAT_MEMD_ERR errCode;
   
    errCode = iot_flash_write(addr, len, &write_len, buff);

    if(OPENAT_MEMD_ERR_NO != errCode)
    {
    	uplus_sys_log("[zk u+] flash_write error len=%d errcode=%d", len, errCode);
    	return -1;
    }
	uplus_sys_log("[zk u+] flash_write ok len=%d", len);
	return 0;
}

int flash_erase(uint32 startAddr, uint32 endAddr)
{
    E_AMOPENAT_MEMD_ERR errCode;
   
    errCode = iot_flash_erase(startAddr, endAddr);

    if (OPENAT_MEMD_ERR_NO != errCode)
    {
        uplus_sys_log("[zk u+] flash_erase error=%d s_addr=0x%x e_addr=0x%x", errCode, startAddr, endAddr);
		return -1;
    }
	//uplus_sys_log("[zk u+] flash_erase ok s_addr=0x%x e_addr=0x%x", startAddr, endAddr);
	return 0;
}

int32 uplus_config_write(uint8 config_zone, uint8 *conf, uint32 len)
{
	/*uint32 start_addr = 0;
	
	if(config_zone == 1)
		start_addr = FLASH_BEGIN_ADDR;
	else if(config_zone == 2)
		start_addr = FLASH_BEGIN_BAT_ADDR;
	else
		return -1;

	if(flash_erase(start_addr, start_addr+0x10000) == 0)
	{
		return flash_write(start_addr, conf, len);
	}
	return -1;*/

	char *f_name = NULL;
	int32 fd = 0;

	if(config_zone == 1)
		f_name = FILE_NAME_U_CONFIG;
	else if(config_zone == 2)
		f_name = FILE_NAME_U_CONFIG_BAT;
	
	if(uplus_file_open(&fd, f_name, FILE_FLAGS_RDWR) < 0)
	{
		uplus_sys_log("[zk u+] uplus_config_write_0 open error");
		return -1;
	}
	
	uplus_file_seek(fd, 0, FILE_SEEK_SET);
	
	uint32 writeLen = uplus_file_write(fd, conf, len);
	if(writeLen != len)
	{
		uplus_file_close(fd);
		uplus_sys_log("[zk u+] uplus_config_write_1 error:writeLen=%d len=%d", writeLen, len);
		return -1;
	}
	uplus_sys_log("[zk u+] uplus_config_write_2 suc:writeLen=%d", writeLen);
	uplus_file_close(fd);
	return writeLen;
}

int32 uplus_config_read(uint8 config_zone, uint8 *conf, uint32 len)
{
	/*uint32 start_addr = 0;
	
	if(config_zone == 1)
		start_addr = FLASH_BEGIN_ADDR;
	else if(config_zone == 2)
		start_addr = FLASH_BEGIN_BAT_ADDR;
	else
		return -1;
	
	return flash_read(start_addr, conf, len);*/

	char *f_name = NULL;
	int32 fd = 0;

	if(config_zone == 1)
		f_name = FILE_NAME_U_CONFIG;
	else if(config_zone == 2)
		f_name = FILE_NAME_U_CONFIG_BAT;
	if(uplus_file_open(&fd, f_name, FILE_FLAGS_RDWR) < 0)
	{
		uplus_sys_log("[zk u+] uplus_config_read_0 open error");
		return -1;
	}
	
	uplus_file_seek(fd, 0, FILE_SEEK_SET);
	
	uint32 readLen = uplus_file_read(fd, conf, len);
	if(readLen != len)
	{
		uplus_file_close(fd);
		uplus_sys_log("[zk u+] uplus_config_read_1 error:readLen=%d len=%d", readLen, len);
		return -1;
	}
	uplus_sys_log("[zk u+] uplus_config_read_2 suc:readLen=%d", readLen);
	uplus_file_close(fd);
	return readLen;
}

static void uplus_config_init(void)
{
	char* file_name[]={FILE_NAME_U_CONFIG, FILE_NAME_U_CONFIG_BAT};
	uint8 i = 0;
	int32 fd = 0;
	
	for(i=0; i<sizeof(file_name)/sizeof(file_name[0]); i++)
	{
		fd = iot_fs_open_file(file_name[i], FILE_FLAGS_RDWR-1);
		if(fd < 0)
		{
			fd = iot_fs_create_file(file_name[i]);
			if(fd  < 0)
			{
				uplus_sys_log("[zk u+] uplus_config_init_0 :error name=%s", file_name[i]);
				continue;
			}
			uplus_file_seek(fd, 0, FILE_SEEK_SET);

			uint16 infoLen = 4096;
			uint8 *info = iot_os_malloc(infoLen);
			if(info == NULL)
			{
				uplus_file_close(fd);
				continue;
			}
			uint32 writeLen = uplus_file_write(fd, info, infoLen);
			if(writeLen != infoLen)
			{
				uplus_file_close(fd);
				uplus_sys_log("[zk u+] uplus_config_init_1 error:name=%s writeLen=%d len=%d", file_name[i], writeLen, infoLen);
				return -1;
			}
			uplus_sys_log("[zk u+] uplus_config_init_2 suc:name=%s writeLen=%d", file_name[i], writeLen);
			uplus_file_close(fd);
			iot_os_free(info);
		}
		else
		{
			uplus_file_close(fd);
			uplus_sys_log("[zk u+] uplus_config_init_3:%s file existed", file_name[i]);
		}
		fd = 0;
	}
}

int sys_res_area_write(uint32 offset, uint8 *buf, uint32 len)
{
	int32 fd = 0;
	char *file_name = "res_area";
	
	if(uplus_file_open(&fd, file_name, FILE_FLAGS_RDWR) < 0)
	{
		uplus_sys_log("[zk] uplus_config_write_0 open error name=%s", file_name);
		return -1;
	}
	
	uplus_file_seek(fd, offset, FILE_SEEK_SET);
	
	uint32 writeLen = uplus_file_write(fd, buf, len);
	if(writeLen != len)
	{
		uplus_file_close(fd);
		uplus_sys_log("[zk u+] sys_res_area_write_1 error:writeLen=%d len=%d offset=%d ", writeLen, len, offset);
		return -1;
	}
	uplus_sys_log("[zk u+] sys_res_area_write_2 ok:writeLen=%d offset=%d", writeLen, offset);
	uplus_file_close(fd);
	return 0;
}

int sys_res_area_read(uint32 offset, uint8 *buf, uint32 len)
{
	int32 fd = 0;
	char *file_name = "res_area";

	if(uplus_file_open(&fd, file_name, FILE_FLAGS_RDWR) < 0)
	{
		uplus_sys_log("[zk] uplus_config_read_0 open error name=%s", file_name);
		return -1;
	}
	
	uplus_file_seek(fd, offset, FILE_SEEK_SET);

	uint32 readeLen = uplus_file_read(fd, buf, len);
	if(readeLen != len)
	{
		uplus_file_close(fd);
		uplus_sys_log("[zk u+] sys_res_area_read_1 error:readeLen=%d len=%d offset=%d", readeLen, len, offset);
		return -1;
	}
	uplus_sys_log("[zk u+] sys_res_area_read_2 ok:readeLen=%d offset=%d", readeLen, offset);
	uplus_file_close(fd);
	return 0;
}

#define EPP_HEAD_LEN	46
//��������������������ʱ,��callback�ᱻ���ã���pkt_buf�а�����ȡ��͸�����װ�
uplus_s32 recv_server_data_callback(void *dev_handle, void *param, pkt_buf_t *pkt_buf)
{
	/**** �������ó���͸�����װ� ****/

	if((dev_handle == NULL) || (pkt_buf == NULL))
		return;

	//������������Ҫ��������������Ӧ��ʱ��Ҫ
	memset(&session, 0, sizeof(session_desc_t));
	sn = 0;
	memcpy(&session, &pkt_buf->info_res.session_desc, sizeof(session_desc_t));

	sn = pkt_buf->info_res.sn;

	//�������ݳ���
	uint32 len = pkt_buf->data_info.data.raw_data.data_len;
	if(len > EPP_HEAD_LEN)
	{
		//��������
		uint8 *data_buff = pkt_buf->data_info.data.raw_data.data+EPP_HEAD_LEN;

		uplus_sys_log("[zk u+] recv_server_data_callback_0 len=%d", len);
		task_msg_send(u_server_task_handle, UPLUS_SDK_RECV_MSG, data_buff, len-EPP_HEAD_LEN);
	}

	pkt_buf->data_info.free(&pkt_buf->data_info);

	pkt_buf->free(pkt_buf);
	
}

//�����������п�����������ʱ����callback�ᱻ���ã���valָ���а�����ȡ��͸�����װ�
uplus_s32 recv_server_CtrData_callback(void *dev_handle, uplus_s32 ctrl_type, void *val)
{
	/**** �������ó���͸�����װ� ****/

	//task_msg_send(u_server_task_handle, UPLUS_SDK_RECV_MSG, val, 1);

	uint8 *p = (uint8*)val;
	uplus_sys_log("[zk] recv_server_callback_0 ctrType=%d val=%d", ctrl_type, *p);
}

static void pkt_data_free(struct data_info * DataInfo)
{
	if(DataInfo != NULL)
	{
		if(DataInfo->data.raw_data.data != NULL)
		{
			iot_os_free(DataInfo->data.raw_data.data);
			DataInfo->data.raw_data.data = NULL;
			DataInfo->data.raw_data.data_len = 0;
		}
	}
}

//�¼��ϱ��������żҷ�����
void Haier_EventNotifyServer(uint8 dir, uint8 data_sub_type, uint8 *appData, uint32 appDataLen)
{
	uint16 len = appDataLen+2;
	uint8 *databuff = NULL;

	if((appData == NULL) || (appDataLen == 0))
		return;

	if(get_sye_state() == SYS_STATE_RUN)
	{
		if(get_net_state() == NETWORK_LINKED)
		{
			databuff = (uint8 *)iot_os_malloc(len);
			if(databuff == NULL)
			{
				uplus_sys_log("[zk] Haier_EventNotifyServer_0 malloc fail len=%d", len);
				return ;
			}
			memset(databuff, 0, len);
			
			databuff[0] = dir;
			databuff[1] = data_sub_type;
			
			memcpy(databuff+2, appData, appDataLen);

			task_msg_send(u_server_task_handle, UPLUS_SDK_SEND_MSG, databuff, len);

			iot_os_free(databuff);
		}
	}
}


//��������Ҫ���͵�������ʱ�����ô˽ӿ�
void send_server_data(uint8 dir, uint8 data_sub_type, uint8 *buff, uint32 len)
{	
	if((buff == NULL) || (len == 0))
		return;
	
	pkt_buf_t *pkt_buf = NULL;
	
	//����һ��pkt_buf���ڷ�������
	if(pkt_buf_list != NULL)
	{
		pkt_buf = uplus_pkt_buf_malloc(pkt_buf_list);
		if(pkt_buf == NULL)
		{
			uplus_sys_log("[zk u+] send_server_data_1:malloc pkt_buf fail");
			return;
		}
	}
	else
	{
		uplus_sys_log("[zk u+] send_server_data_2:pkt_buf_list is NULL");
		return;
	}

	//pkt_buf->data_info.data_type = DATA_TYPE_NONE;
	pkt_buf->data_info.free = pkt_data_free;

	uint8 *data = iot_os_malloc(len);
	if(data == NULL)
	{
		pkt_buf->free(pkt_buf);
		uplus_sys_log("[zk u+] send_server_data:malloc fail");
		return;
	}
	memset(data, 0, len);
	pkt_buf->data_info.data.raw_data.data = data;
	pkt_buf->data_info.data.raw_data.data_len = len;

	pkt_buf->info_res.dir = dir;
	//�����ǰ���ݰ���Ӧ�����ͣ���ô��Ҫ������Щ��Ϣ���������·��ģ��������ϱ�����Ҫ
	if(PKT_BUF_DIR_RSP == dir)
	{
		memcpy(&pkt_buf->info_res.session_desc, &session, sizeof(session_desc_t));
		pkt_buf->info_res.sn = sn;
	}
	pkt_buf->data_info.data_type = DATA_TYPE_EPP;
	pkt_buf->data_info.data_sub_type = data_sub_type;

	memcpy(data, buff, len);
	
	/*****    pkt_buf����Ԫ�ظ�ֵ     *****/
	
	//ָ����һ��pkt_buf����null
	/*pkt_buf->next = NULL;
	
	//uplusSDK�ڲ���pkt_bufָ��
	pkt_buf->pkt_buf_list = pkt_buf_list;
	
	//pkt_buf���ͷŽӿ�
	pkt_buf->free = uplus_pkt_buf_free;
	
	//���ݷ���
	pkt_buf->info_res.dir = dir;
	
	//E++Э��
	pkt_buf->info_res.device_protocol = DEVICE_PROTO_FAMILY_EPP;
	
	//�豸instance
	pkt_buf->info_res.instance = INSTANCE;
	
	//�����ǰ���ݰ���Ӧ�����ͣ���ô��Ҫ������Щ��Ϣ���������·��ģ��������ϱ�����Ҫ
	if(PKT_BUF_DIR_RSP == dir)
	{
		memcpy(&pkt_buf->info_res.session_desc, &session, sizeof(session_desc_t));
		pkt_buf->info_res.sn = sn;
	}
	
	//��������ΪE++;
	pkt_buf->data_info.data_type = DATA_TYPE_EPP;
	
	//����������
	pkt_buf->data_info.data_sub_type = data_sub_type;

	uint8 *data_buff = (uint8*)iot_os_malloc(len);
	if(data_buff == NULL)
	{
		uplus_pkt_buf_free(pkt_buf);
		uplus_sys_log("[zk u+] send_server_data:malloc fail");
		return ;
	}
	//�ͷ�������Դ�ӿ�
	pkt_buf->data_info.free = pkt_data_free;
	
	//�������ݳ���
	pkt_buf->data_info.data.raw_data.data_len= len;
	
	//��������
	memcpy(data_buff, buff, len);
	pkt_buf->data_info.data.raw_data.data = data_buff;
	//memcpy(pkt_buf->data_info.data.raw_data.data, buff, len);

	
	/*****    ����pkt_buf     *****/
	
	if(uplus_dev_tx(device_handle, pkt_buf) == 0)
	{
		uplus_sys_log("[zk u+] send_server_data_:ok");
	}
	else
	{
		uplus_sys_log("[zk u+] send_server_data_:fail");
	}
}

static void u_sys_event_cb_func(uplus_u16 sys_event, void *param)
{
	switch(sys_event)
	{
		case SYS_EVENT_WIFI_CONFIG_MODE_ENTER:
			uplus_sys_log("[zk u+] u_sys_event_cb_4 exit wifi config start");
			//TASK_MSG* msgptr = iot_os_malloc(sizeof(TASK_MSG));
			//msgptr->id = 0xFF;
			//iot_os_send_message(network_task_handle,(void *)msgptr);
			break;
		case SYS_EVENT_CLOUD_START:
			uplus_sys_log("[zk u+] u_sys_event_cb_0 cloud Start...");
			break;
		case SYS_EVENT_CLOUD_OK:
			set_uplus_sdk_state(UPLUS_STATE_RUN);
			uplus_sys_log("[zk u+] u_sys_event_cb_1 conn cloud OK");
			break;
		case SYS_EVENT_CLOUD_FAIL:
			set_uplus_sdk_state(UPLUS_STATE_INIT_FAIL);
			uplus_sys_log("[zk u+] u_sys_event_cb_2 conn cloud fail");
			break;
		default:
			uplus_sys_log("[zk u+] u_sys_event_cb_3 sys_event=%d", sys_event);
			break;
	}
}

static uplus_s32 normal_start(init_config_para_t * init_config)
{
	uplus_s32 result = uplus_wifi_conn_net_init(&init_config->wifi_conn_config);

	uplus_sys_log("[zk u+] normal_start init resylt=%d", result);
	
	return result;
}

int32 uplus_usr_init(void)
{
	init_config_para_t * init_config;
	wifi_conn_config_para_t * wifi_conn_config;
	int32 ret;

	//call pal init
	ret = uplus_sys_init();
	if (ret)
	{
		uplus_sys_log("[zk u+] uplus_usr_init_1:sys_init fail");
		return ret;
	}

	init_config = (init_config_para_t *)uplus_tool_malloc(sizeof(*init_config));
	if (init_config == NULL)
	{
		uplus_sys_log("[zk u+] uplus_usr_init_2:malloc fail");
		return -1;
	}
	uplus_tool_memset(init_config, 0, sizeof(*init_config));

	
	uplus_tool_strncpy((uplus_s8 *)init_config->hw_ver, "U_2.0.01", strlen("U_2.0.01"));   
	uplus_tool_strncpy((uplus_s8 *)init_config->sw_ver, "e_2.7.02", strlen("e_2.7.02"));
	uplus_tool_strncpy(init_config->platform, "UDISCOVERY_UWT", strlen("UDISCOVERY_UWT"));
	uplus_tool_strncpy((uplus_s8 *)init_config->sdk_ver, "2.0.0", strlen("2.0.0"));
	uplus_tool_strncpy((uplus_s8 *)init_config->sdk_platform, "UDISCOVERY_UWT", strlen("UDISCOVERY_UWT"));
	
	init_config->watchdog_time = 250;

	init_config->max_client_num = UPLUS_CONFIG_MAX_CLIENT_NUM;
	init_config->conf_extend_block_num = UPLUS_CONFIG_CONF_EXTEND_BLOCK_NUM;
	init_config->max_wifi_scan_ap_num = UPLUS_CONFIG_MAX_WIFI_SCAN_AP_NUM;
	init_config->wifi_config_smartlink_time = UPLUS_CONFIG_WIFI_CONFIG_SMARTLINK_TIME;
	init_config->wifi_config_softap_time = UPLUS_CONFIG_WIFI_CONFIG_SOFTAP_TIME;
	init_config->wifi_config_smartap_time = UPLUS_CONFIG_WIFI_CONFIG_SMARTAP_TIME;
	init_config->wifi_config_third_time = UPLUS_CONFIG_WIFI_CONFIG_THIRD_TIME;
	init_config->wifi_config_smartlink_to_softap_time = UPLUS_CONFIG_WIFI_CONFIG_SMARTLINK_TO_SOFTAP_TIME;
	init_config->led_to_power_save_time = UPLUS_CONFIG_LED_TO_POWER_SAVE_TIME;
	init_config->product_mode_wifi_conn_time = UPLUS_CONFIG_PRODUCT_MODE_WIFI_CONN_TIME;
	init_config->watchdog_time = UPLUS_CONFIG_WATCHDOG_TIME;

	init_config->support_product_mode = UPLUS_CONFIG_SUPPORT_PRODUCT_MODE;
	init_config->enter_product_mode_power_on_without_wifi_conf = UPLUS_CONFIG_ENTER_PRODUCT_MODE_POWER_ON_WITHOUT_WIFI_CONF;
	init_config->smartlink_method_num = UPLUS_CONFIG_SMARTLINK_METHOD_NUM;
	init_config->softap_method_num = UPLUS_CONFIG_SOFTAP_METHOD_NUM;

	wifi_conn_config = &init_config->wifi_conn_config;
	uplus_tool_strncpy((uplus_s8 *)wifi_conn_config->vendor_id, UPLUS_CONFIG_VERDOR_ID, sizeof(wifi_conn_config->vendor_id));
	wifi_conn_config->fast_wifi_conn_interval = UPLUS_CONFIG_FAST_WIFI_CONN_INTERVAL;
	wifi_conn_config->fast_wifi_conn_time = UPLUS_CONFIG_FAST_WIFI_CONN_TIME;
	wifi_conn_config->slow_wifi_conn_interval = UPLUS_CONFIG_SLOW_WIFI_CONN_INTERVAL;
	wifi_conn_config->slow_wifi_conn_time = UPLUS_CONFIG_SLOW_WIFI_CONN_TIME;
	wifi_conn_config->ap_channel = UPLUS_CONFIG_AP_CHANNEL;
	wifi_conn_config->support_mon_softap = UPLUS_CONFIG_SUPPORT_MON_SOFTAP;

	//framework init
	ret = uplus_init(init_config);
	if(ret)
	{
		uplus_sys_log("[zk u+] uplus_usr_init_3:uplus_init fail");
		return ret;
	}
	
	/* do other init*/
	ret = normal_start(init_config);
	if (ret)
	{
		uplus_sys_log("[zk u+] uplus_usr_init_4:normal_start fail");
		return ret;
	}

	ret = uplus_start();
	
	uplus_sys_log("[zk u+] uplus_usr_init_8 uplus_start=%d", ret);
	
	/*ret = uplus_wifi_conf_other_enter();
	if(ret)
	{
		uplus_sys_log("[zk u+] uplus_usr_init_5:wifi_conf_other_enter fail");
		return ret;
	}*/
	
	iot_os_sleep(3000);
	ret = uplus_wifi_conf_notify(z_ssid, z_passwd);
	if(ret)
	{
		uplus_sys_log("[zk u+] uplus_usr_init_6:wifi_conf_notify fail");
		return ret;
	}
	/*uplus_sys_log("[zk u+] uplus_usr_init_9:exir config start");
	ret = uplus_wifi_conf_other_exit(1, z_ssid, z_passwd);
	if(ret)
	{
		uplus_sys_log("[zk u+] uplus_usr_init_7:wifi_conf_other_exit fail");
		return ret;
	}
	uplus_sys_log("[zk u+] uplus_usr_init_10:exir config end");*/
	return ret;
}

int uplus_server_init(void)
{
	/****�����ĳ�ʼ������****/
	
	//uplusSDK��ʼ��������
	if(uplus_usr_init() == -1)
	{
		uplus_sys_log("[zk u+] uplus_server_init_0 init fail");

		set_uplus_sdk_state(UPLUS_STATE_INIT_FAIL);
		
		return -1;
	}
	
	//��ȡuplusSDK�ڲ���PKT_BUFָ��                      
	pkt_buf_list = uplus_get_pkt_buf_list();
	if(pkt_buf_list != NULL)
	{
		//��ʼ��APP����Ҫ��PKT_BUF�������
		uplus_pkt_buf_list_init(pkt_buf_list, PKT_BUF_MAX);
	}

	//�����յ��װ���Ϣ
	memcpy(&device_ctr_info.dev_info, &dev, sizeof(dev_info_t)); 
	//memcpy(device_ctr_info.dev_info.proto_ver, "2.18", sizeof("2.18"));
	
	uplus_sys_log("[zk u+] type=%d", device_ctr_info.dev_info.type);
	uplus_sys_log("[zk u+] id=0x%x", device_ctr_info.dev_info.dev_id[31]);
	uplus_sys_log("[zk u+] sv=%s", device_ctr_info.dev_info.sw_ver);
	uplus_sys_log("[zk u+] hv=%s", device_ctr_info.dev_info.hw_ver);
	uplus_sys_log("[zk u+] pv=%s", device_ctr_info.dev_info.proto_ver);
	uplus_sys_log("[zk u+] name=%s", device_ctr_info.dev_info.dev_name);
	
	//��������ΪE++           
	device_ctr_info.data_type = DATA_TYPE_EPP | DATA_TYPE_EPP_WITH_PARA;
	
	//��Ҫ���ݸ�callback�Ĳ�����Ŀǰ����Ҫ����NULL
	device_ctr_info.param = NULL;
	
	//����Ҫ����ת�������
	device_ctr_info.convert = NULL;
	
	//����tx��callback���ж�Ӧ�¼�����ʱ�ᱻ���ã�
	device_ctr_info.tx = recv_server_data_callback;
	
	//����ctrl��callback���ж�Ӧ�¼�����ʱ�ᱻ���ã�
	device_ctr_info.ctrl = recv_server_CtrData_callback;
	
	//��uplusSDKע��һ���豸
	device_handle = uplus_dev_register(DEVICE_PROTO_FAMILY_EPP, INSTANCE, &device_ctr_info);
	if(device_handle == NULL)
	{
		uplus_sys_log("[zk u+] uplus_server_init_1 init fal");
		set_uplus_sdk_state(UPLUS_STATE_INIT_FAIL);
		return -1;
	}
	uplus_sys_log("[zk u+] uplus_server_init_1 init suc");
		
	//set_uplus_sdk_state(UPLUS_STATE_RUN);

	//֪ͨSDK���ն�����
	uplus_dev_status(device_handle, 1);

	uplus_sys_event_cb_set(u_sys_event_cb_func, NULL);
	
	return 0;
}

static void uplus_server_send_handle(uint8 *buff, uint16 len)
{
	if((buff == NULL) || (len == 0))
		return;
	
	uint8 dir = buff[0];
	uint8 data_sub_type = buff[1];

	uplus_sys_log("[zk u+] uplus_server_send_0 notify airdatalen=%d", len-2);
	
	zk_debug(buff+2, len-2);

	LEDState_Change(2, 100);
	send_server_data(dir, data_sub_type, buff+2, len-2);
}

static void uplus_server_recv_handle(uint8 *buff, uint16 len)
{
	zk_debug(buff, len);

	LEDState_Change(1, 200);
	
	task_msg_send(air_task_handle, SERVER_CTR_AIR_MSG, buff, len);
	
	uplus_sys_log("[zk u+] uplus_server_recv_1 recv");
}


uint8 fd_set1[4] = {1,2,3,4};
//uint8 fd_set2[4] = {4,3,2,1};
void fs_test(void)
{
	/*uplus_net_fd_zero((void *)fd_set1);
	
	uplus_net_fd_set(4, (void *)fd_set1);
	uplus_net_fd_set(5, (void *)fd_set1);

	uplus_sys_log("4 isset return:0x%x", uplus_net_fd_isset(4, (void *)fd_set1));
	uplus_sys_log("5 isset return:0x%x", uplus_net_fd_isset(5, (void *)fd_set1));

	uplus_net_fd_clr(4, (void *)fd_set1);
	uplus_net_fd_clr(5, (void *)fd_set1);*/

	struct uplus_in_addr zkaddr = {0};
	char ipaddr [] = "172.28.38.13";
	
	zkaddr.s_addr = uplus_net_inet_addr(ipaddr);

	uint32 host = uplus_net_ntohl(zkaddr.s_addr);

	uint32 net = uplus_net_htonl(host);
	
	char *p = uplus_net_inet_ntoa(zkaddr);

	uplus_sys_log("fs_test zkaddr=%x host=%x net=%x p=%s", zkaddr.s_addr, host, net, p);
	
}

void uplus_server_task_main(void *pParameter)
{
	TASK_MSG *msg = NULL;

	iot_os_sleep(3000);
	while(1)
	{
		iot_os_wait_message(u_server_task_handle, (PVOID*)&msg);
		switch(msg->id)
	    {
			case UPLUS_SDK_INIT_MSG:
				uplus_config_init();
				//iot_os_sleep(5000);
				
				T_AMOPENAT_SYSTEM_DATETIME datetime1;
				iot_os_get_system_datetime(&datetime1);
				
				uplus_sys_log("[zk u+]uplus_server_task_main_1 uplus sdk init %d-%d-%d %d:%d:%d", datetime1.nYear, datetime1.nMonth, datetime1.nDay, datetime1.nHour, datetime1.nMin, datetime1.nSec);
				
				uplus_server_init();
				break;
			case UPLUS_SDK_SEND_MSG:
				uplus_server_send_handle(msg->param, msg->len);
				break;
			case UPLUS_SDK_RECV_MSG:
				uplus_server_recv_handle(msg->param, msg->len);
				break;
	        default:
	            break;
	    }
		
	    if(msg)
	    {
	        if(msg->param)
	        {
	            iot_os_free(msg->param);
	            msg->param = NULL;
	        }
	        iot_os_free(msg);
	        msg = NULL;
			//uplus_sys_log("[zk u+] uplus_server_task_main_2 free");
	    }
	}
}

uplus_sem_id test_handle;

#define DNS1	"223.5.5.5"//"8.8.8.8"
#define DNS2	"223.6.6.6"//"114.114.114.114"

int get_host_by_ip(char *name, char *ipaddr)
{
	uint8 cnt = 0;
	if((name==NULL) || (ipaddr==NULL))
	{
		uplus_sys_log("[zk dns] get_host_by_ip parmer fail");
		return -1;
	}
	
    //��������
    struct openat_hostent *hostentP = NULL;
    char *ipAddr = NULL;

	while ((hostentP == NULL) && (cnt < 3))
	{
	    //��ȡ����ip��Ϣ
	    hostentP = gethostbyname(name);

	    cnt++;
	}
	if (!hostentP)
    {
        uplus_sys_log("[zk dns] gethostbyname %s fail", name);
		iot_os_restart();
        return -1;
    }

    // ��ipת�����ַ���
    ipAddr = ipaddr_ntoa((const openat_ip_addr_t *)hostentP->h_addr_list[0]);
	strcpy(ipaddr, ipAddr);
    
    uplus_sys_log("[zk dns] gethostbyname %s ip %s", name, ipaddr);

	return 0;
}

uint8 dns_state;
int dns_srver_config(void)
{
	uint8 cnt = 0;
	int ret = -1;
	CHAR nDns1[30] = {0}, nDns2[30] = {0};

	while((ret <0) && (cnt<3))
	{
		ret = setNetifDns(DNS1, DNS2);
		cnt++;
	}
	uplus_sys_log("[zk dns] setNetifDns ret: %d", ret);

	ret = -1;
	cnt = 0;
	while((ret <0) && (cnt<3))
	{
		ret = getNetifDns(nDns1, nDns2);
		cnt++;
	}
	
	uplus_sys_log("[zk dns] getNetifDns ret: %d nDns1: %s, nDns2: %s", ret, nDns1, nDns2);

	dns_state = 1;
	
	return ret;
}

char* name[]={"www.baidu.com", "www.sougou.com", "www.wechat.com", "im.qq.com"};
char Ip_Addr[30];
uint8 index;
void uplus_server_test_task(void *pParameter)
{
	uplus_os_sem_create(&test_handle);
	iot_os_sleep(3000);
	while(1)
	{
		uplus_os_sem_take(test_handle, 0);

		//uplus_sys_log("[zk u+] uplus_server_test_task_1 test_task run...");
		if(dns_state == 0)
			dns_srver_config();
		else
		{
			get_host_by_ip(name[index], Ip_Addr);
			if((++index) > 3)
				index = 0;
		}
	}
}



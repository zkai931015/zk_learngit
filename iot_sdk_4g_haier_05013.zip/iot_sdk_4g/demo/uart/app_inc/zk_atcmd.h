#ifndef _ZK_ATCMD_H_
#define _ZK_ATCMD_H_

#include "haier_appmain.h"

#define APP_AT_STR_OK                 "OK"
#define APP_AT_STR_ERROR              "ERROR"
#define APP_AT_STR_TRUE               "TRUE"
#define APP_AT_STR_FALSE              "FALSE"

#define _AT_CMD_CR                     '\r'
#define _AT_CMD_LF                     '\n'
#define AT_CMD_WHITE_SPACE            ' '
#define AT_CMD_END_MARK               '\0'
#define AT_CMD_EQUAL_MARK             '='
#define AT_CMD_QUESTION_MARK          '?'
#define AT_CMD_DOUBLE_QUOTATION       '\"'
#define AT_CMD_PARAM_SEPARATOR        ','
#define AT_CMD_SEPARATOR              ';'

#define AT_CMD_PREFIX                 "AT"
#define AT_CMD_PREFIX_LEN             2


typedef enum
{
	AT_RET_OK							= 0x00,
	AT_RET_SYNTAX_ERROR 				= 0x01,
	AT_RET_NOT_NUMERIC				= 0x02,
	AT_RET_PARAM_MISSING				= 0x03,
	AT_RET_MEMORY_ERROR 				= 0x04,
	AT_RET_CMD_IN_PROGRESS			= 0x05,
	AT_RET_PROGRESS_ERROR				= 0x06,
	AT_RET_FLOW_CONTROL 				= 0x07,
	AT_RET_PARAM_UNCONFIG				= 0x08,
	AT_RET_INTERNAL_ERROR				= 0x0D,

	AT_RET_NOT_AT_CMD_ERROR			= 0x0E
  
} AT_RET;

/** At command set callback
 * @param at_string The at string parameter to parse
 * @return result or at command
 */
typedef AT_RET ( *at_cmd_set) (uint8 *at_string);

/** At command read callback
 * @return result or at command
 */
typedef AT_RET ( *at_cmd_read) (void);

/** At command test callback
 * @return result or at command
 */
typedef AT_RET ( *at_cmd_test) (void);

/** At command execute callback
 * @return result or at command
 */

typedef AT_RET ( *at_cmd_exec) (void);

typedef struct
{
    char *cmd_str;  //command string

    at_cmd_set at_set_handler;
    at_cmd_read at_read_handler;
    at_cmd_test at_test_handler;
    at_cmd_exec at_exec_handler;
	
}AT_CMD_CB_s;


struct AT_CMD_CB_node
{
    AT_CMD_CB_s at_cmd_cb;
    struct AT_CMD_CB_node* next;
};

/**
 * @Get registered at cmd table address.
 * @return The address of registerable at cmd table
 */
struct AT_CMD_CB_node * at_get_registered_cmd_table_address(void);

/**
 * @register new at cmd .
 * @param at_cmd_cb the pointer of the at cmd param,at_cmd_cb.cmd_str should always using '+'as first char.should
            not include '=','?',';',or will not parse correctly.
 * @return The result of register, successful: true, fail:false
 */
bool at_cmd_register(const AT_CMD_CB_s* at_cmd_cb);

void at_main_handle(uint8 *p_str, uint16 len);


#endif


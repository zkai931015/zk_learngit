#include "string.h"
#include "iot_os.h"
#include "iot_debug.h"

#define datetime_print iot_debug_print

VOID demo_set_system_datetime()
{
	T_AMOPENAT_SYSTEM_DATETIME* pDatetime;

	pDatetime = iot_os_malloc(sizeof(T_AMOPENAT_SYSTEM_DATETIME));

	pDatetime->nYear = 2019;
	pDatetime->nMonth = 8;
	pDatetime->nDay = 21;
	pDatetime->nHour = 10;
	pDatetime->nMin = 33;
	pDatetime->nSec = 55;

	iot_os_set_system_datetime(pDatetime);

	iot_os_free(pDatetime);
}

VOID demo_get_system_datetime()
{
	T_AMOPENAT_SYSTEM_DATETIME* pDatetime;
	
  	pDatetime = iot_os_malloc(sizeof(T_AMOPENAT_SYSTEM_DATETIME));

  	iot_os_get_system_datetime(pDatetime);

  	iot_os_free(pDatetime);	
	
}

VOID demo_system_datetime(VOID)
{
    //1. ����ϵͳʱ��
    demo_set_system_datetime();

    //2. ��ȡϵͳʱ��
    demo_get_system_datetime();
}

VOID app_main(VOID)
{
    datetime_print("[datetime] app_main");

    demo_system_datetime();
}
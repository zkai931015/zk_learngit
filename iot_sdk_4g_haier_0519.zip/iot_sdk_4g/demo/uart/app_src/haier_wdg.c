#include "haier_wdg.h"

void wdg_reset(void)
{
	iot_gpio_set(WDG_REST_IN_PIN, FALSE);
	iot_os_sleep(100);
	iot_gpio_set(WDG_REST_IN_PIN, TRUE);
}

int8 wdg_feed(void)
{
	//这句其实加不加都可以，为了确保喂狗之前，WDI是高电平（因为要产生一个低脉冲来喂狗）
	iot_gpio_set(WDG_REST_IN_PIN, TRUE);
	
	iot_gpio_set(WDG_REST_IN_PIN, FALSE);
	iot_os_sleep(200);
	iot_gpio_set(WDG_REST_IN_PIN, TRUE);  //喂狗之后，就把电平拉回来

	return 0;
}

int8  wdg_init(VOID)
{
	T_AMOPENAT_GPIO_CFG  output_cfg;
	BOOL err;
	
	memset(&output_cfg, 0, sizeof(T_AMOPENAT_GPIO_CFG));
	
	output_cfg.mode = OPENAT_GPIO_OUTPUT; //输出
	output_cfg.param.defaultState = TRUE; // 默认高电平

	err = iot_gpio_config(WDG_REST_IN_PIN, &output_cfg);
	if (!err)
		return -1;
	err = iot_gpio_config(WDG_WDI_PIN, &output_cfg);
	if (!err)
		return -1;
	
	wdg_reset();
	return 0;
}



#include "zk_atcmd.h"
#include "zk_at_utils.h"

static struct AT_CMD_CB_node* at_cmd_registered_table;

static void at_responce_handle(char *at_string, uint16 stringLen)
{
	if((at_string == NULL) || (stringLen == 0))
		return;
	
	bt_uart_write(at_string, stringLen);
}

/*********************** RESET START**************************/
AT_RET at_handle_RESET_cmd_read(void)
{
	char string[15] = {0};
	
	snprintf(string, sizeof(string), "%s%d", "+RESET:", local.rest_num);

	uplus_sys_log("[zk at] at_handle_RESET_cmd_read:%s", string);
	
	at_responce_handle(string, strlen(string)+1);
	
	return AT_RET_OK;
}

AT_RET at_handle_RESET_cmd_exec()
{
	uplus_sys_log("[zk at] at_handle_RESET_cmd_exec");

	iot_os_restart();
	
	return AT_RET_OK;
}


/*********************** FOTA START**************************/
extern void write_local_cfg_Info(void);
AT_RET at_handle_FOTA_cmd_set(uint8 *at_string)
{
	AT_RET cause = AT_RET_SYNTAX_ERROR;
	uint8 num_recvparams = 0;

	uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_0:%s", at_string);

	cause = at_create_param_array(at_string, &num_recvparams, 1, 4);
	if(cause != AT_RET_OK)
    {
        return cause;
    }

	if(num_recvparams == 1)
	{
		cause = at_get_string_param(AT_PARSE_FIRST_PARAM_POS, local.ota_file_name, sizeof(local.ota_file_name), 1);
		uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_1:cause=%d file_name=%s", cause, local.ota_file_name);
		if(cause != AT_RET_OK)
	    {
	        return AT_RET_SYNTAX_ERROR;
	    }
	}
	else if(num_recvparams == 3)
	{
		cause = at_get_string_param(AT_PARSE_FIRST_PARAM_POS, local.ftp_addr, sizeof(local.ftp_addr), 1);
		uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_2:cause=%d ftp_addr=%s", cause, local.ftp_addr);
	    if(cause != AT_RET_OK)
	    {
	        return AT_RET_SYNTAX_ERROR;
	    }
		cause = at_get_string_param(AT_PARSE_SECOND_PARAM_POS, local.user_name, sizeof(local.user_name), 1);
		uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_3:cause=%d user_name=%s", cause, local.user_name);
	    if(cause != AT_RET_OK)
	    {
	        return AT_RET_SYNTAX_ERROR;
	    }
		cause = at_get_string_param(AT_PARSE_THIRD_PARAM_POS, local.user_passwod, sizeof(local.user_passwod), 1);
		uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_4:cause=%d user_passwod=%s", cause, local.user_passwod);
		if(cause != AT_RET_OK)
	    {
	        return AT_RET_SYNTAX_ERROR;
	    }
	}
	else if(num_recvparams == 4)
	{
		cause = at_get_string_param(AT_PARSE_FIRST_PARAM_POS, local.ftp_addr, sizeof(local.ftp_addr), 1);
		uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_5:cause=%d ftp_addr=%s", cause, local.ftp_addr);
	    if(cause != AT_RET_OK)
	    {
	        return AT_RET_SYNTAX_ERROR;
	    }
		cause = at_get_string_param(AT_PARSE_SECOND_PARAM_POS, local.user_name, sizeof(local.user_name), 1);
		uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_6:cause=%d user_name=%s", cause, local.user_name);
	    if(cause != AT_RET_OK)
	    {
	        return AT_RET_SYNTAX_ERROR;
	    }
		cause = at_get_string_param(AT_PARSE_THIRD_PARAM_POS, local.user_passwod, sizeof(local.user_passwod), 1);
		uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_7:cause=%d user_passwod=%s", cause, local.user_passwod);
		if(cause != AT_RET_OK)
	    {
	        return AT_RET_SYNTAX_ERROR;
	    }
		cause = at_get_string_param(AT_PARSE_FOURTH_PARAM_POS, local.ota_file_name, sizeof(local.ota_file_name), 1);
		uplus_sys_log("[zk at] at_handle_FOTA_cmd_set_8:cause=%d file_name=%s", cause, local.ota_file_name);
		if(cause != AT_RET_OK)
	    {
	        return AT_RET_SYNTAX_ERROR;
	    }
	}
	
	//дFOTA������Ϣ���ļ�ϵͳ
	write_local_cfg_Info();
	
	at_free_at_params();
	
	return AT_RET_OK;
}

AT_RET at_handle_FOTA_cmd_read(void)
{	
	char string[120] = {0};
	
	snprintf(string, sizeof(string), "+FOTA:%s,%s,%s,%s", local.ftp_addr, local.user_name, local.user_passwod, local.ota_file_name);
	
	uplus_sys_log("[zk at] at_handle_FOTA_cmd_read:%s", string);

	at_responce_handle(string, strlen(string)+1);
	
	return AT_RET_OK;
}

AT_RET at_handle_FOTA_cmd_exec(void)
{
	uplus_sys_log("[zk at] at_handle_FOTA_cmd_exec");

	local.fota_flag = 1;
	local.fota_fail_ret_num = 0;

	//дFOTA������Ϣ���ļ�ϵͳ
	write_local_cfg_Info();

	//��ʱһ����ʱ���ڸ�λ
	//iot_os_sleep(1000);
	//ִ��FOTAǰ���ȸ�λ���ų�һЩ��������
	iot_os_restart();

	//task_msg_send(ota_task_handle, FOTA_START_MSG, NULL, 0);
	
	return AT_RET_OK;
}

/*********************** CGMR START**************************/

AT_RET at_handle_CGMR_cmd_exec(void)
{
	uplus_sys_log("[zk at] at_handle_CGMR_cmd_exec:ver=%s", APP_SOFTWARE_VERSION);
	
	at_responce_handle(APP_SOFTWARE_VERSION, strlen(APP_SOFTWARE_VERSION));
	
	return AT_RET_OK;
}


const AT_CMD_CB_s zk_at_cmd_table[] =
{
/*//PS attach or detach
{"+CGATT", at_handle_CGATT_cmd_set,at_handle_CGATT_cmd_read,NULL,NULL},
//clear stored EARFCN
{"+NCSEARFCN", NULL, NULL, NULL, at_handle_NCSEARFCN_cmd_exec},
//Query UE Status
{"+NUESTATS", at_handle_UE_STATS_cmd_set, NULL, at_handle_UE_STATS_cmd_test, at_handle_UE_STATS_cmd_exec},
//Set Phone Functionality
{"+CFUN", at_handle_CFUN_cmd_set, at_handle_CFUN_cmd_read,at_handle_CFUN_cmd_test, NULL},
//Query IMSI
{"+CIMI", NULL, NULL, at_handle_CIMI_cmd_test, at_handle_CIMI_cmd_exec},
//Query signal quanlity UE received
{"+CSQ", NULL, NULL, at_handle_CSQ_cmd_test, at_handle_CSQ_cmd_exec},
//Query camped cell information(PLMN ,PCI)
{"+CEREG", at_handle_CEREG_cmd_set, at_handle_CEREG_cmd_read, at_handle_CEREG_cmd_test, NULL},
//Query UE IP address assgined by core network
{"+CGPADDR", at_handle_CGPADDR_cmd_set,NULL, at_handle_CGPADDR_cmd_test, at_handle_CGPADDR_cmd_exec},
//Clock
{"+CCLK", at_handle_CCLK_set, at_handle_CCLK_cmd_read,at_handle_CCLK_cmd_test, NULL},
//Get Card Identification
{"+NCCID", NULL,at_handle_NCCID_cmd_read,at_handle_NCCID_cmd_test, at_handle_NCCID_cmd_exc},
//Manufacturer information
{"+CGMI", NULL, NULL, at_handle_CGMI_cmd_test, at_handle_CGMI_cmd_exec},
//Config Serial Number
{"+CGSN", at_handle_CGSN_cmd_set, NULL, at_handle_CGSN_cmd_test, at_handle_CGSN_cmd_exec},
//Manufacturer model information
{"+CGMM", NULL, NULL, at_handle_CGMM_cmd_test, at_handle_CGMM_cmd_exec},*/
//Manufacturer revision
{"+CGMR", NULL, NULL, NULL, at_handle_CGMR_cmd_exec},
//reboot
{"+RESET", NULL, at_handle_RESET_cmd_read, NULL, at_handle_RESET_cmd_exec},
{"+FOTA", at_handle_FOTA_cmd_set, at_handle_FOTA_cmd_read, NULL, at_handle_FOTA_cmd_exec},

};

uint8 at_get_cmd_table_size(void)
{
    uint8 table_size;

    table_size = sizeof(zk_at_cmd_table)/sizeof(AT_CMD_CB_s);

    return table_size;
}

const AT_CMD_CB_s * at_get_cmd_table_address(void)
{
    return zk_at_cmd_table;
}

struct AT_CMD_CB_node * at_get_registered_cmd_table_address(void)
{
    return at_cmd_registered_table;
}

void app_at_cmd_init(void)
{
    uint8 table_size;
    uint8 i;
    static bool initialed = 0;

    if (initialed)
    {
        return;
    }

    table_size = at_get_cmd_table_size();
    for (i = 0; i < table_size; i++)
    {
        (void)at_cmd_register(&zk_at_cmd_table[i]);
    }
    initialed = 1;

    return;
}

/**
 * @register new at cmd .
 * @param at_cmd_cb pointer of the at cmd param,at_cmd_cb.cmd_str should always using '+'as first char.should
            not include '=','?',';',or will not parse correctly.
 * @return The result of register, successful: true, fail:false
 */
uint8 at_cmd_register(const AT_CMD_CB_s* at_cmd_cb)
{
    struct AT_CMD_CB_node* current_at_cmd_registered_node, *new_at_cmd_node;

    if ((at_cmd_cb == NULL) || (at_cmd_cb->cmd_str == NULL) || (at_cmd_cb->cmd_str[0] != '+'))
    {
        return 0;//lint !e527
    }

    if ((at_cmd_cb->at_read_handler == NULL) && (at_cmd_cb->at_set_handler == NULL) 
        && (at_cmd_cb->at_exec_handler == NULL) && (at_cmd_cb->at_test_handler == NULL))
    {
        return 0;//lint !e527
    }
    new_at_cmd_node = iot_os_malloc(sizeof(struct AT_CMD_CB_node));
    if (new_at_cmd_node == NULL)
    {
        return 0;//lint !e527
    }

    memcpy((void*)(&new_at_cmd_node->at_cmd_cb), (void*)at_cmd_cb, sizeof(AT_CMD_CB_s));
    new_at_cmd_node->at_cmd_cb.cmd_str = iot_os_malloc(strlen(at_cmd_cb->cmd_str) + 1);//copy the '\0' too.
    if (new_at_cmd_node->at_cmd_cb.cmd_str == NULL)
    {
        iot_os_free(new_at_cmd_node);
        return 0;//lint !e527
    }

    memcpy((void*)new_at_cmd_node->at_cmd_cb.cmd_str, (void*)at_cmd_cb->cmd_str, strlen(at_cmd_cb->cmd_str) + 1);//copy the '\0' too.
    new_at_cmd_node->next = NULL;

	HANDLE Section = iot_os_enter_critical_section();
   // non_os_enter_critical();
    if (at_cmd_registered_table == NULL)
    {
        at_cmd_registered_table = new_at_cmd_node;
        //non_os_exit_critical();
        iot_os_exit_critical_section(Section);
        return 1;
    }

    current_at_cmd_registered_node = at_cmd_registered_table;
    while(current_at_cmd_registered_node->next != NULL)
    {
        current_at_cmd_registered_node = current_at_cmd_registered_node->next;
    }
    current_at_cmd_registered_node->next = new_at_cmd_node;
	
    //non_os_exit_critical();
    iot_os_exit_critical_section(Section);

    return 1;
}

const AT_CMD_CB_s * at_get_atcmd_cb_from_atstring(uint8 *p_atstring, uint16 *len)
{
    const AT_CMD_CB_s     *cmd_cb;
    const AT_CMD_CB_s     *p_at_cmd_table = at_get_cmd_table_address();
    struct AT_CMD_CB_node  *current_at_cmd_registered_node = at_get_registered_cmd_table_address();
    uint16           i, at_cmd_length;
    uint8            count;

    count = at_get_cmd_table_size();
    at_cmd_length = at_get_cmd_name_length(p_atstring);

    for(i = 0; i < at_cmd_length; i++)
    {
        *(p_atstring + i) = (uint8) toupper( *(p_atstring + i));//nt !e1058
    }

    for( i = 0; i < count; i++)
    {
        cmd_cb = &(p_at_cmd_table[i]);
        if( ((strncmp(cmd_cb->cmd_str, p_atstring, strlen(cmd_cb->cmd_str) )) == 0)
            && (at_cmd_length == strlen(cmd_cb->cmd_str)))
        {
            *len = (uint16)strlen(cmd_cb->cmd_str);
            return cmd_cb;
        }
    }

    while(current_at_cmd_registered_node != NULL)
    {
        cmd_cb = &(current_at_cmd_registered_node->at_cmd_cb);
        if( ((strncmp(cmd_cb->cmd_str, p_atstring, strlen(cmd_cb->cmd_str) )) == 0)
            && (at_cmd_length == strlen(cmd_cb->cmd_str)))
        {
            *len = (uint16)strlen(cmd_cb->cmd_str);
            return cmd_cb;
        }
        current_at_cmd_registered_node = current_at_cmd_registered_node->next;
    }

    return NULL;
}

//extern void at_free_at_params(void);
static AT_RET at_perform_atcommand(uint8 *p_str)
{
    uint16              at_cmd_len;
    uint8              *str;
    const AT_CMD_CB_s  *cmd_cb;
    AT_RET              cause = AT_RET_SYNTAX_ERROR;
    
    str = p_str;
    cmd_cb = at_get_atcmd_cb_from_atstring(str, &at_cmd_len);
    if(cmd_cb)
    {
        str += at_cmd_len; //=1,2,3

        // Read command
        if(*str == '?' && (*(str + 1) == '\0'))
        {
            if(cmd_cb->at_read_handler)
            {
                cause = (cmd_cb->at_read_handler)();
            }
        }
        //Test command
        else if ((*str == '=') && ( *(str + 1) == '?') && (*(str + 2) == '\0'))
        {
            if(cmd_cb->at_test_handler)
            {
                cause = (cmd_cb->at_test_handler)();
            }
        }
        // set cmd
        else if(*str == '=')
        {
            str++; //1,2,3
            if(cmd_cb->at_set_handler)
            {
                cause = (cmd_cb->at_set_handler)(str);
            //    at_free_at_params();
            }
        }
        //excute cmd
        else if(cmd_cb->at_exec_handler)
        {
            cause = (cmd_cb->at_exec_handler)();
        }
        return cause;
    }
	uplus_sys_log("[zk at]at_cmd no mismatch");
    return AT_RET_NOT_AT_CMD_ERROR;
}

static AT_RET at_process_atcommand_string(uint8 *p_str)
{
    uint16 count;
    uint8 *str;
    AT_RET  cause;
	
    str = p_str;
    for(count = 0; count < AT_CMD_PREFIX_LEN; count++)
    {
        *(str + count) = (uint8) toupper( *(str + count));//lint !e1058 !e866
    }

    if(strncmp( AT_CMD_PREFIX, str, AT_CMD_PREFIX_LEN) != 0)
    {
    	uplus_sys_log("[zk at] not at cmd");
        return AT_RET_SYNTAX_ERROR;
    }

    if(strlen(str) == AT_CMD_PREFIX_LEN)
    {
        return AT_RET_OK;
    }

    str = str + AT_CMD_PREFIX_LEN; //+CABCD=1,2,3;+CDE=4,5
    cause = at_perform_atcommand(str);

    return cause;
}

void at_main_handle(uint8 *p_str, uint16 len)
{
	if(at_process_atcommand_string(p_str) == AT_RET_OK)
	{
		at_responce_handle("OK", sizeof("OK"));
		
	}
	else
	{
		uplus_sys_log("[zk at] at_main_handle:error");
		
		at_responce_handle("ERROR", sizeof("ERROR"));
	}
}



#ifndef    _HAIER_BT_H_
#define    _HAIER_BT_H_

#include "haier_appmain.h"

#define BT_REST_PIN 	26
#define BT_MODE_PIN 	27
#define BT_CONN_PIN	28

#define BT_NAME_TEST		"ZhangKai"
#define BT_NAME				"U-AC-"		

#define BT_MODE_CTR(x)	 iot_gpio_set(BT_MODE_PIN, x)

//bt cmd table
#define  BT_SET_BAUD		0x01
#define  BT_SET_NAME		0x07
#define	 BT_GET_NAME		0x08
#define  BT_SET_BROADCAST 0x0D
#define  BT_GET_BROADCAST	0x0E
#define	 BT_GET_MAC		0x18

#define BT_UART_PORT				OPENAT_UART_1
#define BT_UART_RECV_TIMEOUT 		(5 * 1000) 

#define BT_UART_RECV_BLOCK		32
#define BT_UART_RECVBUFF_MAX		320

#define BT_RECV_TIMEOUT   			50 //30ms


typedef struct
{
	uint8 recv_start;
	uint8 recv_timeout;
	uint16 recvLen;
	uint8 recvbuff[BT_UART_RECVBUFF_MAX];
	
}bt_uart_recv1;


extern void bt_task_main(void *pParameter);
extern void bt_recv_task_main(void *pParameter);
extern void bt_uart_timer_callback(void *argument);

#endif


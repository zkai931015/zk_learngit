#ifndef    _HAIER_WDG_H_
#define    _HAIER_WDG_H_

#include "haier_appmain.h"

#define	VAT_RESEND_NUM_MAX	3

#define USER_IDENTIFIER		"USER:"

#define APN_DIANXIN			"CTNET"  
#define APN_YIDONG				"CMNET" // CMMET CMIOT
#define APN_LIANTONG			"gmtds"  //3gnet wonet gmtds

#define VAT_CFUN				"AT+CFUN="

#define VAT_CSQ					"AT+CSQ\r\n"
#define VAT_CSQ_ACK			"+CSQ:"

#define VAT_IMEI				"AT+WIMEI?\r\n"
#define VAT_IMEI_ACK			"+WIMEI:"

#define VAT_ICCID				"AT+ICCID\r\n"
#define VAT_ICCID_ACK			"+ICCID: "

#define	VAT_CIMI				"AT+CIMI\r\n"
#define	VAT_CIMI_ACK			"454"

#define VAT_CGPADDR		 	"AT+CGPADDR\r\n"
#define	VAT_CGPADDR_ACK		"+CGPADDR:"

#define VAT_EEMOPT				"AT+EEMOPT=1\r\n"

#define VAT_EEMGINFO			"AT+EEMGINFO?\r\n"
#define	VAT_EEMGINFO_ACK		"+EEMLTESVC:"

#define VAT_CNTP				"AT+CNTP\r\n"
#define VAT_CNTP_ACK			"+CNTP:"

extern void network_task_main(void *pParameter);
extern void vat_send_handle(char * pCmd, uint16 length);
extern VOID vat_recv_handle(UINT8 *pData, UINT16 length);
extern uint8 get_net_state(void);
extern void get_module_ipaddr(void);
extern void get_module_net_info(void);

#endif


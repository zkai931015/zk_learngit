
/**
 * @file uplus_monitor_reboot_extern.h
 * @brief
 *
 * @date 2017-11-13
 * @author fanming
 *
 */

#ifndef __UPLUS_MONITOR_REBOOT_EXTERN_H__
#define __UPLUS_MONITOR_REBOOT_EXTERN_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @brief
 * @param
 * @return
 */
extern uplus_s32 uplus_monitor_reboot_init(void);

#ifdef __cplusplus
}
#endif

#endif /*__UPLUS_MONITOR_REBOOT_EXTERN_H__*/



/**
 * @file pal_os.c
 * @brief
 *
 * @date
 * @author
 *
 */

#include "pal_common.h"

/*!
 * \brief 创建任务。
 * \param [in] name 任务名称，以‘\0’结尾的字符串。
 * \param [in] stack_size 任务栈大小，单位字节。仅包含uplugSDK占用的栈空间，PAL占用的栈空间需要额外计算。
 * \param [in] priority 任务优先级，取值0-7，共8个优先级，0最高。
 * \param [in] func 任务处理函数。
 * \param [in] para 函数参数。
 * \param [out] id 如果创建成功，返回创建的任务ID，任务ID不能为NULL；否则不填写。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_task_create(uplus_s8 * name
										, uplus_u32 stack_size
										, uplus_u8 priority
										, task_func func
										, void *para
										, uplus_task_id *id)
{
	uplus_sys_log("[zk u+] task_creat name=%s prio=%d stack_size=%d", name, priority, stack_size);
	HANDLE task_handle = iot_os_create_task((PTASK_MAIN)func, para, stack_size, priority+4, OPENAT_OS_CREATE_DEFAULT, name);
	if(OPENAT_INVALID_HANDLE != task_handle)
	{
		*id = (uplus_task_id)task_handle;
		return 0;
	}
	else
	{
		return -1;
	}
}					

/*!
 * \brief 删除任务。
 * \param [in] id 任务ID（成功创建任务返回的任务ID）。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_task_delete(uplus_task_id id)
{
	HANDLE task_handle = (HANDLE)id;
	
	if(iot_os_delete_task(task_handle) == TRUE)
		return 0;
	else
		return -1;
}

/*!
 * \brief 任务睡眠（当前任务）。
 * \param [in] delay 任务睡眠时间，单位毫秒。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_task_sleep(uplus_u32 delay)
{
	//uplus_sys_log("[zk u+] os_task_sleep time=%d", delay);
	if(iot_os_sleep(delay) == TRUE)
		return 0;
	else
		return -1;
}

/*!
 * \brief 创建互斥信号量。
 * \param [out] id 如果创建成功，返回创建的信号量ID；否则不填写。信号量ID不能为NULL。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_mutex_create(uplus_mutex_id *id)
{
	HANDLE sem_id = iot_os_create_semaphore(1);
	if(sem_id != OPENAT_INVALID_HANDLE)
	{
		*id = (uplus_mutex_id)sem_id;
		return 0;
	}
	else
		return -1;
}

/*!
 * \brief 获取互斥信号量。
 * \param [in] id 信号量ID。
 * \param [in] time_wait 等待操作，TIME_NO_WAIT、TIME_WAIT_FOREVER或者等待时间（单位毫秒）。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_mutex_take(uplus_mutex_id id, uplus_s32 time_wait)
{ 
	HANDLE sem_id = (HANDLE)id;
	UINT32 nTimeOut;

	if(time_wait < 5)
		nTimeOut = 0;
	else if(time_wait >= 5)
		nTimeOut = time_wait;
	if(iot_os_wait_semaphore(sem_id, nTimeOut) == TRUE)
		return 0;
	else
		return -1;
}

/*!
 * \brief 释放互斥信号量。
 * \param [in] id 信号量ID。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_mutex_give(uplus_mutex_id id)
{
	HANDLE sem_id = (HANDLE)id;

	if(iot_os_release_semaphore(sem_id) == TRUE)
		return 0;
	else
		return -1;
}

/*!
 * \brief 删除互斥信号量。
 * \param [in] id 信号量ID。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_mutex_delete(uplus_mutex_id id)
{
	HANDLE sem_id = (HANDLE)id;

	if(iot_os_delete_semaphore(sem_id) == TRUE)
		return 0;
	else
		return -1;
}

/*!
 * \brief 创建同步信号量。
 * \param [out] id 如果创建成功，返回创建的信号量ID；否则不填写。信号量ID不能为NULL。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_sem_create(uplus_sem_id *id)
{
	HANDLE sem_id = iot_os_create_semaphore(0);
	if(sem_id != OPENAT_INVALID_HANDLE)
	{
		*id = (uplus_sem_id)sem_id;
		return 0;
	}
	else
		return -1;
}

/*!
 * \brief 获取同步信号量。
 * \param id 信号量ID。
 * \param [in] time_wait 等待操作，TIME_NO_WAIT、TIME_WAIT_FOREVER或者等待时间（单位毫秒）。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_sem_take(uplus_sem_id id, uplus_s32 time_wait)
{
	//uplus_sys_log("[zk u+] os_sem_take time=%d", time_wait);
	return uplus_os_mutex_take(id, time_wait);	
}

/*!
 * \brief 释放同步信号量。
 * \param [in] id 信号量ID。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_sem_give(uplus_sem_id id)
{
	return uplus_os_mutex_give(id);
}

/*!
 * \brief 删除互斥信号量。
 * \param [in] id 信号量ID。
 * \return 成功返回0，失败返回-1。
 */
uplus_s32 uplus_os_sem_delete(uplus_sem_id id)
{
	return uplus_os_mutex_delete(id);
}

/*!
 * \brief 获取系统运行时间
 * \note 获取系统运行时间。uplugSDK不关心系统时间单位，但时间单位精度要小于100毫秒。
 * \return 系统运行时间。
 */
uplus_time uplus_os_current_time_get(void)
{
	uplus_time time = iot_os_get_system_tick();
	//uplus_sys_log("[zk u+] os_current_time_get time=%d", time);
	return time;
}

/*!
 * \brief 计算时间差。
 * \param [in] new_time 新时间（uplus_os_current_time_get返回的时间）。
 * \param [in] old_time 旧时间（uplus_os_current_time_get返回的时间）。
 * \return 时间差，单位毫秒。
 */
uplus_time uplus_os_diff_time_cal(uplus_time new_time, uplus_time old_time)
{
	uplus_time time=0;
	//uplus_sys_log("[zk u+] os_diff_time_cal new=%d, old=%d", new_time, old_time);
	if(new_time >= old_time)
		time = (new_time - old_time)*5;
	else
		time = ((0xFFFFFFFF - old_time) + new_time)*5;

	return time;
}



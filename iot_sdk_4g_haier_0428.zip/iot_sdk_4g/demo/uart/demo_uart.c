#include "haier_appmain.h"
#include "haier_led.h"
#include "haier_bottomPlate.h"
#include "haier_bt.h"
#include "haier_module.h"
#include "haier_uplus_server.h"
#include "haier_fota.h"


HANDLE air_task_handle;
HANDLE air_recv_task_handle;
HANDLE bt_task_handle;
HANDLE bt_recv_task_handle;
HANDLE uplus_server_task_handle;
HANDLE u_server_task_handle;
HANDLE network_task_handle;
HANDLE ota_task_handle;
HANDLE led_task_handle;

HANDLE test_task_handle;

HANDLE haier_main_timer_handle;
HANDLE air_uart_timer_handle;
HANDLE bt_uart_timer_handle;

Haier_AppSystem appSysTem;

int32 uplus_usr_init(void);

VOID task_msg_send(HANDLE hTask, TASK_MSG_ID id, void *param, uint32 len)
{
    TASK_MSG *msg = NULL;

    msg = (TASK_MSG *)iot_os_malloc(sizeof(TASK_MSG));
	memset(msg, 0, sizeof(TASK_MSG));
    msg->id = id;
	if((param != NULL) && (len > 0))
	{
		msg->param = iot_os_malloc(len);
		if(msg->param == NULL)
		{
			uplus_sys_log("[zk] task_msg_send_0 malloc fail %d", len);
			iot_os_free(msg);
			return ;
		}
		memset(msg->param, 0, len);
		memcpy(msg->param, param, len);
    	msg->len = len;
	}

    iot_os_send_message(hTask, msg);
}

void set_sys_state(SYS_STATE sysStata)
{
	HANDLE Section = iot_os_enter_critical_section();
	
	appSysTem.sysCurrState = sysStata;
	
    iot_os_exit_critical_section(Section);
}

SYS_STATE get_sye_state(void)
{
	return appSysTem.sysCurrState;
}

static void haier_main_time_callback(void *pParameter)
{
	task_msg_send(air_task_handle, GET_AIR_DATA_MSG, NULL, 0);
}

static void haier_appSoftTimerCreated(void)
{
	haier_main_timer_handle = iot_os_create_timer(haier_main_time_callback,  (PVOID)1);

	air_uart_timer_handle = iot_os_create_timer(air_uart_timer_callback,  (PVOID)2);

	bt_uart_timer_handle = iot_os_create_timer(bt_uart_timer_callback,  (PVOID)3);
}

static void haier_appTaskCreated(void)
{
	air_recv_task_handle = iot_os_create_task(air_recv_task_main, NULL, 4096, 4, OPENAT_OS_CREATE_DEFAULT, "air_recv_task");

	air_task_handle = iot_os_create_task(air_task_main, NULL, 2048, 3, OPENAT_OS_CREATE_DEFAULT, "air_task");

	bt_recv_task_handle = iot_os_create_task(bt_recv_task_main, NULL, 2048, 5, OPENAT_OS_CREATE_DEFAULT, "bt_task");

	bt_task_handle = iot_os_create_task(bt_task_main, NULL, 2048, 4, OPENAT_OS_CREATE_DEFAULT, "bt_task");

	u_server_task_handle = iot_os_create_task(uplus_server_task_main, NULL, 4096, 3, OPENAT_OS_CREATE_DEFAULT, "u_server_task");

	network_task_handle = iot_os_create_task(network_task_main, NULL, 2048, 3, OPENAT_OS_CREATE_DEFAULT, "network_task");

	ota_task_handle = iot_os_create_task(ota_task, NULL,10*1024,5,OPENAT_OS_CREATE_DEFAULT,"ota_task");
	
	led_task_handle = iot_os_create_task(led_task_main, NULL, 1024, 6, OPENAT_OS_CREATE_DEFAULT, "led_task");

	//test_task_handle = iot_os_create_task(uplus_server_test_task, NULL, 1024, 6, OPENAT_OS_CREATE_DEFAULT, "teat_task");
}

void app_main(void)
{
    haier_appSoftTimerCreated();

	haier_appTaskCreated();
}




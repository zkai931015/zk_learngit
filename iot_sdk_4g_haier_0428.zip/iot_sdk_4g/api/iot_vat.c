#include "string.h"
#include "iot_debug.h"
#include "iot_vat.h"
#include "iot_os.h"

#define STR_TO_INT(x) 	(x-'0') 					/*���ֵ�charת��Ϊint*/

typedef struct UrcEntityQueueTag
{
    UrcEntity urcEntityArray[URC_QUEUE_COUNT]; 
    u8 count;                                 
}UrcEntityQueue;

typedef struct AtCmdEntityQueueTag
{
    u8 current;                                 
    u8 last;                                    
    u8 funFirst;                                
    u8 funLast;                                 
    AtCmdEntity atCmdEntityArray[AT_CMD_QUEUE_COUNT]; 

}AtCmdEntityQueue;


int initstatus = FALSE;
BOOL  simpresent = FALSE;
gsmloc_cellinfo GSMLOC_CELL = {0};
extern E_OPENAT_NETWORK_STATE network_state;
static HANDLE g_netstatustimer;


static AtCmdEntityQueue s_atCmdEntityQueue={0};
static UrcEntityQueue s_urcEntityQueue={1};
static AtCmdRsp AtCmdCbDefault(u8* pRspStr);   
static BOOL AtCmdDelayExe(u16 delay);
static VOID global_urc_handler(u8* pUrcStr, u16 len);
static BOOL iot_vat_queue_head_out(VOID);
static BOOL iot_vat_queue_tail_out(VOID);
static BOOL iot_vat_queue_fun_out(VOID);
extern VOID networkStatusChange(VOID);
extern VOID network_check_status(VOID);

static AtCmdRsp AtCmdCbDefault(u8* pRspStr)
{
	iot_debug_print("[vat] AtCmdCbDefault");
    AtCmdRsp  rspValue = AT_RSP_WAIT;
    u8 *rspStrTable[ ] = {"OK","ERROR"};
    s16  rspType = -1;
    u8  i = 0;
    u8  *p = pRspStr + 2;
    for (i = 0; i < sizeof(rspStrTable) / sizeof(rspStrTable[0]); i++)
    {
        if (!strncmp(rspStrTable[i], p, strlen(rspStrTable[i])))
        {
            rspType = i;
            break;
        }
    }
    switch (rspType)
    {
        case 0:  /* OK */
        rspValue  = AT_RSP_CONTINUE;
        break;

        case 1:  /* ERROR */
        rspValue = AT_RSP_ERROR;
        break;

        default:
        break;
    }

    return rspValue;
}
    
static BOOL AtCmdDelayExe(u16 delay)
{
	BOOL ret = FALSE;
	iot_debug_print("[vat]INFO: at cmd delay execute,%d",delay);
	if (delay == 0){
		delay = AT_CMD_EXECUTE_DELAY;
	}
	ret = iot_os_sleep(delay);
	iot_vat_SendCMD();
	return ret;
}

VOID iot_vat_queue_init(VOID)
{
    u8 i = 0;
    u8 first = MIN(s_atCmdEntityQueue.current,s_atCmdEntityQueue.funFirst);
    for ( i=first; i<=s_atCmdEntityQueue.last; i++) {
        AtCmdEntity* atCmdEnt = NULL;
        atCmdEnt = &(s_atCmdEntityQueue.atCmdEntityArray[i]);
        if(atCmdEnt->p_atCmdStr){
            iot_os_free(atCmdEnt->p_atCmdStr);
            atCmdEnt->p_atCmdStr = NULL;
        }
        atCmdEnt->p_atCmdCallBack = NULL;
    }
    memset(&s_atCmdEntityQueue,0,sizeof(AtCmdEntityQueue));
}

static BOOL iot_vat_queue_head_out(VOID)
{
    AtCmdEntity* atCmdEnt = NULL;

   if(s_atCmdEntityQueue.current == s_atCmdEntityQueue.last) /* the queue is empty */
       return FALSE;

   if(s_atCmdEntityQueue.current>=s_atCmdEntityQueue.funLast
           || s_atCmdEntityQueue.current<=s_atCmdEntityQueue.funFirst){
       atCmdEnt = &(s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.current]);
       if(atCmdEnt->p_atCmdStr){
           iot_os_free(atCmdEnt->p_atCmdStr);
           atCmdEnt->p_atCmdStr = NULL;
       }
       atCmdEnt->p_atCmdCallBack = NULL;
   }
   s_atCmdEntityQueue.current = (s_atCmdEntityQueue.current + 1) %  AT_CMD_QUEUE_COUNT;
   return TRUE;
}

static BOOL iot_vat_queue_tail_out(VOID)
{
    AtCmdEntity* atCmdEnt = NULL;
    if(s_atCmdEntityQueue.current == s_atCmdEntityQueue.last)
        return FALSE;
    s_atCmdEntityQueue.last = (s_atCmdEntityQueue.last + AT_CMD_QUEUE_COUNT - 1) % AT_CMD_QUEUE_COUNT;
    atCmdEnt = &(s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.last]);
    if(atCmdEnt->p_atCmdStr){
        iot_os_free(atCmdEnt->p_atCmdStr);
        atCmdEnt->p_atCmdStr = NULL;
    }
    atCmdEnt->p_atCmdCallBack = NULL;
    return TRUE;
}

static BOOL iot_vat_queue_fun_out(VOID)
{
    u8 i = 0;
    if (s_atCmdEntityQueue.funLast == 0)        /* no at cmd func */
        return FALSE;

    if (s_atCmdEntityQueue.funLast < s_atCmdEntityQueue.funFirst)
	{
	    for (i = s_atCmdEntityQueue.funFirst; i < AT_CMD_QUEUE_COUNT; i++) 
		{
           AtCmdEntity* atCmdEnt = NULL;
           atCmdEnt = &(s_atCmdEntityQueue.atCmdEntityArray[i]);
           if(atCmdEnt->p_atCmdStr){
               iot_os_free(atCmdEnt->p_atCmdStr);
               atCmdEnt->p_atCmdStr = NULL;
           }
           atCmdEnt->p_atCmdCallBack = NULL;
       }
	
	    for (i = 0;i <= s_atCmdEntityQueue.funLast; i++)
		{
            AtCmdEntity* atCmdEnt = NULL;
            atCmdEnt = &(s_atCmdEntityQueue.atCmdEntityArray[i]);
            if(atCmdEnt->p_atCmdStr){
                iot_os_free(atCmdEnt->p_atCmdStr);
                atCmdEnt->p_atCmdStr = NULL;
            }
            atCmdEnt->p_atCmdCallBack = NULL;
        }
    }
	else
	{
	    for ( i=s_atCmdEntityQueue.funFirst ;i<=s_atCmdEntityQueue.funLast ; i++) {
	        AtCmdEntity* atCmdEnt = NULL;
	        atCmdEnt = &(s_atCmdEntityQueue.atCmdEntityArray[i]);
	        if(atCmdEnt->p_atCmdStr){
	            iot_os_free(atCmdEnt->p_atCmdStr);
	            atCmdEnt->p_atCmdStr = NULL;
	        }
	        atCmdEnt->p_atCmdCallBack = NULL;
	    }
	}

    if(s_atCmdEntityQueue.current != s_atCmdEntityQueue.funLast){
        s_atCmdEntityQueue.current = s_atCmdEntityQueue.funLast;
    }

    s_atCmdEntityQueue.current = (s_atCmdEntityQueue.current + 1) % AT_CMD_QUEUE_COUNT;
    s_atCmdEntityQueue.funLast = 0;
    s_atCmdEntityQueue.funFirst = 0;
    return TRUE;

}

BOOL iot_vat_queue_is_empty(VOID)
{
    return (s_atCmdEntityQueue.current == s_atCmdEntityQueue.last);
}

BOOL iot_vat_queue_fun_set(u8 funCount)
{
    u8 i = 0;
    u8 first =  MAX(s_atCmdEntityQueue.current,s_atCmdEntityQueue.funFirst);
    u8 freeCount = 0;
	#if 0
    if (s_atCmdEntityQueue.funLast != s_atCmdEntityQueue.funFirst){
        iot_debug_print("[vat]ERROR: fun is exist!");
        return FALSE;                           /* just one func exist */
    }
	#endif
    if(iot_vat_queue_is_empty()){
        freeCount = AT_CMD_QUEUE_COUNT;
    }
    else {
        freeCount = (first - s_atCmdEntityQueue.last + AT_CMD_QUEUE_COUNT) % AT_CMD_QUEUE_COUNT;
    }
    if(funCount > freeCount) {
        iot_debug_print("[vat]ERROR: the queue is full! %d,%d,%d",first,funCount,freeCount);
        return FALSE;                           /* the space is poor */
    }

    s_atCmdEntityQueue.funFirst = s_atCmdEntityQueue.last;
    s_atCmdEntityQueue.funLast = (s_atCmdEntityQueue.last + funCount - 1 + AT_CMD_QUEUE_COUNT) % AT_CMD_QUEUE_COUNT;
    iot_debug_print("[vat]INFO: the at cmd func's range is %d-%d", s_atCmdEntityQueue.funFirst, s_atCmdEntityQueue.funLast);
    return TRUE;
}

BOOL iot_vat_queue_append(AtCmdEntity atCmdEntity)
{
                                                /* get first index */
    u8 first =  MAX(s_atCmdEntityQueue.current,s_atCmdEntityQueue.funFirst);

    if (atCmdEntity.p_atCmdStr == NULL){
        iot_debug_print("[vat]ERROR: at cmd str is null!");
        return FALSE;
    }

    if (atCmdEntity.p_atCmdCallBack == NULL)    /* set default callback function */
        atCmdEntity.p_atCmdCallBack = AtCmdCbDefault;

    if((s_atCmdEntityQueue.last + 1) % AT_CMD_QUEUE_COUNT == first){
        iot_debug_print("[vat]ERROR: at cmd queue is full!");
        return FALSE;                           /* the queue is full */
    }
    else{
        u8* pAtCmd = NULL; 

        pAtCmd = iot_os_malloc(atCmdEntity.cmdLen+1);
		pAtCmd[atCmdEntity.cmdLen] = 0;
        if (!pAtCmd){
            iot_debug_print("[vat]ERROR: memory alloc error!");
            return FALSE;
        }

        memcpy(pAtCmd,atCmdEntity.p_atCmdStr,atCmdEntity.cmdLen);
        s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.last].cmdLen = atCmdEntity.cmdLen;
        s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.last].p_atCmdStr = pAtCmd;
        s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.last].p_atCmdCallBack = atCmdEntity.p_atCmdCallBack;
        s_atCmdEntityQueue.last = (s_atCmdEntityQueue.last + 1) %  AT_CMD_QUEUE_COUNT;
	    iot_debug_print("[vat]pAtCmd : %s",pAtCmd);
        return TRUE;
    }
}

BOOL iot_vat_queue_fun_append(AtCmdEntity atCmdEntity[],u8 funCount)
{
    u8 i = 0;
    BOOL ret = FALSE;
    ret = iot_vat_queue_fun_set(funCount);
    if(!ret)
        return FALSE;

    for ( i=0; i<funCount; i++) {
        BOOL ret = FALSE;
        ret = iot_vat_queue_append(atCmdEntity[i]);
        if (!ret){
            break;
        }
    }

    if(i != funCount){                           /* error is ocur */
        for ( i=funCount; i > 0; i--) {
            iot_vat_queue_tail_out();
        }
        iot_debug_print("[vat]ERROR: add to queue is error!,%d",funCount);
        return FALSE;
    }

    iot_debug_print("[vat]INFO: funFirst:%d  funLast:%d", s_atCmdEntityQueue.funFirst, s_atCmdEntityQueue.funLast);
    return TRUE;
}

static VOID iot_timer_handle(void *pParameter)
{
	iot_os_stop_timer(g_netstatustimer);
	network_check_status();
}

static VOID iot_vat_netstatus(UINT8 *pData)
{
	int i;
	int cid = 0;
	int netstatusType = -1;
	u8  *p = pData + 2;
	UINT8 *netStatus[] = {"+CGEV: ME DETACH",
						"+CGEV: EPS DED DEACT",
						"+CGEV: ME DEACT",
						"+CGEV: EPS PDN DEACT",
						"+CGEV: ME PDN DEACT",
						"+CGEV: NW DEACT",
						"+CGEV: NW DETACH",
						"+CGEV: EPS DED ACT",
						"+CGEV: ME ACT",
						"+CGEV: EPS PDN ACT",
						"+CGEV: ME PDN ACT",
						"+CGEV: NW ACT",
						"+CGEV: EPS ACT",
						"+CGEV: NW MODIFY"};
	for (i = 0; i < sizeof(netStatus) / sizeof(netStatus[0]); i++)
    	{
        if (!strncmp(netStatus[i], p, strlen(netStatus[i])))
        {
            netstatusType = i;
			cid = STR_TO_INT(p[strlen(netStatus[netstatusType])+1]);
			if(6 == cid)
			{
	            if (netstatusType >= 0 && netstatusType < 7)
				{
					network_state = OPENAT_NETWORK_DISCONNECT;	
					networkStatusChange();
				}
	            break;
			}
			if(5 == cid)
			{
				if(netstatusType >= 7 && netstatusType < 13)
				{
					iot_os_stop_timer(g_netstatustimer);
					network_check_status();
				}
			}
        }
    }
}

static int atoi_Vat(char* str_p)
{
	int i;
	int num = 0;
	char* p;
	p = str_p;
	int len = strlen(str_p);
	for(i = 0; i < len; i++)
	{
		if(*(p+i) >= '0' && *(p+i)<='9')
			num = num*10 + STR_TO_INT(*(p+i));
	}
	return num;
}
/*��ȡС������С����Ϣ*/
static VOID GetCellInfo(UINT8 *pData)
{
	int cut = 0;
	u8* p = pData;
	u8 buf[50][15] = {0};
	/*LTE cellinfo*/
	if(!strncmp(pData, "\r\n+EEMLTESVC:", strlen("\r\n+EEMLTESVC:")))	
	{
		p = p + strlen("\r\n+EEMLTESVC:");
		u8* b = strtok(p, ",");
		while(b != NULL)
		{
			strcpy(buf[cut], b);
			cut++;
			b = strtok(NULL, ",");
		}
		GSMLOC_CELL.Cellinfo[0].Mcc = atoi_Vat(buf[0]);
		GSMLOC_CELL.Cellinfo[0].Mnc = atoi_Vat(buf[2]);
		GSMLOC_CELL.Cellinfo[0].Lac= atoi_Vat(buf[3]);
		GSMLOC_CELL.Cellinfo[0].CellId = atoi_Vat(buf[9]);
		GSMLOC_CELL.Cellinfo[0].rssi = atoi_Vat(buf[14])/3;
		iot_debug_print("[vat] mcc: %d,  mnc: %d,  lac: %d,  ci: %d,  rssi: %d,",
			GSMLOC_CELL.Cellinfo[0].Mcc,
			GSMLOC_CELL.Cellinfo[0].Mnc,
			GSMLOC_CELL.Cellinfo[0].Lac,
			GSMLOC_CELL.Cellinfo[0].CellId,
			GSMLOC_CELL.Cellinfo[0].rssi);
	}
	/*UMT cellinfo*/
	if(!strncmp(pData, "\r\n+EEMUMTSSVC:", strlen("\r\n+EEMUMTSSVC:")))	
	{
		UINT16 cellMeasureFlag;
		UINT16 cellParamFlag;
		UINT16 offset = 3;
		p = p + strlen("\r\n+EEMUMTSSVC:");
		u8* b = strtok(p, ",");
		while(b != NULL)
		{
			strcpy(buf[cut], b);
			cut++;
			b = strtok(NULL, ",");
		}
		cellMeasureFlag = atoi_Vat(buf[1]);
		cellParamFlag = atoi_Vat(buf[2]);
		if(cellMeasureFlag != 0)
		{
			offset = offset + 2;
			GSMLOC_CELL.Cellinfo[0].rssi = atoi_Vat(buf[offset])/3;
			offset = offset + 4;
		}
		else
		{
			offset = offset + 2;
			GSMLOC_CELL.Cellinfo[0].rssi = atoi_Vat(buf[offset])/3;
			offset = offset + 2;
		}
		if(cellParamFlag != 0)
		{
			offset = offset + 3;
			iot_debug_print("[vat] buf[%d]: %s,  buf[%d]: %s,  buf[%d]: %s,  buf[%d]: %s,",
				offset, buf[offset],
				offset+1, buf[offset+1],
				offset+2, buf[offset+2],
				offset+3, buf[offset+3]);
			GSMLOC_CELL.Cellinfo[0].Mcc = atoi_Vat(buf[offset]);
			GSMLOC_CELL.Cellinfo[0].Mnc = atoi_Vat(buf[offset+1]);
			GSMLOC_CELL.Cellinfo[0].Lac= atoi_Vat(buf[offset+2]);
			GSMLOC_CELL.Cellinfo[0].CellId = atoi_Vat(buf[offset+3]);
		}
		iot_debug_print("[vat] mcc: %d,  mnc: %d,  lac: %d,  ci: %d,  rssi: %d,",
			GSMLOC_CELL.Cellinfo[0].Mcc,
			GSMLOC_CELL.Cellinfo[0].Mnc,
			GSMLOC_CELL.Cellinfo[0].Lac,
			GSMLOC_CELL.Cellinfo[0].CellId,
			GSMLOC_CELL.Cellinfo[0].rssi);
	}
	/*GSM curCellInfo*/
	if(!strncmp(pData, "\r\n+EEMGINFOSVC:", strlen("\r\n+EEMGINFOSVC:")))	
	{
		p = p + strlen("\r\n+EEMGINFOSVC:");
		u8* b = strtok(p, ",");
		while(b != NULL)
		{
			strcpy(buf[cut], b);
			cut++;
			b = strtok(NULL, ",");
		}
		GSMLOC_CELL.Cellinfo[0].Mcc = atoi_Vat(buf[0]);
		GSMLOC_CELL.Cellinfo[0].Mnc = atoi_Vat(buf[1]);
		GSMLOC_CELL.Cellinfo[0].Lac= atoi_Vat(buf[2]);
		GSMLOC_CELL.Cellinfo[0].CellId = atoi_Vat(buf[3]);
		if(atoi_Vat(buf[9]) > 31)
		{
			GSMLOC_CELL.Cellinfo[0].rssi = 31;
		}
		else if(atoi_Vat(buf[9]) < 0)
		{
			GSMLOC_CELL.Cellinfo[0].rssi = 0;
		}
		else
		{
			GSMLOC_CELL.Cellinfo[0].rssi = atoi_Vat(buf[9]);
		}
		iot_debug_print("[vat] mcc: %d,  mnc: %d,  lac: %d,  ci: %d,  rssi: %d,",
			GSMLOC_CELL.Cellinfo[0].Mcc,
			GSMLOC_CELL.Cellinfo[0].Mnc,
			GSMLOC_CELL.Cellinfo[0].Lac,
			GSMLOC_CELL.Cellinfo[0].CellId,
			GSMLOC_CELL.Cellinfo[0].rssi);
	}
	/*GSM nbrCellInfo*/
	if(!strncmp(pData, "\r\n+EEMGINFONC:", strlen("\r\n+EEMGINFONC:")))	
	{
		p = p + strlen("\r\n+EEMGINFONC:");
		u8* b = strtok(p, ',');
		u8 id = 0;
		while(b != NULL)
		{
			strcpy(buf[cut], b);
			cut++;
			b = strtok(NULL, ',');
		}
		id = atoi_Vat(buf[0]);
		GSMLOC_CELL.Cellinfo[id+1].Mcc = atoi_Vat(buf[1]);
		GSMLOC_CELL.Cellinfo[id+1].Mnc = atoi_Vat(buf[2]);
		GSMLOC_CELL.Cellinfo[id+1].Lac= atoi_Vat(buf[3]);
		GSMLOC_CELL.Cellinfo[id+1].CellId = atoi_Vat(buf[5]);
		GSMLOC_CELL.Cellinfo[id+1].rssi = atoi_Vat(buf[6]);
		iot_debug_print("[vat] mcc: %d,  mnc: %d,  lac: %d,  ci: %d,  rssi: %d,",
			GSMLOC_CELL.Cellinfo[id+1].Mcc,
			GSMLOC_CELL.Cellinfo[id+1].Mnc,
			GSMLOC_CELL.Cellinfo[id+1].Lac,
			GSMLOC_CELL.Cellinfo[id+1].CellId,
			GSMLOC_CELL.Cellinfo[id+1].rssi);
	}
}

static UINT8 iot_vat_ResPerc(UINT8 *pData)
{
	UINT8  *p = pData + 2;
	if(!strncmp(p, "^SIMST:", strlen("^SIMST:")))	
		return 1;
	if(!strncmp(p, "+MSTK:", strlen("+MSTK:")))	
		return 1;
	if(!strncmp(p, "+MMSG:", strlen("+MMSG:")))	
		return 1;
	if(!strncmp(p, "+MPBK:", strlen("+MPBK:")))	
		return 1;
	if(!strncmp(p, "+NITZ:", strlen("+NITZ:")))	
		return 1;
	if(!strncmp(p, "+CGEV:", strlen("+CGEV:"))) 
		return 1;
	
	return 0;
}

static VOID iot_vat_ATCmdIndHandle(UINT8 *pData, UINT16 length)
{
    if (length > 0) 
	{
		iot_vat_netstatus(pData);
		if(!strncmp(pData, "\r\n+CPIN: READY\r\n", length))	
		{
			iot_os_stop_timer(g_netstatustimer);
			network_check_status();
		}
		if(!strncmp(pData, "\r\n^SIMST: 1\r\n", length))	
		{
			simpresent = TRUE;
		}
		else if(!strncmp(pData, "\r\n^SIMST: 0\r\n", length))
		{
			simpresent = FALSE;
		}
		GetCellInfo(pData);
		iot_debug_print("[vat] pData : %s , %d", pData+2, length);
		if(iot_vat_ResPerc(pData))
			return;
		
	    AtCmdRsp atCmdRsp = AT_RSP_ERROR;

	    if (s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.current].p_atCmdCallBack)
		{
	        atCmdRsp = s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.current].p_atCmdCallBack(pData);

	        iot_debug_print("[vat]INFO: callback return %d,%d",s_atCmdEntityQueue.current,atCmdRsp);
	        switch ( atCmdRsp )
			{
	            case AT_RSP_ERROR:
	                iot_debug_print("[vat]ERROR: at cmd execute error, initial at cmd queue!");
	                iot_vat_queue_init();
	                break;
	            case AT_RSP_CONTINUE:	
	            case AT_RSP_FINISH:	
	                iot_vat_queue_head_out();
	                AtCmdDelayExe(0);
	                break;

	            case AT_RSP_FUN_OVER:	
	                iot_vat_queue_fun_out();
	                AtCmdDelayExe(0);
	                break;

	            case AT_RSP_WAIT:
	                break;

	            default:	
	                if(atCmdRsp>=AT_RSP_STEP_MIN && atCmdRsp<=AT_RSP_STEP_MAX) 
				   {
	                    s8 step = s_atCmdEntityQueue.current + atCmdRsp - AT_RSP_STEP;
	                    iot_debug_print("[vat]DEBUG: cur %d,step %d",s_atCmdEntityQueue.current,step);
					  iot_debug_print("[vat]s_atCmdEntityQueue.funFirst = %d, s_atCmdEntityQueue.funLast = %d",s_atCmdEntityQueue.funFirst, s_atCmdEntityQueue.funLast);
	                    if(step<=s_atCmdEntityQueue.funLast && step>= s_atCmdEntityQueue.funFirst)
					  {
	                        s_atCmdEntityQueue.current = step;
	                        AtCmdDelayExe(0);
	                    }
	                    else
					  {
	                        iot_debug_print("[vat]ERROR: return of AtCmdRsp is error!");
	                    }
	                }
	                break;
	        }
	    }
	}
}

VOID iot_vat_SendCMD(VOID)
{
	u8* pCmd = s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.current].p_atCmdStr;
	u16 len = s_atCmdEntityQueue.atCmdEntityArray[s_atCmdEntityQueue.current].cmdLen;
	if(pCmd){
		u16 lenAct = 0;
		iot_debug_print("[vat]DEBUG:at cmd is:%d,%s,%d",s_atCmdEntityQueue.current,pCmd,len);
		if (!strncmp(AT_CMD_DELAY, pCmd, strlen(AT_CMD_DELAY))) {  /* delay some seconds to run next cmd */
			uint32 delay = 0;
			int i = 0;
			for(i = 0; i < (len - strlen(AT_CMD_DELAY)); i++)
			{
				if(pCmd[strlen(AT_CMD_DELAY)+i]>='0' && pCmd[strlen(AT_CMD_DELAY)+i] <= '9')
				{
					delay = delay*10 + STR_TO_INT(pCmd[strlen(AT_CMD_DELAY)+i]);
				}else
				{
					break;
				}
			}
			iot_vat_queue_head_out();
			AtCmdDelayExe(delay);
			return;
		}
		lenAct = IVTBL(send_at_command)(pCmd,len);
		if(!lenAct)
			iot_debug_print("[vat]ERROR: send at cmd error!");
		else{
			iot_debug_print("[vat]send at cmd:%s",pCmd);
		}
	}
}

VOID iot_vat_Modeuleinit(VOID)
{
	if(initstatus)
	{
		return;
	}
	initstatus = TRUE;
	g_netstatustimer = iot_os_create_timer(iot_timer_handle, NULL);
	iot_os_start_timer(g_netstatustimer, 30*1000);
	iot_vat_queue_init();
	IVTBL(init_at)(iot_vat_ATCmdIndHandle);	
}



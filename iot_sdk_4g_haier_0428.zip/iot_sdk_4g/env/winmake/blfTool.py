import sys
import os

def replaceFileContext(fileName, matchString, replace):
    bakFile = fileName +"_bak"
    fout = open(bakFile, 'w')
    with open(fileName, 'r') as f:
        for l in f:
            if l.startswith(matchString):
                if(len(replace) > 0):
                    fout.write(replace + '\r\n')
            else:
                fout.write(l)
    f.close()
    fout.close()
    os.remove(fileName)
    os.rename(bakFile, fileName)

def copyFile(src, dst):
    fout = open(dst, 'w')
    with open(src, 'r') as f:
        for l in f:
            fout.write(l)
    f.close()
    fout.close()



def usage():
    print(sys.argv[0] +" 0/1 infile outFile\r\n 0: for update bin\r\n 1: for prod")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        usage()
        sys.exit(-1)

    copyFile(sys.argv[2], sys.argv[3])

    replaceFileContext(sys.argv[3], '1_Image_Enable', '1_Image_Enable = 0')
    replaceFileContext(sys.argv[3], '2_Image_Enable', '2_Image_Enable = 0')
    replaceFileContext(sys.argv[3], '3_Image_Enable', '3_Image_Enable = 0')
    replaceFileContext(sys.argv[3], '4_Image_Enable', '4_Image_Enable = 0')
    if sys.argv[1] != '1':
        replaceFileContext(sys.argv[3], '[EraseOnly_Option]', '')
        replaceFileContext(sys.argv[3], 'Total_Eraseonly_Areas', '')
        replaceFileContext(sys.argv[3], '1_Eraseonly_Area_Size','')
        replaceFileContext(sys.argv[3], '1_Eraseonly_Area_FlashStartAddress','')
        replaceFileContext(sys.argv[3], '1_Eraseonly_Area_Partition','')
        replaceFileContext(sys.argv[3], '2_Eraseonly_Area_Size','')
        replaceFileContext(sys.argv[3], '2_Eraseonly_Area_FlashStartAddress','')
        replaceFileContext(sys.argv[3], '2_Eraseonly_Area_Partition','')
        replaceFileContext(sys.argv[3], '3_Eraseonly_Area_Size','')
        replaceFileContext(sys.argv[3], '3_Eraseonly_Area_FlashStartAddress','')
        replaceFileContext(sys.argv[3], '3_Eraseonly_Area_Partition','')

        replaceFileContext(sys.argv[3], '5_Image_Enable','5_Image_Enable = 0')
        replaceFileContext(sys.argv[3], '6_Image_Enable','6_Image_Enable = 0')
        replaceFileContext(sys.argv[3], '7_Image_Enable','7_Image_Enable = 0')
        replaceFileContext(sys.argv[3], '9_Image_Enable','9_Image_Enable = 0')
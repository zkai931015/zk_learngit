#ifndef    _HAIER_LED_H_
#define    _HAIER_LED_H_

#include "haier_appmain.h"

#define LED_MODE_PIN 	65
#define LED_STATUS_PIN 	64

#define LED_MODE_OFF iot_gpio_set(LED_MODE_PIN, FALSE)
#define LED_MODE_ON  iot_gpio_set(LED_MODE_PIN, TRUE)

#define LED_STATUS_OFF iot_gpio_set(LED_STATUS_PIN, FALSE)
#define LED_STATUS_ON  iot_gpio_set(LED_STATUS_PIN, TRUE)

extern void led_task_main(void *pParameter);

#endif



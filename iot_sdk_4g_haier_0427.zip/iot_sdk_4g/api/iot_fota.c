#include "iot_flash.h"


E_OPENAT_OTA_RESULT iot_fota_init(void)
{
    return IVTBL(fota_init)();
}


E_OPENAT_OTA_RESULT iot_fota_download(const char* data, UINT32 len, UINT32 total)
{
    return IVTBL(fota_download)(data, len,total);
}


E_OPENAT_OTA_RESULT iot_fota_done(void)
{
    return IVTBL(fota_done)();
}



#include "iot_debug.h"
#include "string.h"

#define UART_LOG_MAX_LENTH 128
static CHAR buff[UART_LOG_MAX_LENTH];
/*******************************************
**                 DEBUG                  **
*******************************************/

/**assert����
*@param		condition:	��������
*@param		func:	    ���Ժ���
*@param		line:	    ����λ��
*@return	TURE: 	    �ɹ�
*           FALSE:      ʧ��
**/
VOID iot_debug_assert(                                          
                        BOOL condition,                  
                        CHAR *func,                     
                        UINT32 line                       
              )
{
    IVTBL(assert)(condition, func, line);
}

VOID iot_uart_print(
                      E_AMOPENAT_UART_PORT port,
                      CHAR *fmt, ...)
{
	va_list args;
	memset(buff, 0, UART_LOG_MAX_LENTH+1);
	va_start(args, fmt);
	vsnprintf(buff, UART_LOG_MAX_LENTH, fmt, args);
	iot_uart_write(port, buff, strlen(buff));
	va_end (args);
}


/**���������쳣ʱ���豸ģʽ
*@param	  mode:   OPENAT_FAULT_RESET ����ģʽ
				  OPENAT_FAULT_HANG  ����ģʽ
**/

VOID iot_debug_set_fault_mode(E_OPENAT_FAULT_MODE mode)
{
	//IVTBL(set_fault_mode)(mode);
}


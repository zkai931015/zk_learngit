#ifndef    _HAIER_WDG_H_
#define    _HAIER_WDG_H_


#include "haier_appmain.h"

#define WDG_REST_IN_PIN		54
#define	WDG_WDI_PIN			53

extern void wdg_reset(void);
extern int8 wdg_feed(void);
extern int8  wdg_init(VOID);

#endif


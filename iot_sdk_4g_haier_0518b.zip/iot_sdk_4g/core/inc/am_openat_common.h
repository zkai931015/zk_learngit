/*********************************************************
  Copyright (C), AirM2M Tech. Co., Ltd.
  Author: lifei
  Description: AMOPENAT ����ƽ̨
  Others:
  History: 
    Version�� Date:       Author:   Modification:
    V0.1      2012.12.14  lifei     �����ļ�
*********************************************************/
#ifndef AM_OPENAT_COMMON_H
#define AM_OPENAT_COMMON_H

#include "cs_types.h"
 
#define OPENAT_INVALID_HANDLE 0

#endif /* AM_OPENAT_COMMON_H */


/**
 * @file uplus_pal_ble.h
 * @brief
 *
 * @date 2019-05-09
 * @author hudingxuan
 *
 */

#ifndef __UPLUS_PAL_BLE_H__
#define __UPLUS_PAL_BLE_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @defgroup BLE PAL APIs
 * @details BLE相关PAL接口。
 * @{
 */

/*============================COMMON==========================================*/
typedef uplus_u8 uplus_ble_addr_t[6];

typedef enum
{
	UPLUS_BLE_ADDRESS_TYPE_PUBLIC,
	UPLUS_BLE_ADDRESS_TYPE_RANDOM
} uplus_ble_addr_type_t;

typedef enum
{
	UPLUS_BLE_UUID_TYPE_16,
	UPLUS_BLE_UUID_TYPE_128,
} uplus_ble_uuid_type_t;

typedef struct
{
	uplus_ble_uuid_type_t type;
	union
	{
		uplus_u16 uuid16;
		uplus_u8 uuid128[16];
	};
} uplus_ble_uuid_t;

typedef enum
{
	UPLUS_BLE_GAP_PERIPHERAL,
	UPLUS_BLE_GAP_CENTRAL
} uplus_ble_gap_role_t;

typedef enum
{
	UPLUS_BLE_SUCCESS = 0,
	UPLUS_BLE_ERROR = -1
} uplus_ble_status_t;

extern uplus_ble_status_t uplus_ble_address_get(uplus_ble_addr_t mac);

extern uplus_ble_status_t uplus_ble_enable(void);
extern uplus_ble_status_t uplus_ble_disable(void);

extern uplus_ble_status_t uplus_ble_rssi_start(uplus_u16 conn_handle);
extern uplus_ble_status_t uplus_ble_rssi_get(uplus_u16 conn_handle, uplus_s8 * rssi);
extern uplus_ble_status_t uplus_ble_rssi_stop(uplus_u16 conn_handle);

extern uplus_ble_status_t uplus_ble_tx_power_set(uplus_u16 conn_handle, uplus_s8 tx_power);

/*============================GAP=============================================*/
/*GAP-Advertise*/
typedef enum
{
	UPLUS_BLE_ADV_TYPE_CONNECTABLE_UNDIRECTED, /*Connectable undirected advertisement*/
	UPLUS_BLE_ADV_TYPE_SCANNABLE_UNDIRECTED, /*Scannable undirected advertisement*/
	UPLUS_BLE_ADV_TYPE_NON_CONNECTABLE_UNDIRECTED, /*Non-Connectable undirected advertisement*/
	UPLUS_BLE_ADV_TYPE_CONNECTABLE_DIRECTED_HDC, /*Connectable high duty cycle directed advertisement*/
	UPLUS_BLE_ADV_TYPE_CONNECTABLE_DIRECTED_LDC /*Connectable low duty cycle directed advertisement*/
} uplus_ble_gap_adv_type_t;

typedef struct
{
	uplus_u16 adv_interval_min; /**< Range: 0x0020 to 0x4000  Time = N * 0.625 msec Time Range: 20 ms to 10.24 sec*/
	uplus_u16 adv_interval_max; /**< Range: 0x0020 to 0x4000  Time = N * 0.625 msec Time Range: 20 ms to 10.24 sec*/
	uplus_ble_gap_adv_type_t adv_type;
	uplus_ble_addr_type_t direct_addr_type;

	struct
	{
		uplus_u8 ch_37_off : 1; /**< Setting this bit to 1 will turn off advertising on channel 37 */
		uplus_u8 ch_38_off : 1; /**< Setting this bit to 1 will turn off advertising on channel 38 */
		uplus_u8 ch_39_off : 1; /**< Setting this bit to 1 will turn off advertising on channel 39 */
	} ch_mask;
} uplus_ble_gap_adv_param_t;

extern uplus_ble_status_t uplus_ble_gap_adv_data_set(
	uplus_u8 const * p_data,
	uplus_u8 dlen,
	uplus_u8 const *p_sr_data,
	uplus_u8 srdlen);
extern uplus_ble_status_t uplus_ble_gap_adv_start(uplus_ble_gap_adv_param_t *p_adv_param);
extern uplus_ble_status_t uplus_ble_gap_adv_stop(void);

/*GAP-Scan*/
typedef enum
{
	UPLUS_BLE_SCAN_TYPE_PASSIVE,
	UPLUS_BLE_SCAN_TYPE_ACTIVE,
} uplus_ble_gap_scan_type_t;

typedef struct
{
	uplus_u16 scan_interval; /**< Range: 0x0004 to 0x4000 Time = N * 0.625 msec Time Range: 2.5 msec to 10.24 sec*/
	uplus_u16 scan_window; /**< Range: 0x0004 to 0x4000 Time = N * 0.625 msec Time Range: 2.5 msec to 10.24 seconds*/
	uplus_u16 timeout; /**< Scan timeout between 0x0001 and 0xFFFF in seconds, 0x0000 disables timeout.*/
} uplus_ble_gap_scan_param_t;

extern uplus_ble_status_t uplus_ble_gap_scan_start(
	uplus_ble_gap_scan_type_t scan_type,
	uplus_ble_gap_scan_param_t scan_param);
extern uplus_ble_status_t uplus_ble_gap_scan_stop(void);

/*GAP-Connection*/
typedef struct
{
	uplus_u16 min_conn_interval; /**< Range: 0x0006 to 0x0C80, Time = N * 1.25 msec, Time Range: 7.5 msec to 4 seconds.*/
	uplus_u16 max_conn_interval; /**< Range: 0x0006 to 0x0C80, Time = N * 1.25 msec, Time Range: 7.5 msec to 4 seconds.*/
	uplus_u16 slave_latency; /**< Range: 0x0000 to 0x01F3*/
	uplus_u16 conn_sup_timeout; /**< Range: 0x000A to 0x0C80, Time = N * 10 msec, Time Range: 100 msec to 32 seconds*/
} uplus_ble_gap_conn_param_t;

typedef struct
{
	uplus_ble_addr_t peer_addr;
	uplus_ble_addr_type_t type;
	uplus_ble_gap_role_t role;
	uplus_ble_gap_conn_param_t conn_param;
} uplus_ble_gap_connect_t;

extern uplus_ble_status_t uplus_ble_gap_update_conn_params(
	uplus_u16 conn_handle,
	uplus_ble_gap_conn_param_t conn_params);
extern uplus_ble_status_t uplus_ble_gap_disconnect(uplus_u16 conn_handle);

/*GAP-Connection-Master*/
extern uplus_ble_status_t uplus_ble_gap_connect(
	uplus_ble_gap_scan_param_t scan_param,
	uplus_ble_gap_connect_t conn_param);

/*GAP-Callback*/
typedef enum
{
	CONNECTION_TIMEOUT = 1,
	REMOTE_USER_TERMINATED,
	LOCAL_HOST_TERMINATED
} uplus_ble_gap_disconnect_reason_t;

typedef struct
{
	uplus_ble_gap_disconnect_reason_t reason;
} uplus_ble_gap_disconnect_t;

typedef struct
{
	uplus_ble_gap_conn_param_t conn_param;
} uplus_ble_gap_connect_update_t;

typedef enum
{
	ADV_DATA, /**< advertising data*/
	SCAN_RSP_DATA, /**< response data from active scanning*/
} uplus_ble_gap_adv_data_type_t;

typedef struct
{
	uplus_ble_addr_t peer_addr;
	uplus_ble_addr_type_t addr_type;
	uplus_ble_gap_adv_data_type_t adv_type;
	uplus_s8 rssi;
	uplus_u8 data[31];
	uplus_u8 data_len;
} uplus_ble_gap_adv_report_t;

typedef struct
{
	uplus_u16 conn_handle;
	union
	{
		uplus_ble_gap_connect_t connect;
		uplus_ble_gap_disconnect_t disconnect;
		uplus_ble_gap_adv_report_t report;
		uplus_ble_gap_connect_update_t update_conn;
	};
} uplus_ble_gap_evt_param_t;

typedef enum
{
	UPLUS_BLE_GAP_EVT_CONNECTED = 0, /**< Generated when a connection is established.*/
	UPLUS_BLE_GAP_EVT_DISCONNET, /**< Generated when a connection is terminated.*/
	UPLUS_BLE_GAP_EVT_CONN_PARAM_UPDATED,
	UPLUS_BLE_GAP_EVT_ADV_REPORT,
} uplus_ble_gap_evt_t;

typedef void (*uplus_ble_gap_callback_t)(uplus_ble_gap_evt_t evt,
	uplus_ble_gap_evt_param_t* param);
extern uplus_ble_status_t uplus_ble_gap_register(uplus_ble_gap_callback_t cb);

/*============================GATT============================================*/
/*GATT-Server*/
typedef enum
{
	UPLUS_BLE_GATTS_EVT_READ,
	UPLUS_BLE_GATTS_EVT_WRITE,
	UPLUS_BLE_GATTS_EVT_CCCD_UPDATE,
	UPLUS_BLE_GATTS_EVT_READ_PERMIT_REQ, /**< If charicteristic's rd_auth = TRUE, this event will be generated.*/
	UPLUS_BLE_GATTS_EVT_WRITE_PERMIT_REQ /**< If charicteristic's wr_auth = TRUE, this event will be generated, meanwhile the char value hasn't been modified. uplus_ble_gatts_rw_auth_reply().*/
} uplus_ble_gatts_evt_t;

/*
 * UPLUS_BLE_GATTS_EVT_WRITE
 * UPLUS_BLE_GATTS_EVT_CCCD_UPDATE
 * UPLUS_BLE_GATTS_EVT_WRITE_PERMIT_REQ events callback parameters
 * */
typedef struct
{
	uplus_u16 value_handle;
	uplus_u8 offset;
	uplus_u8 *data;
	uplus_u16 len;
} uplus_ble_gatts_write_t;

/*
 * UPLUS_BLE_GATTS_EVT_READ
 * UPLUS_BLE_GATTS_EVT_READ_PERMIT_REQ event callback parameters
 * */
typedef struct
{
	uplus_u16 value_handle;
	uplus_u8 offset;
	uplus_u8 **data;
	uplus_u16 *len;
} uplus_ble_gatts_read_t;

/*
 * GATTS event callback parameters union
 * */
typedef struct
{
	uplus_u16 conn_handle;
	union
	{
		uplus_ble_gatts_write_t write;
		uplus_ble_gatts_read_t read;
	};
} uplus_ble_gatts_evt_param_t;

typedef uplus_ble_status_t (*uplus_ble_gatts_callback_t)(
	uplus_ble_gatts_evt_t evt,
	uplus_ble_gatts_evt_param_t* param);
extern uplus_ble_status_t uplus_ble_gatts_register(uplus_ble_gatts_callback_t cb);

typedef enum
{
	UPLUS_BLE_PRIMARY_SERVICE = 1,
	UPLUS_BLE_SECONDARY_SERVICE,
} uplus_ble_gatts_service_t;

typedef struct
{
	uplus_u8 reliable_write;
	uplus_u8 writeable;
} uplus_ble_gatts_char_desc_ext_prop_t;

typedef struct
{
	uplus_s8 *string;
	uplus_u8 len;
} uplus_ble_gatts_char_desc_user_desc_t;

typedef struct
{
	uplus_u8 format;
	uplus_u8 exponent;
	uplus_u16 unit;
	uplus_u8 name_space;
	uplus_u16 desc;
} uplus_ble_gatts_char_desc_cpf_t;

/*
 * NOTE: if char property contains notify , then SHOULD include cccd(client characteristic configuration descriptor automatically). The same to sccd when BROADCAST enabled
 * */
typedef struct
{
	uplus_ble_gatts_char_desc_ext_prop_t *extend_prop;
	uplus_ble_gatts_char_desc_cpf_t	*char_format; /*See more details at Bluetooth SPEC 4.2 [Vol 3, Part G] Page 539*/
	uplus_ble_gatts_char_desc_user_desc_t *user_desc; /*read only*/
} uplus_ble_gatts_char_desc_db_t;

/*
 * gatts characteristic
 * default:  no authentication ; no encrption; configurable authorization
 */
typedef enum
{
	UPLUS_BLE_BROADCAST = 0x01,
	UPLUS_BLE_READ = 0x02,
	UPLUS_BLE_WRITE_WITHOUT_RESP = 0x04,
	UPLUS_BLE_WRITE = 0x08,
	UPLUS_BLE_NOTIFY = 0x10,
	UPLUS_BLE_INDICATE = 0x20,
	UPLUS_BLE_AUTH_SIGNED_WRITE = 0x40,
	UPLUS_BLE_EXTENDED_PROPERTIES = 0x80
} uplus_ble_gatts_char_property;

typedef struct
{
	uplus_ble_uuid_t char_uuid;
	uplus_u8 char_property; /**< See TYPE uplus_ble_gatts_char_property for details*/
	uplus_u8 *p_value; /**< initial characteristic value*/
	uplus_u16 char_value_len;
	uplus_u16 char_value_handle; /**< [out] where the assigned handle be stored.*/
	uplus_u8 is_variable_len;
	uplus_u8 rd_author; /**< read authorization. Enable or Disable UPLUS_BLE_GATTS_EVT_READ_PERMIT_REQ event*/
	uplus_u8 wr_author; /**< write authorization. Enable or Disable UPLUS_BLE_GATTS_EVT_WRITE_PERMIT_REQ event*/
	uplus_ble_gatts_char_desc_db_t char_desc_db;
} uplus_ble_gatts_char_db_t;

/*Regardless of service inclusion service*/
typedef struct
{
	uplus_ble_gatts_service_t srv_type; /**< primary service or secondary service*/
	uplus_u16 srv_handle; /**< [out] dynamically allocated*/
	uplus_ble_uuid_t srv_uuid; /**< 16-bit or 128-bit uuid*/
	uplus_u8 char_num;
	uplus_ble_gatts_char_db_t *p_char_db; /**< p_char_db[charnum-1]*/
} uplus_ble_gatts_srv_db_t;

typedef struct
{
	uplus_ble_gatts_srv_db_t *p_srv_db; /**< p_srv_db[srv_num]*/
	uplus_u8 srv_num;
} uplus_ble_gatts_db_t;
extern uplus_ble_status_t uplus_ble_gatts_service_set(uplus_ble_gatts_db_t *uplus_ble_service_database);

extern uplus_ble_status_t uplus_ble_gatts_notify_or_indicate(
	uplus_u16 conn_handle,
	uplus_u16 srv_handle,
	uplus_u16 char_value_handle,
	uplus_u8 offset,
	uplus_u8* p_value,
	uplus_u16 len);

extern uplus_ble_status_t uplus_ble_gatts_mtu_default_set(uplus_u16 mtu);
extern uplus_ble_status_t uplus_ble_gatts_mtu_get(uplus_u16 conn_handle);

/*GATT-Client*/
typedef struct
{
	uplus_u16 begin_handle;
	uplus_u16 end_handle;
} uplus_ble_handle_range_t;

typedef enum
{
	/** this event generated in responses to a discover_primary_service procedure.*/
	UPLUS_BLE_GATTC_EVT_PRIMARY_SERVICE_DISCOVER_RESP = 0,
	/** this event generated in responses to a discover_charicteristic_by_uuid procedure.*/
	UPLUS_BLE_GATTC_EVT_CHR_DISCOVER_BY_UUID_RESP,
	/** this event generated in responses to a discover_char_clt_cfg_descriptor procedure.*/
	UPLUS_BLE_GATTC_EVT_CCCD_DISCOVER_RESP,
	/** this event generated in responses to a read_charicteristic_value_by_uuid procedure.*/
	UPLUS_BLE_GATTC_EVT_READ_CHAR_VALUE_BY_UUID_RESP,
	/** this event generated in responses to a
	write_charicteristic_value_with_response procedure.*/
	UPLUS_BLE_GATTC_EVT_WRITE_RESP,
	/** this event is generated when peer gatts device send a notification. */
	UPLUS_BLE_GATTC_EVT_NOTIFICATION,
	/** this event is generated when peer gatts device send a indication. */
	UPLUS_BLE_GATTC_EVT_INDICATION,
} uplus_ble_gattc_evt_t;

/*
 * UPLUS_BLE_GATTC_EVT_PRIMARY_SERVICE_DISCOVER_RESP event callback parameters
 * */
typedef struct
{
	uplus_ble_handle_range_t primary_srv_range;
	uplus_ble_uuid_t srv_uuid;
	uplus_u8 succ; /*true : exist the specified primary service and return correctly*/
} uplus_ble_gattc_prim_srv_disc_rsp_t;

/*
 * UPLUS_BLE_GATTC_EVT_CHR_DISCOVER_BY_UUID_RESP event callback parameters
 * */
typedef struct
{
	uplus_ble_handle_range_t char_range;
	uplus_ble_uuid_t uuid_type;
	uplus_ble_uuid_t* char_uuid;
	uplus_u8 succ; /*true: exist the specified characteristic and return correctly*/
} uplus_ble_gattc_char_disc_rsp_t;

/*
 * UPLUS_BLE_GATTC_EVT_CCCD_DISCOVER_RESP event callback parameters
 * */
typedef struct
{
	uplus_u16 desc_handle;
	uplus_u8 succ; /*true: exit cccd and return correctly*/
} uplus_ble_gattc_clt_cfg_desc_disc_rsp;

/*
 * UPLUS_BLE_GATTC_EVT_READ_CHAR_VALUE_BY_UUID_RESP event callback paramters
 * */
typedef struct
{
	uplus_u16 char_value_handle;
	uplus_u8 len;
	uplus_u8* data;
	uplus_u8 succ; /*true: exist the specified characteristic and return correctly*/
} uplus_ble_gattc_read_char_value_by_uuid_rsp;

/*
 * UPLUS_BLE_GATTC_EVT_WRITE_RESP event callback parameters
 *  */
typedef struct
{
	uplus_u8 succ;
} uplus_ble_gattc_write_rsp;

/*
 * UPLUS_BLE_GATTC_EVT_NOTIFICATION or UPLUS_BLE_GATTC_EVT_INDICATION event callback parameters
 *  */
typedef struct
{
	uplus_u16 handle;
	uplus_u8 len;
	uplus_u8 *pdata;
} uplus_ble_gattc_notification_or_indication_t;

/*
 * GATTC callback parameters union
 * */
typedef struct
{
	uplus_u16 conn_handle;
	union
	{
		uplus_ble_gattc_prim_srv_disc_rsp_t srv_disc_rsp;
		uplus_ble_gattc_char_disc_rsp_t char_disc_rsp;
		uplus_ble_gattc_read_char_value_by_uuid_rsp read_char_value_by_uuid_rsp;
		uplus_ble_gattc_clt_cfg_desc_disc_rsp clt_cfg_desc_disc_rsp;
		uplus_ble_gattc_write_rsp write_rsp;
		uplus_ble_gattc_notification_or_indication_t notification;
	};
} uplus_ble_gattc_evt_param_t;

typedef void (*uplus_ble_gattc_callback_t)(
	uplus_ble_gattc_evt_t evt,
	uplus_ble_gattc_evt_param_t* param);
uplus_ble_status_t uplus_ble_gattc_register(uplus_ble_gattc_callback_t cb);

uplus_ble_status_t uplus_ble_gattc_primary_service_discover_by_uuid(
	uplus_u16 conn_handle,
	uplus_ble_handle_range_t* handle_range,
	uplus_ble_uuid_t* p_srv_uuid);
uplus_ble_status_t uplus_ble_gattc_char_discover_by_uuid(
	uplus_u16 conn_handle,
	uplus_ble_handle_range_t* handle_range,
	uplus_ble_uuid_t* p_char_uuid);
uplus_ble_status_t uplus_ble_gattc_clt_cfg_descriptor_discover(
	uplus_u16 conn_handle,
	uplus_ble_handle_range_t* handle_range);
uplus_ble_status_t uplus_ble_gattc_read_char_value_by_uuid(
	uplus_u16 conn_handle,
	uplus_ble_handle_range_t* handle_range,
	uplus_ble_uuid_t *p_char_uuid);
uplus_ble_status_t uplus_ble_gattc_write_with_rsp(
	uplus_u16 conn_handle,
	uplus_u16 handle,
	uplus_u8* p_value,
	uplus_u8 len);
uplus_ble_status_t uplus_ble_gattc_write_cmd(
	uplus_u16 conn_handle,
	uplus_u16 handle,
	uplus_u8* p_value,
	uplus_u8 len);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __UPLUS_PAL_BLE_H__ */


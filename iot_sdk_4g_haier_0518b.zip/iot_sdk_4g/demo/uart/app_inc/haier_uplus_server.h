#ifndef    _UPLUS_SERVER_H_
#define    _UPLUS_SERVER_H_

#include "haier_appmain.h"


/*! \def PKT_BUF_DIR_XXX
 *
 * \brief ���ݷ������͡�
 * REQ ����-->�豸������
 * RSP �豸-->���磬Ӧ��
 * RPT �豸-->���磬�����ϱ���
 *
 */
#define PKT_BUF_DIR_REQ 1
#define PKT_BUF_DIR_RSP 2
#define PKT_BUF_DIR_RPT 3

#define EPP_DATA		  1
#define	EPP_BIG_DATA	  2

#define FILE_NAME_U_CONFIG		"U_CONFIG"
#define FILE_NAME_U_CONFIG_BAT	"U_CONFIG_BAT"

typedef enum
{
    UPLUS_STATE_UNINIT = 0,
 	UPLUS_STATE_INIT_FAIL,
	UPLUS_STATE_RUN,
		
}UPLUS_STATE;

extern dev_info_t dev;

extern void uplus_server_test_task(void *pParameter);
extern void uplus_server_task_main(void *pParameter);
extern void Haier_EventNotifyServer(uint8 dir, uint8 data_sub_type, uint8 *appData, uint32 appDataLen);
extern void set_uplus_sdk_state(UPLUS_STATE state);
extern uint8 get_uplus_sdk_state();

#endif



/**************************************************************************
 * SHA256 declarations 
 **************************************************************************/

#ifndef _ZK_SHA256_H
#define _ZK_SHA256_H

#include "haier_appmain.h"


#define SHA256_SIZE   32

typedef struct
{
    uint32 total[2];
    uint32 state[8];
    uint8 buffer[64];
	
} SHA256_CTX;


void SHA256_Init(SHA256_CTX *ctx);


void SHA256_Update(SHA256_CTX *ctx, const uint8 * msg, int len);


void SHA256_Final(uint8 *digest, SHA256_CTX *ctx);


#endif


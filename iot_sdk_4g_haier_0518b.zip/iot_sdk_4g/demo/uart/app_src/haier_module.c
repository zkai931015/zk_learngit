#include "haier_module.h"
#include "haier_bottomPlate.h"

void vat_send_handle(char * pCmd, uint16 length);
VOID vat_recv_handle(UINT8 *pData, UINT16 length);
uint8 get_net_state(void);

static AtCmdRsp vat_CmdCb_wimei(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_IMEI_ACK);
    
	if(p != NULL)
	{
		memcpy(appSysTem.Module_IMEI, p+strlen(VAT_IMEI_ACK), 15);

		appSysTem.vat_ack_falg = 1;
		
		uplus_sys_log("[zk vat] get imei:%s", appSysTem.Module_IMEI);
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_iccid(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_ICCID_ACK);
    
	if(p != NULL)
	{
		memcpy(appSysTem.Module_ICCID, p+strlen(VAT_ICCID_ACK), 20);

		appSysTem.vat_ack_falg = 1;
		
		uplus_sys_log("[zk vat] get iccid:%s", appSysTem.Module_ICCID);
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_cimi(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_CIMI_ACK);
    
	if(p != NULL)
	{
		memcpy(appSysTem.Module_IMSI, p, 15);

		appSysTem.vat_ack_falg = 1;
		
		uplus_sys_log("[zk vat] get imsi:%s", appSysTem.Module_IMSI);
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_csq(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_CGPADDR_ACK);
    
	if(p != NULL)
	{
		appSysTem.vat_ack_falg = 1;
		
		uplus_sys_log("[zk vat] get csq:%s", p);
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_ipaddr(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_CGPADDR_ACK);
	uint8 cnt=0;

	if(p != NULL)
	{
		uplus_sys_log("[zk vat] get ipaddr:%s", p);
		
		p = strstr(pRspStr, "\"");
		if(p != NULL)
		{
			char *ip_p = ++p;
			while(((*p) != '\"')&&((*p) != '\r')&&((*p) != '\n'))
			{
				//uplus_sys_log("[zk vat] get ipaddr:0x%x", (*p));
				cnt++;
				p++;
			}
			appSysTem.vat_ack_falg = 1;
			memcpy(appSysTem.Module_ipaddr, ip_p, cnt);
			
			uplus_sys_log("[zk vat] get ipaddr:%s", appSysTem.Module_ipaddr);
			return 0;
		}
		else
		{
			uplus_sys_log("[zk vat] get ipaddr:error");
		}
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_EEMGINFO(u8* pRspStr)
{
   //uplus_sys_log("[zk vat] get EEMGINFO:%s", pRspStr);
   uint8 cnt = 0;
   char *p = strstr(pRspStr, VAT_EEMGINFO_ACK);
   char* j = NULL;
   if(p != NULL)
   {
   		appSysTem.vat_ack_falg = 1;
		p += strlen(VAT_EEMGINFO_ACK);
		while(((*p) != 0x0d)&&((*p) != 0x0a))
		{
			if((*p) == 0x2c)
			{
				cnt++;
				if(cnt == 9)
				{
					j = p;
					j++;
				}
				else if(cnt == 10)
				{
					char* c = p;
					memcpy(net_info.Cell_ID, j, c-j);
					//uplus_sys_log("[zk vat] get net info ci=%s", net_info.Cell_ID);
				}
				else if(cnt == 11)
				{
					j = p;
					j++;
					net_info.rsrp = my_atoi(j);
					//uplus_sys_log("[zk vat] get net info rsrp=%d", net_info.rsrp);
				}
				else if(cnt == 13)
				{
					j = p;
					j++;
					net_info.snr = my_atoi(j);
					//uplus_sys_log("[zk vat] get net info snr=%d", net_info.snr);
				}
				else if(cnt == 18)
				{
					j = p;
					j++;
					net_info.rssi = my_atoi(j);
					//uplus_sys_log("[zk vat] get net info rssi=%d", net_info.rssi);
					break;
				}
			}
			p++;		
		}
   		uplus_sys_log("[zk vat] get net info ci=%s rsrp=%d snr=%d rssi=%d", net_info.Cell_ID, net_info.rsrp, net_info.snr, net_info.rssi);
   }
   return 0;
}

static AtCmdRsp vat_CmdCb_CNTP(u8* pRspStr)
{
	char *p = strstr(pRspStr, VAT_CNTP_ACK);
	uint8 result = 0;
    
	if(p != NULL)
	{
		uplus_sys_log("[zk vat] cntp:%s", p);

		result = my_atoi(p+strlen(VAT_CNTP_ACK));
		if(result == 1)
		{
			appSysTem.vat_ack_falg = 1;
			
			T_AMOPENAT_SYSTEM_DATETIME datetime1;
			iot_os_get_system_datetime(&datetime1);

			uplus_sys_log("[zk u+]vat_CmdCb_CNTP_0 timer=%d-%d-%d %d:%d:%d", datetime1.nYear, datetime1.nMonth, datetime1.nDay, datetime1.nHour, datetime1.nMin, datetime1.nSec);
		}	
	}
    return 0;
}

VOID vat_recv_handle(UINT8 *pData, UINT16 length)
{
    if((length > 0) && (pData != NULL)) 
	{
		if(strstr(pData, VAT_IMEI_ACK))
		{
			vat_CmdCb_wimei(pData);
		}
		else if(strstr(pData, VAT_ICCID_ACK))
		{
			vat_CmdCb_iccid(pData);
		}
		else if(strstr(pData, VAT_CIMI_ACK))
		{
			vat_CmdCb_cimi(pData);
		}
		else if(strstr(pData, VAT_CSQ_ACK))
		{
			vat_CmdCb_csq(pData);
		}
		else if(strstr(pData, VAT_CGPADDR_ACK))
		{
			vat_CmdCb_ipaddr(pData);
		}
		else if(strstr(pData, VAT_EEMGINFO_ACK))
		{
			vat_CmdCb_EEMGINFO(pData);
		}
		else if(strstr(pData, VAT_CNTP_ACK))
		{
			vat_CmdCb_CNTP(pData);
		}
		else if(strstr(pData, "OK"))
		{
			if(appSysTem.eemopt_flag== 1)
			{
				appSysTem.eemopt_flag= 2;
				uplus_sys_log("[zk vat] set eemopt success");
			}
			else if(appSysTem.cfun_flag)
			{
				uplus_sys_log("[zk vat] set cfun success type=%d", appSysTem.cfun_flag);
			}
		}
		else if(strstr(pData, "ERROR"))
		{
			uplus_sys_log("[zk vat] vat_recv_handle_1:error");
		}
	}
	else
	{
		uplus_sys_log("[zk vat] vat_recv_handle_2:Param error");
	}
}

void vat_send_handle(char * pCmd, uint16 length)
{
	uint16 lenAct = 0;
	if((pCmd == NULL) || (length==0))
		return;

	char *cmd = iot_os_malloc(length);
	if(cmd == NULL)
	{
		uplus_sys_log("[zk vat] vat_send_handle_0 malloc fail %s %d", pCmd, length);
		return;
	}
	memset(cmd, 0, length);
	memcpy(cmd, pCmd, length);

	//ע������AT�������ص�
	IVTBL(init_at)(vat_recv_handle);	
	
	lenAct = IVTBL(send_at_command)(cmd,length);
	if(!lenAct)
		iot_debug_print("[zk vat]ERROR: send at cmd error!");
	else
		iot_debug_print("[zk vat]send at cmd:%s",pCmd);
	
	iot_os_free(cmd);
}

void get_module_imei(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_IMEI, sizeof(VAT_IMEI));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

void get_module_ipaddr(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_CGPADDR, sizeof(VAT_CGPADDR));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

void get_module_iccid(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_ICCID, sizeof(VAT_ICCID));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

void get_module_imsi(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_CIMI, sizeof(VAT_CIMI));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

void set_module_cfun(uint8 type)
{
	uint8 cmd_buf[20] = {0};

	snprintf(cmd_buf, 20, "%s%d%s", VAT_CFUN, type, "\r\n");

	//uplus_sys_log("[zk net] set_module_cfun cmd=%s", cmd_buf);
	appSysTem.cfun_flag = type + 1;
	vat_send_handle(cmd_buf, strlen(cmd_buf));
}

void set_module_eemopt(uint8 mode)
{
	uint8 getCnt = 0;

	appSysTem.eemopt_flag = 1;
	while((appSysTem.eemopt_flag == 1) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_EEMOPT, sizeof(VAT_EEMOPT));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

void ntp_time_syn(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_CNTP, sizeof(VAT_CNTP));
		getCnt++;
		
		iot_os_sleep(1000);
	}
}

void get_module_net_info(void)
{
	/*uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_EEMGINFO, sizeof(VAT_EEMGINFO));
		getCnt++;
		
		iot_os_sleep(500);
	}*/
	vat_send_handle(VAT_EEMGINFO, sizeof(VAT_EEMGINFO));
}

static void module_config(void)
{
	get_module_imei();
	//��ȡICCID
	get_module_iccid();
	//��ȡIMSI
	get_module_imsi();
	//������������Ϊ��ѯģʽ
	set_module_eemopt(1);
	//test
	/*set_module_cfun(0);
	iot_os_sleep(5000);
	set_module_cfun(1);*/
}

static void set_net_state(uint8 net_state)
{
	HANDLE Section = iot_os_enter_critical_section();
    
	appSysTem.netCurrState = net_state;

	iot_os_exit_critical_section(Section);
}

uint8 get_net_state(void)
{
	return appSysTem.netCurrState;
}

static void network_connetck(void)
{
    T_OPENAT_NETWORK_CONNECT networkparam;
    
    memset(&networkparam, 0, sizeof(T_OPENAT_NETWORK_CONNECT));
    //memcpy(networkparam.apn, APN_YIDONG, strlen(APN_YIDONG));
    memcpy(networkparam.apn, "ctexcel", strlen("ctexcel"));

    iot_network_connect(&networkparam);

}

static void networkIndCallBack(E_OPENAT_NETWORK_STATE state)
{
    TASK_MSG* msgptr = iot_os_malloc(sizeof(TASK_MSG));
	uplus_sys_log("[zk net] network ind state %d", state);
	
	switch(state)
	{
		case OPENAT_NETWORK_DISCONNECT:
			msgptr->id= NETWORK_DISCONNECT;
			break;
		case OPENAT_NETWORK_READY:
			msgptr->id = NETWORK_READY;
			break;
		case OPENAT_NETWORK_LINKED:
			msgptr->id = NETWORK_LINKED;
			break;
		default:
			iot_os_free(msgptr);
			msgptr = NULL;
			return;
	}
	
	if(msgptr != NULL)
	{
		iot_os_send_message(network_task_handle,(void *)msgptr);
	}
}

#define SEARCH_NET_MAX_TIME	(3*60*1000)
HANDLE net_timer_handle;
static void net_timer_callback(void *argument)
{	
	uplus_sys_log("[zk net] net_timer_callback:RESET");
	iot_os_restart();
}

#define SERVER_TCP_IP "121.40.198.143"
#define SERVER_TCP_PORT 12415
static void zk_test_socket_tcp_connect_server(void)
{	
	struct openat_timeval tm;
    openat_fd_set ReadSet;
	int32 Result;

    int socketfd;
    int connErr;
    struct openat_sockaddr_in tcp_server_addr; 

	char ipaddr[20] = {0};
	//unsigned short port = 12415;  //56626;
	//memcpy(ipaddr, SERVER_TCP_IP, sizeof(SERVER_TCP_IP));
	
	get_host_by_ip("gw-sea.haieriot.net", ipaddr);
	//memcpy(ipaddr, "101.200.183.79", sizeof("101.200.183.79"));
	unsigned short port = 56814;//56808;  
    // ����tcp socket
    socketfd = socket(OPENAT_AF_INET,OPENAT_SOCK_STREAM,0);
    if (socketfd < 0)
    {
        uplus_sys_log("[socket] create tcp socket error");
        return;
    }
       
    uplus_sys_log("[socket] create tcp socket success");

	uint8 optval[4] = {1,0,0,0};
	uplus_net_socket_opt_set(socketfd, 0, 1, optval, 4);
	uplus_net_socket_opt_set(socketfd, 2, 1, optval, 4);
    
    // ����TCP����
    memset(&tcp_server_addr, 0, sizeof(tcp_server_addr)); // ��ʼ����������ַ  
    tcp_server_addr.sin_family = OPENAT_AF_INET;  
    tcp_server_addr.sin_port = htons((unsigned short)port);  
    inet_aton(ipaddr,&tcp_server_addr.sin_addr);

    uplus_sys_log("[socket] tcp connect to addr %s", ipaddr);
    connErr = connect(socketfd, (const struct sockaddr *)&tcp_server_addr, sizeof(struct openat_sockaddr));

	uplus_net_ssl_client_create(socketfd, NULL, 0);
		
	/*FD_ZERO(&ReadSet);
    FD_SET(socketfd, &ReadSet);
	uint8 Buf[100];
	uint16 RxLen=5;
	
	tm.tv_sec = 10;
   	tm.tv_usec = 0;
	
	Result = select(socketfd + 1, &ReadSet, NULL, NULL, &tm);
    if(Result > 0)
    {
    	Result = recv(socketfd, Buf, RxLen, 0);
        if(Result == 0)
        {
        	iot_debug_print("[zk test]socket close!");
            return -1;
        }
        else if(Result < 0)
        {
        	iot_debug_print("[zk test]recv error %d", socket_errno(socketfd));
            return -1;
        }
        //iot_debug_print("SSL_SocketRx:recv %d %x %x %x %x %x", Result, p[0], p[1], p[2], p[3], p[4]);
		return Result;
    }
    else
    {
    	iot_debug_print("[zk test] read timeout");
    	return -1;
    }*/
}

extern int dns_srver_config(void);
static void app_business_handle(TASK_MSG_ID msgid)
{
	 switch(msgid)
    {
    	case NETWORK_DISCONNECT:
			uplus_sys_log("[zk net] network disconnect");
			//�ı�����״̬��־λ
			set_net_state(NETWORK_DISCONNECT);
			//�ı�ϵͳ״̬
			set_sys_state(SYS_STATE_NETWORK_CONNECT);
			//֪ͨSDK������
			uplus_wifi_status_callback(WIFI_DOWN, WIFI_DOWN_AP_DISCONNECT);
			//��������IP��ַ
			memset(appSysTem.Module_ipaddr, 0, sizeof(appSysTem.Module_ipaddr));

			//ֱ��������λ ���� ����CFUN ����Э��ջ
			iot_os_restart();
			
			set_module_cfun(0);
			iot_os_sleep(5000);
			set_module_cfun(1);
			//����Э��ջ��3min��û�����ɹ���������λ
			iot_os_start_timer(net_timer_handle, SEARCH_NET_MAX_TIME);
			break;
        case NETWORK_READY:
            network_connetck();
			set_net_state(NETWORK_READY);
			set_sys_state(SYS_STATE_NETWORK_CONNECT);
			uplus_sys_log("[zk net] network ready");
            break;
        case NETWORK_LINKED:
            uplus_sys_log("[zk net] network connected");
			//�����ɹ��Ժ󣬹ر������ʱ���������������λ
			if(iot_os_available_timer(net_timer_handle) == TRUE)
			{
				uplus_sys_log("[zk net] stop net timer");
				iot_os_stop_timer(net_timer_handle);
			}
			set_net_state(NETWORK_LINKED);
			set_sys_state(SYS_STATE_RUN);
			//��ȡ�������·���IP������SDK��Ҫ
			get_module_ipaddr();
			//�����ʱ5s��Ϊ������DNS����������Ϊ֮ǰ�ᷢ������ʧ�ܵ����󣬵�����ʱ��Ҳ��ż������
			iot_os_sleep(5000);
			dns_srver_config();

			//zk_test_socket_tcp_connect_server();
			task_msg_send(u_server_task_handle, UPLUS_SDK_INIT_MSG, NULL, 0);
            break;
		default:
			break;
    }
}

void fota_business_handle(TASK_MSG_ID msgid)
{
	 switch(msgid)
    {
        case NETWORK_READY:
            network_connetck();
			uplus_sys_log("[zk net] fota_business_handle: network ready");
            break;
        case NETWORK_LINKED:
            uplus_sys_log("[zk net] fota_business_handle:network connected");
			//�����ɹ��Ժ󣬹ر������ʱ���������������λ
			if(iot_os_available_timer(net_timer_handle) == TRUE)
			{
				uplus_sys_log("[zk net] fota_business_handle:stop net timer");
				iot_os_stop_timer(net_timer_handle);
			}
			set_net_state(NETWORK_LINKED);
			//�ɹ�����PDP���غ�֪ͨFOTA����ʼ���غ�����
			task_msg_send(ota_task_handle, FOTA_START_MSG, NULL, 0);
            break;
		default:
			break;
    }
}

void network_task_main(void *pParameter)
{
    TASK_MSG*    msg;
	
	iot_os_sleep(3000);
	
	if(get_sye_state() != SYS_STATE_FOTA)
	{
		//ģ����һЩ��Ҫ��ʼ������
		module_config();
	}
	//ע������״̬�ص�����
    iot_network_set_cb(networkIndCallBack);
	//����һ��������ʱ������������������3minû�����ɹ���������λ
	net_timer_handle = iot_os_create_timer(net_timer_callback,  (PVOID)4);
	iot_os_start_timer(net_timer_handle, SEARCH_NET_MAX_TIME);
    while(1)
    {
        iot_os_wait_message(network_task_handle, (void *)&msg);

		if(get_sye_state() != SYS_STATE_FOTA)
		{
			app_business_handle(msg->id);
		}
		else
		{
			fota_business_handle(msg->id);
		}
        iot_os_free(msg);
    }
}


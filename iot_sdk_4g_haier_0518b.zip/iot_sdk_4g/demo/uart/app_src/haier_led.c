#include "haier_led.h"
#include "haier_wdg.h"

static void led_Init(void)
{
    T_AMOPENAT_GPIO_CFG  output_cfg;
    BOOL err;
    
    memset(&output_cfg, 0, sizeof(T_AMOPENAT_GPIO_CFG));
    
    output_cfg.mode = OPENAT_GPIO_OUTPUT; //���
    output_cfg.param.defaultState = TRUE; // Ĭ�ϸߵ�ƽ

    err = iot_gpio_config(LED_MODE_PIN, &output_cfg);
    if (!err)
        return;

	err = iot_gpio_config(LED_STATUS_PIN, &output_cfg);
	if (!err)
        return;

	if(get_sye_state() != SYS_STATE_FOTA)
	{
		set_sys_state(SYS_STATE_POWN);
		iot_os_sleep(2000);
		LED_MODE_OFF;
		LED_STATUS_OFF;
	}
	
    uplus_sys_log("[zk led] gpio_Init_0 gpio finish");
}

static uint8 LEDState_ChangeFlag;
void LEDState_Change(uint8 FlashCnt, uint16 time)
{
	uint8 i;
	
	for(i=0; i<FlashCnt; i++)
	{
		LED_STATUS_ON;
		iot_os_sleep(time);
		LED_STATUS_OFF;
		if(FlashCnt > 1)
		{
			iot_os_sleep(time);
		}
	}
}

void led_fota_change(uint8 typ)
{
	if(get_sye_state() == SYS_STATE_FOTA)
	{
		switch(typ)
		{
			case LED_FOTA_START:
				LED_STATUS_ON;
				break;
			case LED_FOTA_STOP:
				LED_STATUS_OFF;
				break;
			default:
				iot_debug_print("[zk led] led_fota_change:typ error %d", typ);
				break;
		}
	}
}

static void led_task_main_handle(void)
{
	switch(appSysTem.sysCurrState)
	{
		case SYS_STATE_POWN:
			set_sys_state(SYS_STATE_NETWORK_CONNECT);
			iot_debug_print("[zk led] led_task_main_0 enter network connect");
			break;
		case SYS_STATE_NETWORK_CONNECT:
			LED_MODE_ON;
			iot_os_sleep(300);
			LED_MODE_OFF;
			iot_os_sleep(300);
			break;
		case SYS_STATE_RUN:
			LED_MODE_ON;
			iot_os_sleep(3000);
			LED_MODE_OFF;
			iot_os_sleep(3000);
			break;
		case SYS_STATE_FOTA:
			LED_STATUS_ON;
			LED_MODE_OFF;
			iot_os_sleep(500);
			LED_STATUS_OFF;
			iot_os_sleep(500);
			iot_debug_print("[zk led] led_task_main_3 sys fota...");
			break;
		default:
			iot_debug_print("[zk led] led_task_main_4 sys status error");
			iot_os_sleep(1000);
			break;
	}
}

void led_task_main(void *pParameter)
{
	led_Init();
	//wdg_init();
	extern HANDLE g_CustTaskHandle;
	iot_os_delete_task(g_CustTaskHandle);
	while(1)
	{
		led_task_main_handle();
	}
}



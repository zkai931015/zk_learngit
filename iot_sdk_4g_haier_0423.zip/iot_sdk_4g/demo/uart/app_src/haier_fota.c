#include "haier_fota.h"

#define DEMO_OTA_FILE_NAME "LIERDA_TEST_FOTA_CORE_720H.bin"		//ģ���ͺŶ�Ӧ�����ļ�
#define DEMO_OTA_FTP_SERVER_IP "36.7.87.100"
#define DEMO_OTA_FTP_USR   "user"
#define DEMO_OTA_FTP_PWD   "123456"

#define DEMO_OTA_ASSERT(c) iot_debug_assert(c, (CHAR*)__func__, __LINE__)

#define DEMO_OTA_MSG_NETWORK_READY (0)
#define DEMO_OTA_MSG_NETWORK_LINKED (1)

void ota_task(PVOID pParameter);

static BOOL demo_ota_download(const char* file)
{
    netbuf* conn = NULL;
    unsigned int fsz;
    BOOL ret = FALSE;

    //FtpCallbackOptions opt;
    FtpInit();
    iot_debug_print("[zk ota] FtpInit suc");
    do{
        if(!FtpConnect(DEMO_OTA_FTP_SERVER_IP, &conn))
        {
            iot_debug_print("[zk ota] connect to %s failed", DEMO_OTA_FTP_SERVER_IP);
            break;
        }
		iot_debug_print("[zk ota] ready FtpInit Login");
        if(!FtpLogin(DEMO_OTA_FTP_USR, DEMO_OTA_FTP_PWD, conn))
        {
            iot_debug_print("[zk ota] login to %s failed", DEMO_OTA_FTP_SERVER_IP);
            break;
        }

        if (!FtpSize(file, (unsigned int*)&fsz, 'I', conn))
        {
            iot_debug_print("[zk ota] get file %s size error", file);
            break;
        }
        iot_debug_print("[zk ota] download %s....", file);
        if(!FtpGet(NULL, file, 'I',conn, fsz))
        {
            iot_debug_print("[zk ota] download file %s error", file);
            break;
        }
        iot_debug_print("[zk ota] download %s end", file);
        ret = TRUE;
    }while(0);

    if(conn)
    {
        FtpClose(conn);
    }
   return ret;
}

void ota_task(PVOID pParameter)
{
    TASK_MSG*    msg;
    BOOL sock = FALSE;
    UINT32 appsize;
    int resp,rv=1;
    unsigned int sz;


    while(1)
    {
        iot_os_wait_message(ota_task_handle, (PVOID)&msg);

        switch(msg->id)
        {
            case FOTA_START_MSG:
                iot_debug_print("[zk ota] fota start");
				set_sys_state(SYS_STATE_FOTA);
                if(!sock)
                {
                    if(iot_fota_init() != 0)//fail
                    {
                        iot_debug_print("[zk ota] fota_init fail");
                        iot_fota_done(); 
                        break;
                    }
                    sock = TRUE;
                    iot_debug_print("[zk ota] fota_init suc,start demo_ota_download");
         			if(!demo_ota_download(DEMO_OTA_FILE_NAME))
                    {
                        iot_debug_print("[zk ota] demo_ota_download fail");
                    }        
                    int r = iot_fota_done();
				  if(r < 0)
				  	iot_debug_print("[zk ota]fota error %d",r);
                    sock = FALSE;
				  iot_debug_print("[zk ota]fota end %d",r);
                }
                break;
			case FOTA_UPDATE_MSG:
				iot_debug_print("[zk ota] fota update");
				iot_os_restart();
				break;
			default:
				break;
        }

        iot_os_free(msg);
    }
}



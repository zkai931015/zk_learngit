#include "haier_led.h"
#include "haier_wdg.h"

static void led_Init(void)
{
    T_AMOPENAT_GPIO_CFG  output_cfg;
    BOOL err;
    
    memset(&output_cfg, 0, sizeof(T_AMOPENAT_GPIO_CFG));
    
    output_cfg.mode = OPENAT_GPIO_OUTPUT; //���
    output_cfg.param.defaultState = TRUE; // Ĭ�ϸߵ�ƽ

    err = iot_gpio_config(LED_MODE_PIN, &output_cfg);
    if (!err)
        return;

	err = iot_gpio_config(LED_STATUS_PIN, &output_cfg);
	if (!err)
        return;
	
	set_sys_state(SYS_STATE_POWN);
	iot_os_sleep(2000);
	LED_MODE_OFF;
	LED_STATUS_OFF;
	
    uplus_sys_log("[zk led] gpio_Init_0 gpio finish");
}

void led_task_main(void *pParameter)
{
	led_Init();
	//wdg_init();
	extern HANDLE g_CustTaskHandle;
	iot_os_delete_task(g_CustTaskHandle);
	while(1)
	{
		switch(appSysTem.sysCurrState)
		{
			case SYS_STATE_POWN:
				set_sys_state(SYS_STATE_NETWORK_CONNECT);
				iot_debug_print("[zk led] led_task_main_0 enter network connect");
				break;
			case SYS_STATE_NETWORK_CONNECT:
				LED_MODE_ON;
				iot_os_sleep(300);
				LED_MODE_OFF;
				iot_os_sleep(300);
				break;
			case SYS_STATE_RUN:
				LED_MODE_ON;
				//uint32 tick = uplus_os_current_time_get();
				//iot_debug_print("[zk led] led_task_main_1 tick=%d", tick);
				iot_os_sleep(3000);
				LED_MODE_OFF;
				//tick = uplus_os_current_time_get();
				//iot_debug_print("[zk led] led_task_main_2 tick=%d", tick);
				iot_os_sleep(3000);
				//iot_debug_print("[zk led] led_task_main_3 tick_diff=%d", uplus_os_diff_time_cal(uplus_os_current_time_get(), tick));
				//iot_debug_print("[zk led] led_task_main_1 sys run...");
				
				//���Դ���
				//extern uplus_sem_id test_handle;
				//uplus_os_sem_give(test_handle);
				break;
			case SYS_STATE_FOTA:
				LED_STATUS_ON;
				LED_MODE_OFF;
				iot_os_sleep(500);
				LED_STATUS_OFF;
				iot_os_sleep(500);
				iot_debug_print("[zk led] led_task_main_3 sys fota...");
				break;
			default:
				iot_debug_print("[zk led] led_task_main_4 sys status error");
				iot_os_sleep(1000);
				break;
		}
	}
}



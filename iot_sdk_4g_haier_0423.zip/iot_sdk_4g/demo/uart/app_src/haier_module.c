#include "haier_module.h"

void vat_send_handle(char * pCmd, uint16 length);
VOID vat_recv_handle(UINT8 *pData, UINT16 length);
uint8 get_net_state(void);

static AtCmdRsp vat_CmdCb_wimei(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_IMEI_ACK);
    
	if(p != NULL)
	{
		memcpy(appSysTem.Module_IMEI, p+strlen(VAT_IMEI_ACK), 15);

		appSysTem.vat_ack_falg = 1;
		
		uplus_sys_log("[zk vat] get imei:%s", appSysTem.Module_IMEI);
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_iccid(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_ICCID_ACK);
    
	if(p != NULL)
	{
		memcpy(appSysTem.Module_ICCID, p+strlen(VAT_ICCID_ACK), 20);

		appSysTem.vat_ack_falg = 1;
		
		uplus_sys_log("[zk vat] get iccid:%s", appSysTem.Module_ICCID);
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_cimi(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_CIMI_ACK);
    
	if(p != NULL)
	{
		memcpy(appSysTem.Module_IMSI, p, 15);

		appSysTem.vat_ack_falg = 1;
		
		uplus_sys_log("[zk vat] get imsi:%s", appSysTem.Module_IMSI);
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_csq(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_CGPADDR_ACK);
    
	if(p != NULL)
	{
		appSysTem.vat_ack_falg = 1;
		
		uplus_sys_log("[zk vat] get csq:%s", p);
	}
    return 0;
}

static AtCmdRsp vat_CmdCb_ipaddr(u8* pRspStr)
{
    char *p = strstr(pRspStr, VAT_CGPADDR_ACK);
	uint8 cnt=0;

	if(p != NULL)
	{
		uplus_sys_log("[zk vat] get ipaddr:%s", p);
		
		p = strstr(pRspStr, "\"");
		if(p != NULL)
		{
			char *ip_p = ++p;
			while(((*p) != '\"')&&((*p) != '\r')&&((*p) != '\n'))
			{
				//uplus_sys_log("[zk vat] get ipaddr:0x%x", (*p));
				cnt++;
				p++;
			}
			appSysTem.vat_ack_falg = 1;
			memcpy(appSysTem.Module_ipaddr, ip_p, cnt);
			
			uplus_sys_log("[zk vat] get ipaddr:%s", appSysTem.Module_ipaddr);
			return 0;
		}
		else
		{
			uplus_sys_log("[zk vat] get ipaddr:error");
		}
	}
    return 0;
}


VOID vat_recv_handle(UINT8 *pData, UINT16 length)
{
    if((length > 0) && (pData != NULL)) 
	{
		if(strstr(pData, VAT_IMEI_ACK))
		{
			vat_CmdCb_wimei(pData);
		}
		else if(strstr(pData, VAT_ICCID_ACK))
		{
			vat_CmdCb_iccid(pData);
		}
		else if(strstr(pData, VAT_CIMI_ACK))
		{
			vat_CmdCb_cimi(pData);
		}
		else if(strstr(pData, VAT_CSQ_ACK))
		{
			vat_CmdCb_csq(pData);
		}
		else if(strstr(pData, VAT_CGPADDR_ACK))
		{
			vat_CmdCb_ipaddr(pData);
		}
		else if(strstr(pData, "ERROR"))
		{
			uplus_sys_log("[zk vat] vat_recv_handle_1:error");
		}
	}
	else
	{
		uplus_sys_log("[zk vat] vat_recv_handle_2:Param error");
	}
}

void vat_send_handle(char * pCmd, uint16 length)
{
	uint16 lenAct = 0;
	if((pCmd == NULL) || (length==0))
		return;

	char *cmd = iot_os_malloc(length);
	if(cmd == NULL)
	{
		uplus_sys_log("[zk vat] vat_send_handle_0 malloc fail %s %d", pCmd, length);
		return;
	}
	memset(cmd, 0, length);
	memcpy(cmd, pCmd, length);

	//ע������AT�������ص�
	IVTBL(init_at)(vat_recv_handle);	
	
	lenAct = IVTBL(send_at_command)(cmd,length);
	if(!lenAct)
		iot_debug_print("[zk vat]ERROR: send at cmd error!");
	else
		iot_debug_print("[zk vat]send at cmd:%s",pCmd);
	
	iot_os_free(cmd);
}

void get_module_imei(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_IMEI, sizeof(VAT_IMEI));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

void get_module_ipaddr(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_CGPADDR, sizeof(VAT_CGPADDR));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

void get_module_iccid(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_ICCID, sizeof(VAT_ICCID));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

void get_module_imsi(void)
{
	uint8 getCnt = 0;

	appSysTem.vat_ack_falg = 0;
	while((appSysTem.vat_ack_falg == 0) && (getCnt < VAT_RESEND_NUM_MAX))
	{
		vat_send_handle(VAT_CIMI, sizeof(VAT_CIMI));
		getCnt++;
		
		iot_os_sleep(500);
	}
}

static void module_config(void)
{
	get_module_imei();
	//��ȡICCID
	get_module_iccid();
	//��ȡIMSI
	get_module_imsi();
}

static void set_net_state(uint8 net_state)
{
	HANDLE Section = iot_os_enter_critical_section();
    
	appSysTem.netCurrState = net_state;

	iot_os_exit_critical_section(Section);
}

uint8 get_net_state(void)
{
	return appSysTem.netCurrState;
}

static void network_connetck(void)
{
    T_OPENAT_NETWORK_CONNECT networkparam;
    
    memset(&networkparam, 0, sizeof(T_OPENAT_NETWORK_CONNECT));
    //memcpy(networkparam.apn, APN_YIDONG, strlen(APN_YIDONG));
    memcpy(networkparam.apn, "ctexcel", strlen("ctexcel"));

    iot_network_connect(&networkparam);

}

static void networkIndCallBack(E_OPENAT_NETWORK_STATE state)
{
    TASK_MSG* msgptr = iot_os_malloc(sizeof(TASK_MSG));
	//uplus_sys_log("[zk net] network ind state %d", state);
	
	switch(state)
	{
		case OPENAT_NETWORK_DISCONNECT:
			msgptr->id= NETWORK_DISCONNECT;
			break;
		case OPENAT_NETWORK_READY:
			msgptr->id = NETWORK_READY;
			break;
		case OPENAT_NETWORK_LINKING:
			msgptr->id = NETWORK_LINKING;
			break;
		case OPENAT_NETWORK_LINKED:
			msgptr->id = NETWORK_LINKED;
			break;
		case OPENAT_NETWORK_GOING_DOWN:
			msgptr->id = NETWORK_GOING_DOWN;
			break;
		default:
			iot_os_free(msgptr);
			return;
	}
	iot_os_send_message(network_task_handle,(void *)msgptr);
}

void network_task_main(void *pParameter)
{
    TASK_MSG*    msg;
	
	iot_os_sleep(3000);
	//ģ����һЩ��Ҫ��ʼ������
	module_config();
	//ע������״̬�ص�����
    iot_network_set_cb(networkIndCallBack);
    while(1)
    {
        iot_os_wait_message(network_task_handle, (void *)&msg);

        switch(msg->id)
        {
        	case NETWORK_DISCONNECT:
				uplus_sys_log("[zk net] network disconnect");
				set_net_state(NETWORK_DISCONNECT);
				set_sys_state(SYS_STATE_NETWORK_CONNECT);
				break;
            case NETWORK_READY:
                network_connetck();
				set_net_state(NETWORK_READY);
				set_sys_state(SYS_STATE_NETWORK_CONNECT);
                break;
			case OPENAT_NETWORK_LINKING:
				uplus_sys_log("[zk net] network linking....");
				set_net_state(OPENAT_NETWORK_LINKING);
				set_sys_state(SYS_STATE_NETWORK_CONNECT);
				break;
            case NETWORK_LINKED:
                uplus_sys_log("[zk net] network connected...");
				set_net_state(NETWORK_LINKED);
				set_sys_state(SYS_STATE_RUN);

				get_module_ipaddr();
				extern int dns_srver_config(void);
				dns_srver_config();
				
				task_msg_send(u_server_task_handle, UPLUS_SDK_INIT_MSG, NULL, 0);
                break;
			case OPENAT_NETWORK_GOING_DOWN:
				uplus_sys_log("[zk net] network going down");
				set_net_state(OPENAT_NETWORK_GOING_DOWN);
				set_sys_state(SYS_STATE_NETWORK_CONNECT);
				break;
			default:
				break;
        }
		
        iot_os_free(msg);
    }
}


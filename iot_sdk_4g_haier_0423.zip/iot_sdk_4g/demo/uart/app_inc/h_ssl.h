#ifndef    _H_SSL_H_
#define    _H_SSL_H_

#include "haier_appmain.h"

#include "uplus_type.h"

#include "ssllib.h"

//#define TEST_IP						"101.132.154.251"

extern uplus_ctx_id net_ssl_client_create(uplus_s32 fd, struct uplus_ca_chain *root_ca, uplus_u8 root_ca_num);
extern uplus_s32 net_ssl_client_handshake(uplus_ctx_id id);
extern uplus_s32 net_ssl_client_close(uplus_ctx_id id);
extern uplus_s32 net_ssl_pending(uplus_ctx_id id);
extern uplus_s32 net_ssl_read(uplus_ctx_id id, uplus_u8 *buf, uplus_size_t len);
extern uplus_s32 net_ssl_write(uplus_ctx_id id, uplus_u8 *buf, uplus_size_t len);

#endif


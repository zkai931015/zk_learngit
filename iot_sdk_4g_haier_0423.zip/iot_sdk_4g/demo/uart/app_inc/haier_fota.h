#ifndef    _HAIER_FOTA_H_
#define    _HAIER_FOTA_H_

#include "haier_appmain.h"

extern void ota_task(PVOID pParameter);

#endif


#include "string.h"
#include "iot_sys.h"
#include "iot_os.h"
#include "iot_debug.h"
#include "iot_flash.h"
#include "iot_socket.h"
#include "iot_network.h"
#include "iot_fs.h"
#include "ftplib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "iot_uart.h"  //zhangkai 2020/04/03
#include "iot_gpio.h"


#define DEMO_OTA_FILE_NAME "LIERDA_TEST_FOTA_CORE_720H.bin"		//ģ���ͺŶ�Ӧ�����ļ�
#define DEMO_OTA_FTP_SERVER_IP "36.7.87.100"
#define DEMO_OTA_FTP_USR   "user"
#define DEMO_OTA_FTP_PWD   "123456"

#define DEMO_OTA_ASSERT(c) iot_debug_assert(c, (CHAR*)__func__, __LINE__)

#define DEMO_OTA_MSG_NETWORK_READY (0)
#define DEMO_OTA_MSG_NETWORK_LINKED (1)

typedef struct {
    UINT8 type;
    UINT8 data;
}MESSAGE;

static HANDLE g_s_ota_task;
static HANDLE uart_task_handle;
static HANDLE network_task_handle;
static HANDLE led_task_handle;

#define APP_VERSION			"V001.005"

#define UART_PORT1				OPENAT_UART_1
#define UART_PORT2 			OPENAT_UART_2
#define UART_RECV_TIMEOUT 	(5 * 1000) 		// 5S

#define NETWORK_DISCONNECT 	(0)
#define NETWORK_READY 			(1)
#define NETWORK_LINKING 		(2)
#define NETWORK_LINKED 		(3)
#define NETWORK_GOING_DOWN 	(4)

#define FOTA_START				1
#define FOTA_UPDATE			2


#define LED_MODE_PIN 	65
#define LED_STATUS_PIN 	64

#define LED_MODE_OFF iot_gpio_set(LED_MODE_PIN, FALSE)
#define LED_MODE_ON  iot_gpio_set(LED_MODE_PIN, TRUE)

#define LED_STATUS_OFF iot_gpio_set(LED_STATUS_PIN, FALSE)
#define LED_STATUS_ON  iot_gpio_set(LED_STATUS_PIN, TRUE)


typedef enum
{
	UART1_RECV_MSG=1,
	UART2_RECV_MSG,
		
}TASK_MSG_ID;

typedef enum
{
	SYS_STATE_POWN=1,
	SYS_STATE_NETWORK_CONNECT,
    SYS_STATE_RUN,
    SYS_STATE_FOTA,
		
}SYS_STATE;


typedef struct
{
    TASK_MSG_ID id;
    UINT32 len;
    VOID *param;
}TASK_MSG;

typedef enum
{
    UART_1 = 1,
	UART_2
		
}UART_ID;


typedef struct
{
    UART_ID uart_id;
    UINT32 len;
    VOID *param;
}UART_MSG;

SYS_STATE SysTem_Status;

static int led_status_change(uint16 led_state);


static BOOL demo_ota_download(const char* file)
{
    netbuf* conn = NULL;
    unsigned int fsz;
    BOOL ret = FALSE;

    //FtpCallbackOptions opt;
    FtpInit();
    iot_debug_print("[zk ota] FtpInit suc");
    do{
        if(!FtpConnect(DEMO_OTA_FTP_SERVER_IP, &conn))
        {
            iot_debug_print("[zk ota] connect to %s failed", DEMO_OTA_FTP_SERVER_IP);
            break;
        }
		iot_debug_print("[zk ota] ready FtpInit Login");
        if(!FtpLogin(DEMO_OTA_FTP_USR, DEMO_OTA_FTP_PWD, conn))
        {
            iot_debug_print("[zk ota] login to %s failed", DEMO_OTA_FTP_SERVER_IP);
            break;
        }

        if (!FtpSize(file, (unsigned int*)&fsz, 'I', conn))
        {
            iot_debug_print("[zk ota] get file %s size error", file);
            break;
        }
        iot_debug_print("[zk ota] download %s....", file);
        if(!FtpGet(NULL, file, 'I',conn, fsz))
        {
            iot_debug_print("[zk ota] download file %s error", file);
            break;
        }
        iot_debug_print("[zk ota] download %s end", file);
        ret = TRUE;
    }while(0);

    if(conn)
    {
        FtpClose(conn);
    }
   return ret;
}



static void demo_network_connetck(void)
{
    T_OPENAT_NETWORK_CONNECT networkparam;
    
    memset(&networkparam, 0, sizeof(T_OPENAT_NETWORK_CONNECT));
    memcpy(networkparam.apn, "ctexcel", strlen("ctexcel"));

    iot_network_connect(&networkparam);

}

static void demo_ota_task(PVOID pParameter)
{
    MESSAGE*    msg;
    BOOL sock = FALSE;
    UINT32 appsize;
    int resp,rv=1;
    unsigned int sz;

    while(1)
    {
        iot_os_wait_message(g_s_ota_task, (PVOID)&msg);

        switch(msg->type)
        {
            case FOTA_START:
                iot_debug_print("[zk ota] fota start");
				led_status_change(SYS_STATE_FOTA);
                if(!sock)
                {
                    if(iot_fota_init() != 0)//fail
                    {
                        iot_debug_print("[zk ota] fota_init fail");
                        iot_fota_done(); 
                        break;
                    }
                    sock = TRUE;
                    iot_debug_print("[zk ota] fota_init suc,start demo_ota_download");
         			if(!demo_ota_download(DEMO_OTA_FILE_NAME))
                    {
                        iot_debug_print("[zk ota] demo_ota_download fail");
                    }        
                    int r = iot_fota_done();
				  if(r < 0)
				  	iot_debug_print("[zk ota]fota error %d",r);
                    sock = FALSE;
				  iot_debug_print("[zk ota]fota end %d",r);
                }
                break;
			case FOTA_UPDATE:
				iot_debug_print("[zk ota] fota update");
				iot_os_restart();
				break;
			default:
				break;
        }

        iot_os_free(msg);
    }
}

VOID uart_msg_send(HANDLE hTask, TASK_MSG_ID id, VOID *param, UINT32 len)
{
    TASK_MSG *msg = NULL;

    msg = (TASK_MSG *)iot_os_malloc(sizeof(TASK_MSG));
    msg->id = id;
    msg->param = param;
    msg->len = len;

    iot_os_send_message(hTask, msg);
}


void uart2_recv_handle(T_AMOPENAT_UART_MESSAGE* evt)
{
	UINT8 *recv_buff = NULL;
    int32 recv_len;
    int32 dataLen = evt->param.dataLen;

	if(dataLen > 0)
	{
		recv_buff = iot_os_malloc(dataLen);
		if(recv_buff == NULL)
		{
			iot_debug_print("[zk ota] uart2_recv_handle_0 recv_buff malloc fail %d", dataLen);
		}
	}
	else
	{
		iot_debug_print("[zk ota] uart2_recv_handle_1 datalen error %d", dataLen);
		return;
	}
	
    switch(evt->evtId)
    {
        case OPENAT_DRV_EVT_UART_RX_DATA_IND:
    
            recv_len = iot_uart_read(UART_PORT2, recv_buff, dataLen , UART_RECV_TIMEOUT);
            iot_debug_print("[zk ota] uart2_recv_handle_2:recv_len %d", recv_len);
			uart_msg_send(uart_task_handle, UART2_RECV_MSG, recv_buff, recv_len);
            break;

        case OPENAT_DRV_EVT_UART_TX_DONE_IND:
            iot_debug_print("[zk ota] uart2_recv_handle_3 OPENAT_DRV_EVT_UART_TX_DONE_IND");
            break;
        default:
            break;
    }
}


VOID uart_write(E_AMOPENAT_UART_PORT port,char *buff, int32 len)
{
	/*if((buff == NULL) || (len <=0))
		return;
	
	int32 write_len = len+10;
	char *write_buff = (char*)iot_os_malloc(write_len);
	if(write_buff == NULL)
	{
		iot_debug_print("[zk ota] uart_write_0 malloc fail %d", write_len);
		return;
	}
	memset(write_buff, 0, write_len);
	memcpy(write_buff, buff, len);
	memcpy(write_buff+len, "\r\n ok \r\n", sizeof("\r\n ok \r\n"));

    write_len = iot_uart_write(port, (uint8*)write_buff, len+sizeof("\r\n ok \r\n"));
    iot_debug_print("[zk ota] uart_write_1 uart_%d len %d", port+1, write_len);

	iot_os_free(write_buff);
	write_buff = NULL;*/

	iot_uart_write(port, "\r\nOK\r\n", sizeof("\r\nOK\r\n"));
}

VOID uart_open(VOID)
{
    T_AMOPENAT_UART_PARAM uartCfg;
	
    memset(&uartCfg, 0, sizeof(T_AMOPENAT_UART_PARAM));
    uartCfg.baud = OPENAT_UART_BAUD_115200; 
    uartCfg.dataBits = 8;  
    uartCfg.stopBits = 1; 
    uartCfg.parity = OPENAT_UART_NO_PARITY; 
    uartCfg.flowControl = OPENAT_UART_FLOWCONTROL_NONE; 
    uartCfg.txDoneReport = TRUE;
	uartCfg.uartMsgHande = uart2_recv_handle; 
	iot_uart_open(UART_PORT2, &uartCfg);
	iot_debug_print("[zk ota] uart_open_0");	
}


VOID uart_close(VOID)
{
    iot_uart_close(UART_PORT2);
    iot_debug_print("[zk ota] uart_close_1");
}

VOID uart_init(VOID)
{   
    uart_open(); 
}


static VOID uart_task_main(PVOID pParameter)
{
	TASK_MSG *msg = NULL;
	MESSAGE*    msgptr;
	char buff[20] = {0};
	uart_init();
	while(1)
	{
		iot_os_wait_message(uart_task_handle, (PVOID*)&msg);
		switch(msg->id)
	    {
	        case UART1_RECV_MSG:    
				iot_debug_print("[zk ota] uart_task_main_1 recv_len %s", msg->param);
				uart_write(UART_PORT1, msg->param, msg->len); 
	            break;
			case UART2_RECV_MSG:
				iot_debug_print("[zk ota] uart_task_main_2 recv_len %s", msg->param);
				uart_write(UART_PORT2, msg->param, msg->len); 
				break;
	        default:
	            break;
	    }
		
		memset(buff, 0, 20);
		if(msg->len < 20)
		{
			memcpy(buff, msg->param, msg->len);
		}
		
	    if(msg)
	    {
	        if(msg->param)
	        {
	            iot_os_free(msg->param);
	            msg->param = NULL;
	        }
	        iot_os_free(msg);
	        msg = NULL;
			iot_debug_print("[zk ota] uart_task_main_3 uart free");
	    }

		msgptr = iot_os_malloc(sizeof(MESSAGE));
		memset(msgptr, 0, sizeof(MESSAGE));
		if(msgptr != NULL)
		{
			if(memcmp(buff, "FOTA START", 10) == 0)
			{
				msgptr->type = FOTA_START;
				iot_os_send_message(g_s_ota_task,(PVOID)msgptr);
			}
			else if(memcmp(buff, "FOTA UPDATE", 11) == 0)
			{
				msgptr->type = FOTA_UPDATE;
				iot_os_send_message(g_s_ota_task,(PVOID)msgptr);
			}
			else if(memcmp(buff, "AT+CGMR", 7) == 0)
			{
				iot_debug_print("[zk ota] VER=%s", APP_VERSION);
			}
			else
			{
				iot_os_free(msgptr);
				iot_debug_print("[zk ota] not cmd");
			}
		}
	}
}

static void networkIndCallBack(E_OPENAT_NETWORK_STATE state)
{
    MESSAGE* msgptr = iot_os_malloc(sizeof(MESSAGE));
	
	switch(state)
	{
		case OPENAT_NETWORK_DISCONNECT:
			msgptr->type = NETWORK_DISCONNECT;
			break;
		case OPENAT_NETWORK_READY:
			msgptr->type = NETWORK_READY;
			break;
		case OPENAT_NETWORK_LINKING:
			msgptr->type = NETWORK_LINKING;
			break;
		case OPENAT_NETWORK_LINKED:
			msgptr->type = NETWORK_LINKED;
			break;
		case OPENAT_NETWORK_GOING_DOWN:
			msgptr->type = NETWORK_GOING_DOWN;
			break;
		default:
			iot_os_free(msgptr);
			return;
	}
	iot_os_send_message(network_task_handle,(PVOID)msgptr);
}

static void network_task_main(PVOID pParameter)
{
    MESSAGE*    msg;
    BOOL sock = FALSE;

	extern HANDLE g_CustTaskHandle;
	iot_os_delete_task(g_CustTaskHandle);
	iot_os_sleep(3000);
	//ע������״̬�ص�����
    iot_network_set_cb(networkIndCallBack);
    while(1)
    {
        iot_os_wait_message(network_task_handle, (PVOID)&msg);

        switch(msg->type)
        {
        	case NETWORK_DISCONNECT:
				iot_debug_print("[zk ota] network disconnect");
				led_status_change(SYS_STATE_NETWORK_CONNECT);
				break;
            case NETWORK_READY:
                demo_network_connetck();
				led_status_change(SYS_STATE_NETWORK_CONNECT);
                break;
			case OPENAT_NETWORK_LINKING:
				iot_debug_print("[zk ota] network linking....");
				led_status_change(SYS_STATE_NETWORK_CONNECT);
				break;
            case NETWORK_LINKED:
                iot_debug_print("[zk ota] network connected");
				led_status_change(SYS_STATE_RUN);
                break;
			case OPENAT_NETWORK_GOING_DOWN:
				iot_debug_print("[zk ota] network going down");
				led_status_change(SYS_STATE_NETWORK_CONNECT);
				break;
			default:
				break;
        }
		
        iot_os_free(msg);
    }
}

VOID gpio_Init(VOID)
{
    T_AMOPENAT_GPIO_CFG  output_cfg;
    BOOL err;
    
    memset(&output_cfg, 0, sizeof(T_AMOPENAT_GPIO_CFG));
    
    output_cfg.mode = OPENAT_GPIO_OUTPUT; //输出
    output_cfg.param.defaultState = TRUE; // 默认高电平

    err = iot_gpio_config(LED_MODE_PIN, &output_cfg);
    if (!err)
        return;

	err = iot_gpio_config(LED_STATUS_PIN, &output_cfg);
	if (!err)
        return;
	
    iot_debug_print("[zk ota] gpio_Init_1 gpio finish");
}

static int led_status_change(uint16 led_state)
{
	SysTem_Status = (SYS_STATE)led_state;
	return 0;
}

static VOID led_task_main(PVOID pParameter)
{
	SysTem_Status = SYS_STATE_POWN;
	iot_debug_print("[zk ota] led_task_main_0 sys pown ");
	gpio_Init();
	
	while(1)
	{
		switch(SysTem_Status)
		{
			case SYS_STATE_POWN:
				LED_MODE_ON;
				LED_STATUS_ON;
				iot_os_sleep(1800);
				LED_MODE_OFF;
				LED_STATUS_OFF;
			
				SysTem_Status = SYS_STATE_NETWORK_CONNECT;
				iot_debug_print("[zk ota] network connecting...");
				break;
			case SYS_STATE_NETWORK_CONNECT:
				LED_MODE_ON;
				iot_os_sleep(300);
				LED_MODE_OFF;
				iot_os_sleep(200);
				break;
			case SYS_STATE_RUN:
				LED_MODE_ON;
				iot_os_sleep(3000);
				LED_MODE_OFF;
				iot_os_sleep(2900);
			
				iot_debug_print("[zk ota] led_task_main_4 sys run...");
				break;
			case SYS_STATE_FOTA:
				LED_STATUS_ON;
				LED_MODE_OFF;
				iot_os_sleep(500);
				LED_STATUS_OFF;
				iot_os_sleep(500);
				iot_debug_print("[zk ota] led_task_main_1 sys fota...");
				break;
			default:
				iot_debug_print("[zk ota] led_task_main_2 sys status error");
				iot_os_sleep(5000);
				break;
		}
	}
}

VOID app_main()
{
    g_s_ota_task = iot_os_create_task(demo_ota_task, NULL,10*1024,5,OPENAT_OS_CREATE_DEFAULT,"demo_ota");

	uart_task_handle = iot_os_create_task(uart_task_main, NULL, 2048, 3, OPENAT_OS_CREATE_DEFAULT, "uart_task");

	network_task_handle = iot_os_create_task(network_task_main, NULL, 2048, 1, OPENAT_OS_CREATE_DEFAULT, "network_task");

	led_task_handle = iot_os_create_task(led_task_main, NULL, 1024, 6, OPENAT_OS_CREATE_DEFAULT, "led_task");
}


#include "haier_fota.h"

#define OTA_FILE_NAME "LIERDA_TEST_FOTA_CORE_720H.bin"		//ģ���ͺŶ�Ӧ�����ļ�
#define OTA_FTP_SERVER_IP "36.7.87.100"
#define OTA_FTP_USR   "user"
#define OTA_FTP_PWD   "123456"

#define OTA_ASSERT(c) iot_debug_assert(c, (CHAR*)__func__, __LINE__)

void ota_task(PVOID pParameter);

static BOOL ota_download(const char* file)
{
    netbuf* conn = NULL;
    unsigned int fsz;
    BOOL ret = FALSE;

    //FtpCallbackOptions opt;
    FtpInit();
    iot_debug_print("[zk ota] FtpInit suc");
    do{
        //if(!FtpConnect(OTA_FTP_SERVER_IP, &conn))
        if(!FtpConnect(local.ftp_addr, &conn))
        {
            iot_debug_print("[zk ota] connect to %s failed", local.ftp_addr);
            break;
        }
		iot_debug_print("[zk ota] ready FtpInit Login");
        //if(!FtpLogin(OTA_FTP_USR, OTA_FTP_PWD, conn))
        if(!FtpLogin(local.user_name, local.user_passwod, conn))
        {
            iot_debug_print("[zk ota] login to %s failed", local.ftp_addr);
            break;
        }

        if (!FtpSize(file, (unsigned int*)&fsz, 'I', conn))
        {
            iot_debug_print("[zk ota] get file %s size error", file);
            break;
        }
        iot_debug_print("[zk ota] download %s....", file);
        if(!FtpGet(NULL, file, 'I',conn, fsz))
        {
            iot_debug_print("[zk ota] download file %s error", file);
            break;
        }
        iot_debug_print("[zk ota] download %s end", file);
        ret = TRUE;
    }while(0);

    if(conn)
    {
    	iot_debug_print("[zk ota] download close", file);
        FtpClose(conn);
    }
   return ret;
}

#define FTP_DOWNLOWD_MAX_TIME	(5*60*1000)
HANDLE ftp_timer_handle;
static void ftp_timer_callback(void *argument)
{	
	uplus_sys_log("[zk ota] ftp_timer_callback:RESET");
	iot_os_restart();
}

void ota_task(PVOID pParameter)
{
    TASK_MSG*    msg;
    BOOL sock = FALSE;
    UINT32 appsize;
    int resp,rv=1;
    unsigned int sz;

	//����һ��������ʱ������������FTP���أ�5minû���سɹ���ǿ�Ƹ�λ
	ftp_timer_handle = iot_os_create_timer(ftp_timer_callback,  (PVOID)5);	
    while(1)
    {
        iot_os_wait_message(ota_task_handle, (PVOID)&msg);

        switch(msg->id)
        {
            case FOTA_START_MSG:
                iot_debug_print("[zk ota] fota start");
				set_sys_state(SYS_STATE_FOTA);
				iot_os_start_timer(ftp_timer_handle, FTP_DOWNLOWD_MAX_TIME);
                if(!sock)
                {
                    if(iot_fota_init() != 0)//fail
                    {
                        iot_debug_print("[zk ota] fota_init fail");
                        iot_fota_done(); 
						set_sys_state(SYS_STATE_RUN);
						//���ʧ�ܣ��ر������ʱ��������Ḵλ
						if(iot_os_available_timer(ftp_timer_handle) == TRUE)
		    			{
		    				uplus_sys_log("[zk ota] stop ftp timer");
							iot_os_stop_timer(ftp_timer_handle);
						}	
                        break;
                    }
                    sock = TRUE;
                    iot_debug_print("[zk ota] fota_init suc,start demo_ota_download");
         			//if(!ota_download(OTA_FILE_NAME))
					if(!ota_download(appSysTem.ota_file_name))
                    {
                        iot_debug_print("[zk ota] demo_ota_download fail");
                    }        
                  	int r = iot_fota_done();
				  	if(r < 0)
				  	{
				  		iot_debug_print("[zk ota]fota error %d",r);
                    	sock = FALSE;
						set_sys_state(SYS_STATE_RUN);

						//���ʧ�ܣ��ر������ʱ��������Ḵλ
						if(iot_os_available_timer(ftp_timer_handle) == TRUE)
		    			{
		    				uplus_sys_log("[zk ota] stop ftp timer");
							iot_os_stop_timer(ftp_timer_handle);
						}		
				  	}
					else
					{
						iot_debug_print("[zk ota]fota success result=%d",r);
						iot_os_restart();
					}
                }
                break;
			case FOTA_UPDATE_MSG:
				iot_debug_print("[zk ota] fota update");
				iot_os_restart();
				break;
			default:
				break;
        }

        iot_os_free(msg);
    }
}


